package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Test

class CrashLogTest {
    @Test
    fun summaryNamesTheExceptionAndOurLine() {
        val report = """
            Image Clicker 1.7 crashed
            time: 2026-11-03 07:30:00
            phone: Samsung SM-S911B, Android 14 (API 34)
            thread: main
            java.lang.IllegalArgumentException: radius must be > 0
            	at android.graphics.RadialGradient.<init>(RadialGradient.java:120)
            	at app.imageclicker.BlobCanvas.draw(StyleBlob.kt:209)
            	at app.imageclicker.StyleView.frame(StyleView.kt:150)
        """.trimIndent()
        assertEquals("IllegalArgumentException: radius must be > 0 (StyleBlob.kt:209)", CrashLog.summary(report))
    }

    @Test
    fun summaryOfAnAndroidExitIsItsReason() {
        val report = "Image Clicker 1.8.1 was closed by Android: crash in the phone's native code (usually graphics)\n" +
            "time: 2026-11-03 10:40:00\nopen: settings (live previews), panel\n"
        assertEquals("crash in the phone's native code (usually graphics)", CrashLog.summary(report))
    }

    @Test
    fun readableBitsPullsLibraryNamesOutOfABinaryTombstone() {
        val bin = byteArrayOf(0, 1, 2) + "libhwui.so".toByteArray() + byteArrayOf(0, 7, -1) +
            "random noise".toByteArray() + byteArrayOf(3) + "Abort message: GL error".toByteArray() + byteArrayOf(0) +
            "ab".toByteArray() + byteArrayOf(0) + "libhwui.so".toByteArray()
        val out = CrashLog.readableBits(bin).lines()
        assertEquals(listOf("libhwui.so", "Abort message: GL error"), out)
    }
}
