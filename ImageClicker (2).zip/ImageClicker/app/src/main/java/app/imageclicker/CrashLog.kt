package app.imageclicker

import android.annotation.TargetApi
import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Finds out why the app closed, so it can be shown and sent:
 * - a Java crash is written to a file by an uncaught-exception handler before Android closes the app;
 * - anything else (a crash in the phone's graphics code, Android killing the app for memory, a freeze)
 *   skips that handler, so on Android 11+ the next start asks Android why the app last ended;
 * - a breadcrumb of what was open (settings, tap folder, which menu style, a run) is saved instantly,
 *   so the report says what you were doing, and risky things can be switched off automatically.
 */
object CrashLog {
    private const val FILE = "last_crash.txt"
    private const val META = "crash_meta"

    @Volatile
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                write(app, t, e)
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    private fun stamp(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    private fun phone(): String =
        "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    private fun write(ctx: Context, t: Thread, e: Throwable) {
        val trace = StringWriter().also { e.printStackTrace(PrintWriter(it)) }.toString()
        val text = buildString {
            append("Image Clicker ").append(version(ctx)).append(" crashed\n")
            append("time: ").append(stamp(System.currentTimeMillis())).append('\n')
            append("phone: ").append(phone()).append('\n')
            append("open: ").append(openThings(ctx)).append('\n')
            append("thread: ").append(t.name).append('\n')
            append(trace.take(12000))
        }
        File(ctx.filesDir, FILE).writeText(text)
    }

    @Suppress("DEPRECATION")
    private fun version(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    // ------------------------------------------------------------------ breadcrumbs

    /** What is on screen right now. Written with commit() so it is on disk even if the app dies a moment later. */
    fun breadcrumb(ctx: Context, what: String) {
        val p = ctx.getSharedPreferences(META, Context.MODE_PRIVATE)
        if (p.getString("open", null) == what) return
        p.edit().putString("open", what).putLong("openAt", System.currentTimeMillis()).commit()
    }

    private fun openThings(ctx: Context): String =
        ctx.getSharedPreferences(META, Context.MODE_PRIVATE).getString("open", null) ?: "unknown"

    // ------------------------------------------------------------------ why did the app end last time (Android 11+)

    /**
     * Call when the app starts. If Android says the app ended abnormally since the last check (and no Java
     * report covers it), writes a report, and switches off what was open when it happened so it can't
     * close the app again: animated previews, the menu style that was showing, shader effects.
     */
    fun collect(ctx: Context) {
        val p = ctx.getSharedPreferences(META, Context.MODE_PRIVATE)
        val unclean = p.getString("session", "") == "running" && !OverlayService.alive
        if (unclean) p.edit().putString("session", "reported").commit()
        val reported = collectExit(ctx, p)
        if (!reported && unclean) {
            // Android < 11, or it gave no reason: we still know the overlay never shut down normally
            val f = File(ctx.filesDir, FILE)
            if (f.exists() && System.currentTimeMillis() - f.lastModified() < 10 * 60_000L) return
            val open = openThings(ctx)
            val changed = protect(ctx, open)
            f.writeText(buildString {
                append("Image Clicker ").append(version(ctx)).append(" was closed by Android: it stopped without an error (Android gave no reason)\n")
                append("time: about ").append(stamp(p.getLong("openAt", System.currentTimeMillis()))).append('\n')
                append("phone: ").append(phone()).append('\n')
                append("open: ").append(open).append('\n')
                if (changed.isNotEmpty()) append("to be safe Image Clicker turned off: ").append(changed.joinToString(", ")).append('\n')
            })
        }
    }

    /** The overlay started: if the next start still finds this, it never shut down normally. */
    fun sessionStart(ctx: Context) {
        ctx.getSharedPreferences(META, Context.MODE_PRIVATE).edit().putString("session", "running").commit()
    }

    /** The overlay shut down normally (Exit, or stopped from the notification / setup screen). */
    fun sessionEnd(ctx: Context) {
        ctx.getSharedPreferences(META, Context.MODE_PRIVATE).edit().putString("session", "clean").commit()
    }

    /** Android 11+: reports the newest abnormal end Android recorded. Returns true if it wrote a report. */
    private fun collectExit(ctx: Context, p: android.content.SharedPreferences): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val seen = p.getLong("seenExit", 0L)
        val exits = try {
            Exits.read(ctx)
        } catch (e: Exception) {
            return false
        }
        if (exits.isEmpty()) return false
        p.edit().putLong("seenExit", exits.maxOf { it.time }).apply()
        // the newest abnormal end we haven't reported (an app update after a crash is a normal end; skip past it)
        val e = exits.filter { it.time > seen && it.abnormal && System.currentTimeMillis() - it.time < 3L * 24 * 3600 * 1000 }
            .maxByOrNull { it.time } ?: return false
        val f = File(ctx.filesDir, FILE)
        if (e.javaCrash && f.exists() && kotlin.math.abs(f.lastModified() - e.time) < 120_000L) return true

        val open = openThings(ctx)
        val changed = protect(ctx, open)
        val text = buildString {
            append("Image Clicker ").append(version(ctx)).append(" was closed by Android: ").append(e.reasonText).append('\n')
            append("time: ").append(stamp(e.time)).append('\n')
            append("phone: ").append(phone()).append('\n')
            append("open: ").append(open).append('\n')
            if (e.description.isNotBlank()) append("android says: ").append(e.description).append('\n')
            if (e.memoryMb > 0) append("memory in use: ").append(e.memoryMb).append(" MB\n")
            if (changed.isNotEmpty()) append("to be safe Image Clicker turned off: ").append(changed.joinToString(", ")).append('\n')
            if (e.trace.isNotBlank()) append("--- details ---\n").append(e.trace)
        }
        f.writeText(text)
        return true
    }

    /** Switches off whatever was open when the app died. Returns what it changed. */
    private fun protect(ctx: Context, open: String): List<String> {
        val s = ClickerSettings(ctx)
        val out = ArrayList<String>()
        if (open.contains("live previews") && s.livePreviews) {
            s.livePreviews = false
            out.add("animated previews")
        }
        val style = Regex("menu: ([a-z]+)").find(open)?.groupValues?.get(1)
        if (style != null && style != StyleFactory.DEFAULT && s.menuStyle == style) {
            s.menuStyle = StyleFactory.DEFAULT
            out.add("the ${StyleFactory.resolve(style).name} menu (back to Classic)")
        }
        if (style in setOf("glass", "aurora", "neon", "terminal") && s.shaders) {
            s.shaders = false
            out.add("shader effects")
        }
        return out
    }

    // ------------------------------------------------------------------ reading / showing

    fun read(ctx: Context): String? {
        val f = File(ctx.filesDir, FILE)
        return if (f.exists()) f.readText() else null
    }

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    /** One line: the exception and the first line of our own code, or Android's reason. */
    fun summary(text: String): String {
        val lines = text.lines()
        val first = lines.firstOrNull().orEmpty()
        if (first.contains("was closed by Android:")) return first.substringAfter("was closed by Android:").trim()
        val ex = lines.firstOrNull { it.contains("Exception") || it.contains("Error") } ?: lines.getOrElse(5) { "" }
        val at = lines.firstOrNull { it.trim().startsWith("at app.imageclicker") }
            ?.substringAfter("(")?.substringBefore(")")
        return ex.trim().removePrefix("java.lang.") + (if (at != null) " ($at)" else "")
    }

    /** Readable words from a binary tombstone: library names, the abort message, the signal. */
    fun readableBits(bytes: ByteArray, max: Int = 45): String {
        val words = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() {
            if (sb.length >= 5) words.add(sb.toString())
            sb.setLength(0)
        }
        for (b in bytes) {
            val c = b.toInt() and 0xFF
            if (c in 32..126) sb.append(c.toChar()) else flush()
        }
        flush()
        val keep = words.filter { w ->
            w.contains(".so") || w.contains("abort", true) || w.contains("signal", true) || w.contains("SIG") ||
                w.contains("fatal", true) || w.contains("Skia", true) || w.contains("hwui", true) ||
                w.contains("RenderThread") || w.contains("Exception") || w.contains("imageclicker")
        }
        return keep.distinct().take(max).joinToString("\n")
    }
}

/** One past end of the app, as Android recorded it. */
class ExitRecord(
    val time: Long,
    val reasonText: String,
    val abnormal: Boolean,
    val javaCrash: Boolean,
    val description: String,
    val memoryMb: Long,
    val trace: String
)

@TargetApi(30)
private object Exits {
    fun read(ctx: Context): List<ExitRecord> {
        val am = ctx.getSystemService(ActivityManager::class.java) ?: return emptyList()
        return am.getHistoricalProcessExitReasons(ctx.packageName, 0, 8).map { info ->
            val r = info.reason
            val (text, abnormal) = when (r) {
                ApplicationExitInfo.REASON_CRASH -> "crash (app error)" to true
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "crash in the phone's native code (usually graphics)" to true
                ApplicationExitInfo.REASON_ANR -> "it froze (app not responding)" to true
                ApplicationExitInfo.REASON_LOW_MEMORY -> "the phone ran low on memory" to true
                ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "it used too much CPU or memory" to true
                ApplicationExitInfo.REASON_SIGNALED -> "it was killed by the system (signal ${info.status})" to true
                ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "it failed to start" to true
                ApplicationExitInfo.REASON_UNKNOWN -> "unknown reason" to true
                ApplicationExitInfo.REASON_OTHER -> "the system closed it" to true
                ApplicationExitInfo.REASON_PERMISSION_CHANGE -> "a permission was changed" to false
                ApplicationExitInfo.REASON_USER_REQUESTED -> "closed by you (force stop or update)" to false
                ApplicationExitInfo.REASON_USER_STOPPED -> "stopped by you" to false
                ApplicationExitInfo.REASON_EXIT_SELF -> "it closed itself" to false
                ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "something it depends on stopped" to false
                else -> "reason $r" to false
            }
            val trace = if (r == ApplicationExitInfo.REASON_CRASH_NATIVE || r == ApplicationExitInfo.REASON_ANR) {
                try {
                    info.traceInputStream?.use { input ->
                        val bytes = input.readBytes().let { if (it.size > 600_000) it.copyOf(600_000) else it }
                        if (r == ApplicationExitInfo.REASON_ANR) {
                            val s = String(bytes)
                            val i = s.indexOf("\"main\"")
                            (if (i >= 0) s.substring(i) else s).lines().take(40).joinToString("\n")
                        } else {
                            CrashLog.readableBits(bytes)
                        }
                    } ?: ""
                } catch (e: Exception) {
                    ""
                }
            } else ""
            ExitRecord(
                time = info.timestamp,
                reasonText = text,
                abnormal = abnormal,
                javaCrash = r == ApplicationExitInfo.REASON_CRASH,
                description = info.description ?: "",
                memoryMb = info.pss / 1024,
                trace = trace
            )
        }
    }
}
