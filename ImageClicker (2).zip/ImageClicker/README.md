# Image Clicker

Android overlay auto-clicker driven by **screenshot matching**. You save small images of buttons/icons from the
screen, build a **sequence** of steps in a floating **terminal**, and the app finds each image on screen and taps it.

No root, no OpenCV. Matching is done in Kotlin; taps are injected through an Accessibility Service.

## Build the APK

The project could not be compiled where it was written, so build it once yourself. Pick one:

**A. GitHub Actions (no setup)**
1. Create a GitHub repo. Upload `ImageClicker.zip` (as is, no need to unzip) and put `build.yml` at `.github/workflows/build.yml`.
   Pushing the unzipped folder works too.
2. Open the *Actions* tab → *Build APK* → wait for green → download artifact `ImageClicker-debug-apk`.
3. Unzip, copy `app-debug.apk` to the phone, install. Every build is signed with the same key (`app/debug.keystore`),
   so a new version installs over the old one and keeps your images and sequences.
   If Play Protect blocks it: Play Store → profile → *Play Protect* → ⚙ → turn off *Scan apps with Play Protect* while installing.

The workflow also runs the unit tests (`gradle testDebugUnitTest`) after uploading the APK.

**B. Android Studio**
Open this folder → let it sync → *Build > Build Bundle(s) / APK(s) > Build APK(s)*.

**C. Command line** (JDK 17 + Android SDK with platform 34)
```
./gradlew assembleDebug          # -> app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest      # unit tests (motion, layout, menu model, parser, night window)
```

Min Android 8.0 (API 26). Tested design target: Android 14.

## First-time setup (in the app)

1. **Allow draw-over-apps**
2. **Enable accessibility service** → *Image Clicker* → On
   Sideloaded app and the toggle is greyed out (Android 13+)? Settings → Apps → Image Clicker → ⋮ → *Allow restricted settings*, then retry.
3. **Start overlay terminal** → accept the screen-capture prompt.

A green `>_` bubble appears over every app. Tap it to open/close the terminal, drag it to move.

## Search areas and steady taps

- `area coin`: the screen freezes, drag a box, press Save. From then on `coin` is only searched inside that box
  (every step, watch, find, the tap folder). `area all` does the same for all images without their own box.
  `area coin off` removes it, `area` lists them. The boxes stay outlined on screen (dashed cyan, with the image's
  name), also while a run is going, so you can scroll the page until the button sits inside. `area hide` /
  `area show` (or *Show search areas* in settings) turns the outlines off and on. The lines are drawn just outside
  the searched region, so they never get in the way of matching. A box drawn tight around the
  button still works: it is widened a little around its centre so the image fits.
- **Scroll back** (on by default, `set realign off` to disable): when an image that has its own area is on screen
  but outside the box (the page scrolled), the page is dragged slowly back until the image is inside again. The
  drag starts in the middle of the screen and the finger stays still before lifting, so the page doesn't fling.
  It only drags once the image stands still, and after 4 tries in a row it waits 10 s.
- **Steady taps** (on by default, `set steady off` to disable): an image is only tapped when it is found in the same
  place on two looks in a row. A page that is still scrolling, or a look-alike that flashes by, is never tapped.
- **Gone** needs the score clearly below thr (0.05 under), so a button scoring 0.89 at thr 0.90 still counts as there.

## The tap folder (easiest way)

Open it with the **tap** button in the menu header, *Tap folder* in the ☰ menu, or `tapfolder`.

- It shows every image you saved. **Tap an image and it starts watching it**: as soon as the image is on screen it is
  tapped once. While it stays on screen nothing more happens, and nothing else on the screen is ever tapped.
  Go to another screen and nothing happens; come back to the screen with the image and it taps it again.
  It keeps watching until you tap the red **■**.
- **+ new image** snaps a new one (type its name, press go, drag a box around it). *Snap image* in the ☰ menu does the same.
- **Long-press** images to pick several: *watch* watches them together, *save* stores them as a sequence
  (name it first), and you can also *resnap* (one picked) or *delete* them (tap delete twice).
- **Sequences** lists your saved sequences with their images. *watch* / *run ∞* / *run 1×* start one with a single tap,
  *load* puts it in the terminal, *delete* (tap twice) removes it.

The same in the terminal: `watch coin` (or `watch coin gem`), and in a sequence the step `watch <img>`.
Options: `thr=0.8` (match threshold), `again=3000` (tap again if it's still there 3 s after the tap; default: once per
appearance), `after=500` (pause after a tap before looking again). An image has to be gone for two looks in a row
before it counts as gone, so a single blurry frame never causes a double tap.

## Quick start

Open your target app, then in the terminal:

```
snap play            # screen freezes; drag a box around the Play button; Save
snap collect
snap ok
add tap play
add waitimg loading_done
add tap collect skip
add tap ok skip
add wait 1000
steps                # review
find play            # test: shows match score, outlines it in red
save daily
run 5                # run 5 loops   (run inf = forever)
```

When a run starts the panel hides and the bubble turns into a red **■**. Tap it (or the notification's *Stop run*) to stop.

## Commands

| command | what it does |
|---|---|
| `snap <name>` | freeze screen, drag a box, save it as image `<name>` |
| `resnap <name>` | redo an existing image: same name, so every step using it keeps working. Cancel keeps the old one |
| `snapxy <name> x y w h` | save an image from pixel coordinates |
| `tpl` / `tpl rm <name>` | list / delete images |
| `find <name> [thr=0.9]` | match right now, print score + position, outline it |
| `add <step>` | append a step (see below) |
| `ins <n> <step>` / `edit <n> <step>` | insert before / replace step n |
| `del <n>` / `mv <a> <b>` / `clear` | remove / reorder / empty |
| `steps` | list the sequence |
| `save <n>` / `load <n>` / `seqs` / `rm <n>` | named sequences |
| `run [count\|inf]` / `stop` | start / stop |
| `watch <img> [img2 ...] [thr=] [again=]` | tap each image once every time it appears, nothing else, until ■ |
| `tapfolder` | open the tap folder (saved images + sequences) |
| `area <img>` / `area all` / `area <img> off` / `area` / `area show\|hide` | drag a box: only search there (see Search areas) |
| `set realign on\|off` | scroll an image back into its area (default on) |
| `set steady on\|off` | tap only after two steady sightings (default on) |
| `hold` (or the **hold** button) | tap a spot on screen; the finger stays down there until you tap the red ■ |
| `hold <x> <y> [ms=]` / `hold <img> [ms=]` | long press a point / an image right now (no `ms` = until ■) |
| `do <step>` | run one step right now, e.g. `do swipe 500 1500 500 500` |
| `set thr\|poll\|loopdelay\|marks\|restartdelay <v>` | defaults (see below) |
| `editor` / `sliders` | a slider per image step to tune its `thr` (shows each step's last match score) |
| `errors [clear]` / `times [clear]` | error log / time log of runs |
| `mini [on\|off]` | mini mode: only a small run bar on screen |
| `night [on\|off\|22:00-08:00]` | night mode (see below) |
| `theme` / `theme <name or 1-7>` | next look / pick one (same as the ◐ button) |
| `style [name\|number\|next\|list]` | menu style (13 of them, see *Menu styles*) |
| `menu` / `settings` | open the menu (☰) / the settings page (⚙) |
| `crash [clear]` | why the app closed last time (also shown on the setup screen with a *Copy* button) |
| `label left\|right` | move the project label |
| `status` / `hide` / `clear log` / `exit` | misc |

## Steps

```
tap <img>      [thr=0.9] [timeout=0] [dx=0] [dy=0] [roi=x,y,w,h] [after=300] [skip]
waitimg <img>  [same options]     wait until the image is visible
goneimg <img>  [same options]     wait until the image is gone
hold <img>     [ms=0] [thr=..] [timeout=..] [skip] ...   long press on the image
tapxy <x> <y>                     [after=300]
holdxy <x> <y>                    [ms=0] [after=300]       long press on a point
swipe <x1> <y1> <x2> <y2>         [ms=300] [after=300]
wait <ms>
back | home
watch <img>    [thr=..] [again=0] [after=500] [dx=] [dy=] [roi=]   tap once per appearance (see The tap folder)
```

A sequence is either normal steps or only `watch` steps (watch steps all run together until you stop them).

- `thr` match threshold 0–1 (default from `set thr`, initially 0.90). Lower = more forgiving.
- `timeout` ms to keep looking. **Default 0 = wait forever**, so a step never gives up on its own. If you set one, a timeout stops the run, or moves on when you add `skip`.
- `dx`/`dy` tap offset from the image centre. `roi` limits the search area (faster, fewer false hits).
- `after` pause after the step.

Settings: `thr` default threshold · `poll` ms between screenshots while waiting (350) · `loopdelay` ms between loops (500) · `marks on` flashes a red box where it taps.

## Files

Sequences are plain text (one step per line, `#` comments), images are PNGs, in
`Android/data/app.imageclicker/files/{sequences,templates}/` (reachable over USB or from a file manager that can open `Android/data`).
The current sequence is auto-saved and restored next time.

## Tips and limits

- Images are matched **pixel-wise**, so snap them on the same device/resolution/orientation you will run on. Rotating is handled, but re-snap if the app's layout changes.
- Pick boxes with some detail (text/icon edges). `snap` warns about flat areas that would match anywhere.
- Use `find` to tune `thr` before running. A good hit scores ≥ 0.95; a miss usually scores well below 0.85.
- Apps that block screenshots (`FLAG_SECURE`, many banking/streaming apps) show up black, so image matching cannot work there.
- Android 14+ shows a screen-sharing chip/notification and may ask for capture permission every time you start the overlay. That is a system rule.
- The terminal panel takes focus while open, so some games pause. It is removed automatically during runs.
- Check the target app's terms of service. Automating online games can get accounts banned.

## Long press / hold

- Fastest: tap **hold** in the menu, then tap the spot. The finger stays pressed until you tap the red **■** bubble.
- In a sequence: `add holdxy 540 1800 ms=8000` holds 8 s, then the sequence continues.
  `add hold charge_btn` finds the image and holds it; with no `ms` it holds until you stop the run.
- Android rule: **touching the screen yourself ends the hold.** So tapping ■ (or anywhere) lets go.
- Keep the ■ bubble away from the spot you hold (drag it aside), or the press lands on the bubble.

## Themes

Tap **◐** in the menu to cycle through seven animated looks (your choice is remembered):

1. **Terminal** – green CRT: scanlines, rolling refresh band, flicker, HUD corners, block cursor
2. **Neon** – synthwave sunset: striped sun, twinkling stars, scrolling grid, rotating neon frame
3. **Aurora** – frosted glass with drifting aurora light, grain, light sweep, gradient rim
4. **Inferno** – licking flames, rising embers, pulsing heat, molten shimmering frame
5. **Groovy** – 60s/70s lava lamp (real moving wax blobs), floating weed leaves and daisies, sunburst, retro striped frame
6. **Rasta 420** – Jamaican flag, leaf pulsing to a 76 bpm one-drop beat, smoke, equalizer, waving red/gold/green ribbons
7. **Morphogen** – a living Turing pattern (reaction-diffusion simulated live). It drifts between dividing cells, worms,
   fingerprints, coral and labyrinths and never repeats; every tap or command plants new growth. Icon-only pebble buttons.

The animation only runs while the menu is open; it is hidden during runs and snaps, so it never ends up in the images it matches.

## Logs, sliders, mini mode, night mode

- **Time**: the clock is in the menu header; while running, the mini bar shows how long the run has been going.
- **Error log** (`errors`): every failure (image not found, timeouts, capture problems) with date and time, red in the log.
  Saved to `errors.log`. **Time log** (`times`): one line per run: start, duration, loops, how it ended. Saved to `times.log`.
- **Threshold sliders** (`editor`, or *Thr sliders* in the menu): one slider per image step (0.50–1.00) plus the default.
  Each row shows the step's best score from the last run, green if it would match and red if not. *save* writes the thresholds
  back to the loaded sequence. No need to make a new sequence to change a threshold.
- **Not found → minimized**: when a run stops because an image wasn't found, the menu shrinks to the mini bar, with a
  slider button that opens the editor on the step that failed.
- **Mini mode** (`mini on`): instead of the menu, only a small bar with run inf / stop, the timer, the last status and ⤢ (opens the full menu).
- **Night mode** (`night on`): at 22:00 it starts `run inf`. Until 08:00, whenever the run stops because an image isn't found
  (or fails), it waits `restartdelay` (3 s) and starts `run inf` again. At 08:00 it stops the run it started.
  Change the window with `night 23:30-07:00`. The screen is kept on while night mode is on.

## Menu styles

The menu header has **◐** theme, **hold**, **tap** folder, **⚙** settings and **☰** menu.
**☰** (or `menu`) opens the menu. It has the same eleven actions in every style: Run forever / Stop, Thr sliders, Snap image, Tap folder,
Hold a spot, Log, Settings, Next theme, Night mode (toggle), Mini mode (toggle), Hide menu.
**⚙** (or *Settings* in the menu) opens the settings page. Its gallery shows a picture of every style in a mini phone
screen at the spot where that style sits (switch on *Live previews* to animate them). Tap one to use it: the old style plays its exit, then the new one enters.
The choice is saved and survives restarts.

| # | style | where it sits | look and motion |
|---|---|---|---|
| 1 | Liquid Glass | bottom dock | frosted shelf of glass drops; a liquid drop flows to the item you touch and merges with it (gooey metaballs, AGSL on Android 13+) |
| 2 | Neon Cyberpunk | left rail | slanted neon blades slide in; boot glitch, RGB split, scanlines (AGSL glitch on 13+), scroll the rail |
| 3 | Orbital | centre disc | items orbit a glowing core; spin the ring with your finger, it snaps with a tick; tapping an item swings it to the top and runs it |
| 4 | Card Deck | bottom fan | a hand of cards fans out in 3D; swipe to turn the hand, a tapped card lifts and flips |
| 5 | Morphing Blob | top island | one living shape that morphs into the silhouette of each item; swipe to browse |
| 6 | Particle Burst | centre honeycomb | hexagon cells around a core assemble from streams of particles and burst when pressed |
| 7 | Retro Terminal | top console | green-screen menu that types itself out; the selection steps line by line with a phosphor trail (AGSL CRT on 13+) |
| 8 | Pixel Arcade | bottom cabinet | 8-bit: 12 fps stepped motion, pixel font, buttons drop in like blocks, a hopping cursor |
| 9 | Origami | right drawer | paper panels unfold along their creases (3D hinges), ribbon bookmark, dog-eared corner |
| 10 | Clay | centre grid | puffy pastel clay buttons that drop, squash and jiggle; the selected one inflates |
| 11 | Aurora | top curtain | a night-sky curtain comes down with a wavy hem; aurora light flows from item to item (AGSL on 13+) |
| 12 | Kinetic Brutalist | full screen | huge words in raw blocks slam in from alternating sides and slide with your scroll speed |
| 13 | Classic | top-right dropdown | the original list: rows slide in, ripple, springy switches |

All styles: spring physics (every animation can be interrupted and reversed mid-way), haptic ticks/clicks,
tap outside or press Back to close, items are TalkBack buttons (toggles report on/off), keyboard Tab/arrows + Enter work.
**Reduced motion**: if Android's *Remove animations* is on, or *Calm motion* in settings, menus appear and disappear without animating.
The style follows the current theme's colours. Rotating the phone re-places the menu for the new orientation.

## Settings page

Style gallery · theme list · Night mode, Mini mode, label side, Calm motion, Live previews, Shader effects, Tap marks ·
default threshold slider · Run once, tap folder, sliders, error log, time log, status, clear log, help, exit.

## Add a new menu style

1. Create `app/src/main/java/app/imageclicker/StyleMyThing.kt` with `class MyThingCanvas : StyleCanvas()`.
   Implement `draw(canvas, t)`, `hit(x, y)` (item index under a point, or -1) and `itemBounds(i, out)`.
   Read `items` (the shared `MenuItem` list), `selected` (the pane that is showing) and `open.value` (0 closed … 1 open).
   Animate with `Spring`s: call `.to(target, reduced)` and `.step(dt)` in `update(dt, t)`, and return true while
   something is still moving. Optional: `onSize`, `onItems`, `onSelect`, `onTheme`, `onDown/onUp/onDrag/onFling`,
   `ambient` (keep animating at rest), `viewEffect` (an AGSL shader for Android 13+).
2. Register it in `StyleRegistry.kt`: add a `StyleInfo("mything", "My Thing", "one line") { MyThingCanvas() }` to
   `StyleFactory.all`, and a line in `MenuLayouts.place` for where it sits on screen.
3. That's all: it appears in the settings gallery, `style list`, and the ☰ menu.
   `MenuSystemTest` checks that its placement fits phones, tablets and landscape.

## Code map

`OverlayService` windows, menu/settings, night mode · `Terminal` commands · `Runner` runs sequences ·
`TemplateMatcher` image matching · `Sequence` step syntax · `Themes` the 7 animated themes ·
`MenuKit` menu model + `StyleCanvas` · `StyleView` hosts a style (frames, touch, haptics, TalkBack, AGSL) ·
`Style*.kt` the 13 styles · `StyleRegistry` list + placements · `Motion` springs and helpers · `Shaders` AGSL sources.

## Project label

"martijn's project v1.10" stays in the top-right corner, in the current theme's font, the whole time the app runs.
It can't be tapped, so it never blocks the game. Move it with `label left` / `label right`.
Because it is always on screen it also appears in screenshots: snap images away from that corner, or the label becomes part of the image.
