package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class StepParserTest {

    @Test
    fun tapWithOptions() {
        val s = StepParser.parse("tap coin thr=0.65 timeout=5000 skip dx=4 roi=1,2,3,4")
        assertEquals(Op.TAP, s.op)
        assertEquals("coin", s.tpl)
        assertEquals(0.65, s.thr!!, 1e-9)
        assertEquals(5000L, s.timeout)
        assertTrue(s.skip)
        assertEquals(4, s.dx)
        assertEquals(listOf(1, 2, 3, 4), s.roi)
    }

    @Test
    fun defaultsWaitForever() {
        val s = StepParser.parse("tap coin")
        assertEquals(0L, s.timeout)
        assertNull(s.thr)
        assertEquals(300L, s.after)
        assertEquals(0L, StepParser.parse("waitimg coin").after)
    }

    @Test
    fun holdForms() {
        assertEquals(0L, StepParser.parse("hold boss").ms)
        assertEquals(1500L, StepParser.parse("hold boss ms=1500").ms)
        val h = StepParser.parse("holdxy 10 20")
        assertEquals(Op.HOLDXY, h.op)
        assertEquals(10, h.x)
        assertEquals(20, h.y)
    }

    @Test
    fun roundTrip() {
        val lines = listOf(
            "tap coin thr=0.65 timeout=5000 skip",
            "waitimg door",
            "hold boss ms=1500",
            "holdxy 5 6",
            "swipe 1 2 3 4 ms=500",
            "wait 250",
            "back",
            "tapxy 7 8 after=100"
        )
        for (l in lines) assertEquals(l, StepParser.parse(l).toLine())
    }

    @Test
    fun rejectsBadInput() {
        val bad = listOf("", "jump x", "tap", "tap a b", "tapxy 1", "tapxy a b", "tap c thr=2", "wait soon",
            "tapxy 1 2 thr=0.5", "back now", "tap c foo=1", "swipe 1 2 3", "tap c roi=1,2", "wait 5 ms=3", "tapxy 1 2 skip")
        for (l in bad) {
            try {
                StepParser.parse(l)
                fail("should reject: '$l'")
            } catch (e: IllegalArgumentException) {
                assertTrue(e.message!!.isNotBlank())
            }
        }
    }

    @Test
    fun scriptCollectsErrorsWithLineNumbers() {
        val (steps, errors) = StepParser.parseScript("# demo\ntap a\n\nnope\nwait 10\n")
        assertEquals(2, steps.size)
        assertEquals(1, errors.size)
        assertTrue(errors[0].startsWith("line 4"))
    }
}
