package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TextAndTimeTest {
    private val mono: (String) -> Float = { it.length * 10f }

    @Test
    fun fitKeepsShortText() {
        assertEquals("Log", TextFit.fit("Log", 100f, mono))
    }

    @Test
    fun fitTruncatesLongLabelsWithEllipsis() {
        val long = "Run forever and ever and ever"
        val r = TextFit.fit(long, 120f, mono)
        assertTrue(r.endsWith("…"))
        assertTrue(mono(r) <= 120f)
        // as long as possible: same answer as trying every prefix
        val best = (0..long.length).map { long.substring(0, it).trimEnd() + "…" }.filter { mono(it) <= 120f }.maxByOrNull { it.length }
        assertEquals(best, r)
        // proportional widths too (wide W, narrow i)
        val prop: (String) -> Float = { s -> s.sumOf { c -> if (c == 'W') 14.0 else if (c == 'i') 4.0 else 8.0 }.toFloat() }
        for (wdt in listOf(20f, 37f, 60f, 95f)) {
            val t = "WiWiWide iiii label"
            val got = TextFit.fit(t, wdt, prop)
            val ref = (0..t.length).map { t.substring(0, it).trimEnd() + "…" }.filter { prop(it) <= wdt }.maxByOrNull { it.length } ?: ""
            assertEquals("width $wdt", if (prop(t) <= wdt) t else ref, got)
        }
    }

    @Test
    fun fitHandlesNoRoom() {
        assertEquals("", TextFit.fit("Settings", 0f, mono))
        assertEquals("", TextFit.fit("Settings", 5f, mono))
        assertEquals("…", TextFit.fit("Settings", 10f, mono))
    }

    @Test
    fun nightWindowAcrossMidnight() {
        val s = 22 * 60
        val e = 8 * 60
        assertTrue(NightWindow.contains(s, e, 22 * 60))
        assertTrue(NightWindow.contains(s, e, 23 * 60 + 59))
        assertTrue(NightWindow.contains(s, e, 0))
        assertTrue(NightWindow.contains(s, e, 7 * 60 + 59))
        assertFalse(NightWindow.contains(s, e, 8 * 60))
        assertFalse(NightWindow.contains(s, e, 12 * 60))
        assertFalse(NightWindow.contains(s, e, 21 * 60 + 59))
    }

    @Test
    fun nightWindowSameDayAndEmpty() {
        assertTrue(NightWindow.contains(60, 120, 60))
        assertFalse(NightWindow.contains(60, 120, 120))
        assertFalse(NightWindow.contains(300, 300, 300))
    }

    @Test
    fun nightWindowParse() {
        assertEquals(Pair(22 * 60, 8 * 60), NightWindow.parse("22:00-08:00"))
        assertEquals(Pair(21 * 60 + 30, 6 * 60 + 5), NightWindow.parse(" 21:30 - 6:05 "))
        assertNull(NightWindow.parse("24:00-08:00"))
        assertNull(NightWindow.parse("22:60-08:00"))
        assertNull(NightWindow.parse("tonight"))
        assertNull(NightWindow.parse("22-08"))
    }
}
