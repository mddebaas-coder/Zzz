package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Test

class CrashLogTest {
    @Test
    fun summaryNamesTheExceptionAndOurLine() {
        val report = """
            Image Clicker 1.7 crashed
            time: 2026-11-03 07:30:00
            phone: Samsung SM-S911B, Android 14 (API 34)
            thread: main
            java.lang.IllegalArgumentException: radius must be > 0
            	at android.graphics.RadialGradient.<init>(RadialGradient.java:120)
            	at app.imageclicker.BlobCanvas.draw(StyleBlob.kt:209)
            	at app.imageclicker.StyleView.frame(StyleView.kt:150)
        """.trimIndent()
        assertEquals("IllegalArgumentException: radius must be > 0 (StyleBlob.kt:209)", CrashLog.summary(report))
    }
}
