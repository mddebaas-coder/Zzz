package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AreaTest {
    @Test
    fun parse() {
        assertEquals(Area(843, 1400, 500, 300), Area.parse("843,1400,500,300"))
        assertEquals(Area(1, 2, 3, 4), Area.parse(" 1, 2 ,3,4 "))
        assertNull(Area.parse("1,2,3"))
        assertNull(Area.parse("1,2,0,4"))
        assertNull(Area.parse("-1,2,3,4"))
        assertNull(Area.parse("a,b,c,d"))
        assertNull(Area.parse(null))
        assertEquals("843,1400,500,300", Area(843, 1400, 500, 300).toString())
    }

    @Test
    fun stepRoiBeatsImageAreaBeatsAllArea() {
        val s = Area(1, 1, 10, 10)
        val i = Area(2, 2, 10, 10)
        val a = Area(3, 3, 10, 10)
        assertEquals(s, Area.pick(s, i, a))
        assertEquals(i, Area.pick(null, i, a))
        assertEquals(a, Area.pick(null, null, a))
        assertNull(Area.pick(null, null, null))
    }

    @Test
    fun tightBoxGrowsSoTheImageStillFits() {
        // box dragged exactly around a 100x40 button
        val u = Area.usable(Area(500, 800, 100, 40), 100, 40, 1440, 3000)
        assertTrue(u.w >= 100 + 2 * 25 && u.h >= 40 + 2 * 16)
        // still centred on the box
        assertEquals(550, u.x + u.w / 2)
        assertEquals(820, u.y + u.h / 2)
        // a big box is left alone
        assertEquals(Area(0, 0, 800, 800), Area.usable(Area(0, 0, 800, 800), 100, 40, 1440, 3000))
    }

    @Test
    fun usableStaysOnScreen() {
        val u = Area.usable(Area(1430, 2990, 10, 10), 100, 100, 1440, 3000)
        assertTrue(u.x >= 0 && u.y >= 0 && u.right <= 1440 && u.bottom <= 3000)
        assertTrue(u.w >= 100 && u.h >= 100)
    }

    @Test
    fun samePlace() {
        assertTrue(Area.samePlace(1093, 540, 1095, 543, 120, 60))
        assertFalse(Area.samePlace(1093, 540, 1093, 792, 120, 60)) // another row of the list
        assertTrue(Area.samePlace(0, 0, 0, 0, 10, 10))
    }

    @Test
    fun watchWaitsForASteadySighting() {
        val w = WatchState()
        // first sighting not steady yet (moving / first look): no tap, still armed
        assertEquals(WatchEvent.NONE, w.update(true, 0, steady = false))
        assertTrue(w.armed)
        assertEquals(WatchEvent.TAP, w.update(true, 350, steady = true))
    }

    @Test
    fun justUnderThresholdIsNotGone() {
        val w = WatchState()
        w.update(true, 0)
        // score 0.89 at thr 0.90: not seen, but not absent either -> never re-arms
        repeat(5) { assertEquals(WatchEvent.NONE, w.update(false, 350L * (it + 1), absent = false)) }
        assertFalse(w.armed)
        w.update(false, 3000)
        assertEquals(WatchEvent.GONE, w.update(false, 3350))
    }
}
