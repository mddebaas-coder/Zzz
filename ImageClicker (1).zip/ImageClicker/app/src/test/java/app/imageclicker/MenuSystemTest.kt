package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MenuSystemTest {

    @Test
    fun menuIdsAreUniqueAndAllMap() {
        val ids = MenuModel.ids
        assertEquals(ids.size, ids.toSet().size)
        for (id in ids) {
            val item = MenuModel.item(id, running = false, nightOn = false, miniOn = false)
            assertEquals(id, item.id)
            assertTrue(item.label.isNotBlank())
            assertTrue(item.short.isNotBlank())
        }
        assertTrue(MenuModel.paneIds.all { it in ids })
    }

    @Test
    fun runItemFollowsRunState() {
        val idle = MenuModel.item("toggle", running = false, nightOn = false, miniOn = false)
        val busy = MenuModel.item("toggle", running = true, nightOn = false, miniOn = false)
        assertEquals(Icon.LOOP, idle.icon)
        assertEquals(Icon.STOP, busy.icon)
        assertTrue(idle.primary && busy.primary)
    }

    @Test
    fun togglesCarryTheirState() {
        assertTrue(MenuModel.item("night", false, nightOn = true, miniOn = false).on)
        assertFalse(MenuModel.item("night", false, nightOn = false, miniOn = true).on)
        assertTrue(MenuModel.item("mini", false, nightOn = false, miniOn = true).on)
        assertTrue(MenuModel.item("mini", false, false, false).toggle)
        assertFalse(MenuModel.item("log", false, false, false).toggle)
    }

    @Test(expected = IllegalArgumentException::class)
    fun unknownIdIsRejected() {
        MenuModel.item("nope", false, false, false)
    }

    @Test
    fun atLeastTwelveDistinctStyles() {
        val all = StyleFactory.all
        assertTrue(all.size >= 12)
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertEquals(all.size, all.map { it.name }.toSet().size)
        assertTrue(all.all { it.blurb.length > 20 })
        assertTrue(StyleFactory.index(StyleFactory.DEFAULT) >= 0)
    }

    @Test
    fun savedStyleResolvesOrFallsBack() {
        assertEquals("orbital", StyleFactory.resolve("orbital").id)
        // a removed/renamed style or a corrupted preference falls back to the default
        assertEquals(StyleFactory.DEFAULT, StyleFactory.resolve("does-not-exist").id)
        assertEquals(StyleFactory.DEFAULT, StyleFactory.resolve(null).id)
        assertEquals(StyleFactory.DEFAULT, StyleFactory.resolve("").id)
    }

    @Test
    fun findByNameNumberOrPrefix() {
        assertEquals("brutal", StyleFactory.find("kinetic brutalist")?.id)
        assertEquals("brutal", StyleFactory.find("Kinetic")?.id)
        assertEquals("glass", StyleFactory.find("1")?.id)
        assertEquals("neon", StyleFactory.find("neon")?.id)
        assertEquals("terminal", StyleFactory.find("retro")?.id)
        assertNull(StyleFactory.find("99"))
        assertNull(StyleFactory.find(""))
        assertNull(StyleFactory.find("zzz"))
    }

    @Test
    fun getWrapsAround() {
        val n = StyleFactory.all.size
        assertEquals(StyleFactory.all[0].id, StyleFactory.get(n).id)
        assertEquals(StyleFactory.all[n - 1].id, StyleFactory.get(-1).id)
    }

    /** Phones, small phones, landscape, tablets: every style's box must lie fully inside the window. */
    @Test
    fun everyPlacementFitsEveryScreen() {
        val screens = listOf(320 to 568, 360 to 740, 412 to 915, 740 to 360, 915 to 412, 600 to 960, 800 to 1280, 1280 to 800, 280 to 280)
        for ((sw, sh) in screens) {
            for (info in StyleFactory.all) {
                val p = MenuLayouts.place(info.id, sw, sh)
                val l = p.left(sw)
                val t = p.top(sh)
                val where = "${info.id} on ${sw}x$sh: box $l,$t ${p.w}x${p.h}"
                assertTrue(where, p.w > 0 && p.h > 0)
                assertTrue(where, l >= 0 && t >= 0)
                assertTrue(where, l + p.w <= sw && t + p.h <= sh)
                assertTrue(where, p.scrim in 0..255)
            }
        }
    }

    @Test
    fun placementsAreDistinct() {
        // the styles live in different places / shapes on a phone, not one recoloured box
        val boxes = StyleFactory.all.map { MenuLayouts.place(it.id, 360, 740).let { p -> listOf(p.anchor.name, p.w, p.h) } }
        assertTrue(boxes.toSet().size >= 10)
        assertTrue(StyleFactory.all.map { MenuLayouts.place(it.id, 360, 740).anchor }.toSet().size >= 6)
    }

    @Test
    fun tabletsDoNotStretchCardsEdgeToEdge() {
        val p = MenuLayouts.place("clay", 1280, 800)
        assertTrue(p.w <= 400)
        val g = MenuLayouts.place("glass", 1280, 800)
        assertTrue(g.w <= 440)
    }
}
