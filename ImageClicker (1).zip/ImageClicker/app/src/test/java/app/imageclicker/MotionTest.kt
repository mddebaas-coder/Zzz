package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs

class MotionTest {

    private fun run(s: Spring, seconds: Float, dt: Float = 1f / 60f): Int {
        var frames = 0
        var t = 0f
        while (t < seconds) {
            s.step(dt)
            t += dt
            frames++
        }
        return frames
    }

    @Test
    fun springSettlesOnTarget() {
        val s = Spring(0f, 300f, 0.8f)
        s.to(1f)
        run(s, 2f)
        assertTrue(s.settled)
        assertEquals(1f, s.value, 0f)
        assertEquals(0f, s.velocity, 0f)
    }

    @Test
    fun underDampedSpringOvershootsCriticalDoesNot() {
        val bouncy = Spring(0f, 400f, 0.3f)
        bouncy.to(1f)
        var maxB = 0f
        repeat(120) { bouncy.step(1f / 60f); maxB = maxOf(maxB, bouncy.value) }
        assertTrue("under-damped spring should overshoot, max=$maxB", maxB > 1.05f)

        val firm = Spring(0f, 400f, 1f)
        firm.to(1f)
        var maxF = 0f
        repeat(120) { firm.step(1f / 60f); maxF = maxOf(maxF, firm.value) }
        assertTrue("critically damped spring should not overshoot, max=$maxF", maxF <= 1.001f)
    }

    @Test
    fun retargetKeepsPositionAndVelocity() {
        val s = Spring(0f, 300f, 0.8f)
        s.to(1f)
        repeat(6) { s.step(1f / 60f) }
        val v = s.value
        val vel = s.velocity
        assertTrue(vel > 0f)
        // interrupt: send it back mid-flight
        s.to(0f)
        assertEquals(v, s.value, 0f)
        assertEquals(vel, s.velocity, 0f)
        s.step(1f / 60f)
        // no jump: one frame moves it only a little
        assertTrue(abs(s.value - v) < 0.1f)
        run(s, 2f)
        assertTrue(s.settled)
        assertEquals(0f, s.value, 0f)
    }

    @Test
    fun reducedMotionSnaps() {
        val s = Spring(0f, 300f, 0.8f)
        s.to(1f, reduced = true)
        assertEquals(1f, s.value, 0f)
        assertTrue(s.settled)
    }

    @Test
    fun stepIsFrameRateIndependentEnough() {
        val a = Spring(0f, 250f, 0.9f)
        val b = Spring(0f, 250f, 0.9f)
        a.to(100f)
        b.to(100f)
        run(a, 0.25f, 1f / 30f)
        run(b, 0.25f, 1f / 120f)
        assertTrue("30 fps ${a.value} vs 120 fps ${b.value}", abs(a.value - b.value) < 2.5f)
    }

    @Test
    fun hugeFrameGapIsClamped() {
        val s = Spring(0f, 1500f, 0.2f)
        s.to(1f)
        s.step(5f) // e.g. the app was paused
        assertTrue(s.value.isFinite())
        assertTrue(abs(s.value) < 10f)
    }

    @Test
    fun kickAddsVelocity() {
        val s = Spring(1f, 700f, 0.3f)
        assertTrue(s.settled)
        s.kick(4f)
        assertFalse(s.settled)
        s.step(1f / 60f)
        assertTrue(s.value > 1f)
        run(s, 3f)
        assertEquals(1f, s.value, 0f)
    }

    @Test
    fun wrapAngleStaysInRange() {
        for (k in -20..20) {
            val a = k * 0.7f
            val w = MotionMath.wrapAngle(a)
            assertTrue(w > -PI.toFloat() - 1e-4f && w <= PI.toFloat() + 1e-4f)
            assertEquals(kotlin.math.sin(a), kotlin.math.sin(w), 1e-3f)
        }
    }

    @Test
    fun ringFocusAndRotationAgree() {
        val n = 10
        val focus = (-PI / 2).toFloat()
        var current = 3.3f
        for (i in 0 until n) {
            current = MotionMath.rotationFor(n, i, focus, current)
            assertEquals(i, MotionMath.nearestOnRing(n, current, focus))
        }
        // rotationFor takes the short way round
        val r = MotionMath.rotationFor(n, 1, focus, 0f)
        assertTrue(abs(r) <= PI.toFloat())
        assertEquals(-1, MotionMath.nearestOnRing(0, 0f, 0f))
    }

    @Test
    fun staggerAndPhase() {
        assertEquals(0f, MotionMath.phase(0.1f, 0.2f, 0.4f), 0f)
        assertEquals(0.5f, MotionMath.phase(0.3f, 0.2f, 0.4f), 1e-5f)
        assertEquals(1f, MotionMath.phase(0.9f, 0.2f, 0.4f), 0f)
        assertEquals(1f, MotionMath.phase(1f, 0.5f, 0.5f), 0f)
        // first item starts first, last item finishes exactly at the end
        assertTrue(MotionMath.stagger(0.2f, 0, 5) > MotionMath.stagger(0.2f, 4, 5))
        assertEquals(1f, MotionMath.stagger(1f, 4, 5), 0f)
        assertEquals(0.3f, MotionMath.stagger(0.3f, 0, 1), 0f)
    }

    @Test
    fun fanIsSymmetric() {
        val n = 7
        for (i in 0 until n) {
            assertEquals(-MotionMath.fanAngle(n, i, 1f, 60f), MotionMath.fanAngle(n, n - 1 - i, 1f, 60f), 1e-4f)
        }
        assertEquals(30f, MotionMath.fanAngle(n, n - 1, 1f, 60f), 1e-4f)
        assertEquals(0f, MotionMath.fanAngle(n, 0, 0f, 60f), 0f)
        assertEquals(0f, MotionMath.fanAngle(1, 0, 1f, 60f), 0f)
    }

    @Test
    fun easings() {
        assertEquals(0f, MotionMath.easeOutCubic(0f), 0f)
        assertEquals(1f, MotionMath.easeOutCubic(1f), 0f)
        assertEquals(1f, MotionMath.easeOutBack(1f), 1e-5f)
        var over = 0f
        for (k in 0..100) over = maxOf(over, MotionMath.easeOutBack(k / 100f))
        assertTrue(over > 1f)
        for (k in 0..100) {
            val w = MotionMath.wobble(k * 0.37f, 2f)
            assertTrue(w in -1f..1f)
        }
    }
}
