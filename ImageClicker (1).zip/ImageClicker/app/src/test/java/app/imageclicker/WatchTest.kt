package app.imageclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchTest {

    /** Feeds a visibility timeline (one look every 350 ms) and returns the events. */
    private fun run(w: WatchState, seen: String): List<WatchEvent> =
        seen.mapIndexed { i, c -> w.update(c == '#', i * 350L) }

    @Test
    fun tapsOnceWhenItAppearsThenWaits() {
        val ev = run(WatchState(), "..####....")
        assertEquals(WatchEvent.TAP, ev[2])
        // stays on screen: no more taps
        assertTrue(ev.subList(3, 6).all { it == WatchEvent.NONE })
        assertEquals(1, ev.count { it == WatchEvent.TAP })
    }

    @Test
    fun goingAwayAndComingBackTapsAgain() {
        // you leave the screen (gone for a while) and come back: one tap per appearance
        val w = WatchState()
        val ev = run(w, "###.....###....###")
        assertEquals(3, ev.count { it == WatchEvent.TAP })
        assertEquals(3, w.taps)
        assertEquals(WatchEvent.TAP, ev[0])
        assertEquals(WatchEvent.TAP, ev[8])
        assertEquals(WatchEvent.TAP, ev[15])
    }

    @Test
    fun nothingVisibleMeansNoTaps() {
        val w = WatchState()
        val ev = run(w, "..........")
        assertTrue(ev.all { it == WatchEvent.NONE })
        assertEquals(0, w.taps)
        assertTrue(w.armed)
    }

    @Test
    fun oneMissedLookDoesNotCauseADoubleTap() {
        // a single blurry frame while the image is still there must not re-arm
        val ev = run(WatchState(goneScans = 2), "####.####")
        assertEquals(1, ev.count { it == WatchEvent.TAP })
        // two misses in a row do count as gone
        val ev2 = run(WatchState(goneScans = 2), "###..###")
        assertEquals(2, ev2.count { it == WatchEvent.TAP })
        assertEquals(WatchEvent.GONE, ev2[4])
    }

    @Test
    fun againRetapsWhileItStays() {
        val w = WatchState(againMs = 1000)
        val ev = run(w, "##########")
        // tap at 0 ms, again at 1050, 2100, 3150 (every 3rd look of 350 ms)
        assertEquals(WatchEvent.TAP, ev[0])
        assertEquals(3, ev.count { it == WatchEvent.RETAP })
        assertEquals(4, w.taps)
    }

    @Test
    fun armedStateIsReported() {
        val w = WatchState()
        assertTrue(w.armed)
        w.update(true, 0)
        assertFalse(w.armed)
        assertTrue(w.visible)
        w.update(false, 350)
        w.update(false, 700)
        assertTrue(w.armed)
    }

    @Test
    fun watchStepSyntax() {
        val s = StepParser.parse("watch coin thr=0.8 again=2000")
        assertEquals(Op.WATCH, s.op)
        assertEquals("coin", s.tpl)
        assertEquals(0.8, s.thr!!, 1e-9)
        assertEquals(2000L, s.again)
        assertEquals(500L, s.after)
        assertTrue(s.isImage)
        for (l in listOf("watch coin", "watch coin thr=0.8 again=2000", "watch gem dx=5 roi=0,0,100,200 after=800")) {
            assertEquals(l, StepParser.parse(l).toLine())
        }
    }

    @Test
    fun watchRejectsOptionsThatMakeNoSense() {
        for (l in listOf("watch coin timeout=500", "watch coin skip", "tap coin again=100", "watch", "watch a b", "watch coin again=-5", "watch coin ms=10")) {
            try {
                StepParser.parse(l)
                throw AssertionError("should reject: $l")
            } catch (e: IllegalArgumentException) {
                // expected
            }
        }
    }

    @Test
    fun sequenceKinds() {
        val w = StepParser.parse("watch coin")
        val t = StepParser.parse("tap coin")
        assertEquals(SeqKind.EMPTY, SeqKind.of(emptyList()))
        assertEquals(SeqKind.WATCH, SeqKind.of(listOf(w, w.copy(tpl = "gem"))))
        assertEquals(SeqKind.STEPS, SeqKind.of(listOf(t)))
        assertEquals(SeqKind.MIXED, SeqKind.of(listOf(w, t)))
        // a saved watch sequence loads back as a watch sequence
        val (steps, errors) = StepParser.parseScript("watch coin\nwatch gem again=3000\n")
        assertTrue(errors.isEmpty())
        assertEquals(SeqKind.WATCH, SeqKind.of(steps))
    }
}
