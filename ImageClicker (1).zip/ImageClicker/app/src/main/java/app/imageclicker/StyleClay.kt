package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * CLAY: soft, puffy 3D buttons in pastel clay. They drop in with gravity and squash when they
 * land, jiggle when pressed (squash and stretch on stiff, under-damped springs), and the selected
 * one inflates while the others deflate a little. Thick rounded lowercase type pressed into the clay.
 */
class ClayCanvas : StyleCanvas() {
    private val fall = ArrayList<Spring>()
    private val sx = ArrayList<Spring>()
    private val sy = ArrayList<Spring>()
    private val puff = ArrayList<Spring>()
    private var landed = BooleanArray(0)
    private var cols = 2
    private var bw = 0f
    private var bh = 0f
    private var gap = 0f

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val light = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }
    private val rc = RectF()

    private val pastels = intArrayOf(
        0xFFFFB5C2.toInt(), 0xFFFFD6A5.toInt(), 0xFFFDFFB6.toInt(), 0xFFCAFFBF.toInt(), 0xFF9BF6FF.toInt(),
        0xFFA0C4FF.toInt(), 0xFFBDB2FF.toInt(), 0xFFFFC6FF.toInt(), 0xFFE4C1F9.toInt(), 0xFFB9FBC0.toInt()
    )

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (fall.size < n) fall.add(Spring(1f, 260f, 0.5f))
        while (sx.size < n) sx.add(Spring(1f, 700f, 0.28f))
        while (sy.size < n) sy.add(Spring(1f, 700f, 0.28f))
        while (puff.size < n) puff.add(Spring(1f, 300f, 0.45f))
        if (landed.size != n) landed = BooleanArray(n)
        if (w > 0f) onSize()
    }

    override fun onSize() {
        cols = if (w > d * 260f) 3 else 2
        val rows = (n + cols - 1) / cols
        gap = d * 12f
        bw = (w - gap * (cols + 1)) / cols
        bh = min((h - gap * (rows + 1)) / max(1, rows), bw * 0.9f)
    }

    private fun cell(i: Int, out: RectF) {
        val c = i % cols
        val r = i / cols
        val rows = (n + cols - 1) / cols
        val totalH = rows * bh + (rows - 1) * gap
        val y0 = (h - totalH) / 2f
        val x = gap + c * (bw + gap)
        val y = y0 + r * (bh + gap)
        out.set(x, y, x + bw, y + bh)
    }

    override fun onSelect(old: String?, new: String?) {
        val i = idx(new)
        if (i >= 0) {
            sx[i].kick(3f)
            sy[i].kick(-3f)
        }
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val o = open.value
        val sel = idx(selected)
        for (i in 0 until n) {
            // fall: 1 = up above the view, 0 = resting; staggered so they land one after another
            val ready = !opening || o > 0.05f + 0.6f * i / max(1, n - 1)
            fall[i].to(if (opening && ready) 0f else if (opening) fall[i].target else 1f, reduced)
            val before = fall[i].value
            fall[i].step(dt)
            if (opening && !landed[i] && before > 0.02f && fall[i].value <= 0.02f) {
                // squash on impact, proportional to the landing speed
                landed[i] = true
                val v = abs(fall[i].velocity).coerceAtMost(8f)
                sx[i].kick(v * 1.4f)
                sy[i].kick(-v * 1.8f)
            }
            if (!opening) landed[i] = false
            val pressing = i == pressed
            sx[i].to(if (pressing) 1.12f else 1f, reduced)
            sy[i].to(if (pressing) 0.84f else 1f, reduced)
            puff[i].to(if (i == sel) 1.06f else if (sel >= 0) 0.97f else 1f, reduced)
            sx[i].step(dt)
            sy[i].step(dt)
            puff[i].step(dt)
            if (!fall[i].settled || !sx[i].settled || !sy[i].settled || !puff[i].settled) moving = true
        }
        return moving
    }

    override val ambient: Boolean get() = false

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        if (fall.all { it.value > 0.99f } && open.target < 0.5f) return
        val sel = idx(selected)
        for (i in 0 until n) {
            val f = fall[i].value
            if (f > 0.99f) continue
            cell(i, rc)
            val cx = rc.centerX()
            val by = rc.bottom - f * (rc.bottom + d * 20f) // falls from above the view
            val scaleX = sx[i].value * puff[i].value
            val scaleY = sy[i].value * puff[i].value
            val bw2 = bw * scaleX
            val bh2 = bh * scaleY
            // squash keeps the bottom on the "floor"
            rc.set(cx - bw2 / 2f, by - bh2, cx + bw2 / 2f, by)
            drawClay(c, i, rc, i == sel, f)
        }
    }

    private fun drawClay(c: Canvas, i: Int, r: RectF, hot: Boolean, falling: Float) {
        val item = items[i]
        val base0 = mix(pastels[i % pastels.size], th.promptColor or (0xFF shl 24), 0.18f)
        val base = if (hot) mix(th.promptColor or (0xFF shl 24), Color.WHITE, 0.25f) else base0
        val rad = min(r.width(), r.height()) * 0.38f
        // soft drop shadow (stacked, fading) that tightens as the button nears the floor
        val sa = (1f - falling).coerceIn(0f, 1f)
        for (k in 4 downTo 1) {
            // each layer a little larger and fainter: a soft, diffuse contact shadow
            shadow.color = withAlpha(mix(base, Color.BLACK, 0.6f), (34 * sa / (k + 1)).roundToInt())
            val g = k * d * 1.6f
            c.drawRoundRect(r.left - g * 0.5f, r.top + g * 0.6f, r.right + g * 0.5f, r.bottom + g * 1.3f, rad + g, rad + g, shadow)
        }
        // body with a gentle top-left light
        body.shader = LinearGradient(r.left, r.top, r.right, r.bottom, mix(base, Color.WHITE, 0.35f), mix(base, Color.BLACK, 0.12f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, body)
        body.shader = null
        // inner highlight blob (top-left) and inner shade (bottom-right) give the puffy volume
        light.shader = RadialGradient(r.left + r.width() * 0.3f, r.top + r.height() * 0.25f, r.width() * 0.6f,
            withAlpha(Color.WHITE, 0x90), withAlpha(Color.WHITE, 0), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, light)
        dark.shader = RadialGradient(r.right - r.width() * 0.15f, r.bottom - r.height() * 0.1f, r.width() * 0.7f,
            withAlpha(mix(base, Color.BLACK, 0.5f), 0x50), withAlpha(Color.BLACK, 0), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, dark)

        val ink = mix(base, Color.BLACK, 0.62f)
        val iconSize = min(r.width(), r.height()) * 0.42f
        val iy = r.top + r.height() * 0.42f
        // pressed-in look: light edge under, dark ink on top
        Icons.draw(c, item.icon, r.centerX() + d * 0.8f, iy + d * 1f, iconSize, withAlpha(Color.WHITE, 0x90))
        Icons.draw(c, item.icon, r.centerX(), iy, iconSize, if (item.toggle && !item.on) withAlpha(ink, 0x80) else ink)
        text.textSize = min(d * 12f, r.height() * 0.2f)
        val label = fit(text, item.short.lowercase() + if (item.toggle) (if (item.on) " ●" else " ○") else "", r.width() - d * 10f)
        val ty = r.bottom - r.height() * 0.17f
        text.color = withAlpha(Color.WHITE, 0x90)
        c.drawText(label, r.centerX() + d * 0.7f, ty + d * 0.9f, text)
        text.color = ink
        c.drawText(label, r.centerX(), ty, text)
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f) return -1
        for (i in 0 until n) {
            cell(i, rc)
            rc.inset(-gap / 2f, -gap / 2f)
            if (rc.contains(x, y)) return i
        }
        return -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        cell(i, out)
        return true
    }

    override fun onUp(i: Int, click: Boolean) {
        if (i >= 0) {
            // release: spring back past the rest shape (stretch), then settle
            sx[i].kick(-4f)
            sy[i].kick(5f)
        }
        super.onUp(i, click)
    }
}
