package app.imageclicker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

class ClickerSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Default match threshold (0..1) for image steps without thr=. */
    var thr: Double
        get() = sp.getFloat("thr", 0.90f).toDouble()
        set(v) { sp.edit().putFloat("thr", v.toFloat()).apply() }

    /** Delay between screenshots while waiting for an image. */
    var pollMs: Long
        get() = sp.getLong("poll", 350L)
        set(v) { sp.edit().putLong("poll", v).apply() }

    /** Pause between loops of a sequence. */
    var loopDelayMs: Long
        get() = sp.getLong("loopdelay", 500L)
        set(v) { sp.edit().putLong("loopdelay", v).apply() }

    /** Index into Themes.all (the ◐ button cycles it). */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** Project label in the top-left (true) or top-right (false) corner. */
    var labelLeft: Boolean
        get() = sp.getBoolean("labelLeft", false)
        set(v) { sp.edit().putBoolean("labelLeft", v).apply() }

    /** Only the small run bar instead of the menu. */
    var miniMode: Boolean
        get() = sp.getBoolean("mini", false)
        set(v) { sp.edit().putBoolean("mini", v).apply() }

    /** Night mode: auto-start run inf at [nightStart] and restart it after failures until [nightEnd]. */
    var nightOn: Boolean
        get() = sp.getBoolean("night", false)
        set(v) { sp.edit().putBoolean("night", v).apply() }

    /** Minutes after midnight. */
    var nightStart: Int
        get() = sp.getInt("nightStart", 22 * 60)
        set(v) { sp.edit().putInt("nightStart", v).apply() }

    var nightEnd: Int
        get() = sp.getInt("nightEnd", 8 * 60)
        set(v) { sp.edit().putInt("nightEnd", v).apply() }

    /** Pause before night mode restarts a run that stopped. */
    var restartDelayMs: Long
        get() = sp.getLong("restartDelay", 3000L)
        set(v) { sp.edit().putLong("restartDelay", v).apply() }

    /** Id of the menu style (see StyleFactory). Unknown ids fall back to the default. */
    var menuStyle: String
        get() = sp.getString("menuStyle", StyleFactory.DEFAULT) ?: StyleFactory.DEFAULT
        set(v) { sp.edit().putString("menuStyle", v).apply() }

    /** Calm motion: menus snap instead of animating (on top of the system "remove animations" setting). */
    var calmMotion: Boolean
        get() = sp.getBoolean("calmMotion", false)
        set(v) { sp.edit().putBoolean("calmMotion", v).apply() }

    /** Flash a red box where a tap lands. */
    var marks: Boolean
        get() = sp.getBoolean("marks", false)
        set(v) { sp.edit().putBoolean("marks", v).apply() }
}

class Store(ctx: Context) {
    val root: File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    private val tplDir = File(root, "templates").apply { mkdirs() }
    private val seqDir = File(root, "sequences").apply { mkdirs() }
    private val cache = HashMap<String, Bitmap>()

    // ---- templates ----
    fun tplNames(): List<String> =
        (tplDir.listFiles() ?: emptyArray()).filter { it.extension == "png" }.map { it.nameWithoutExtension }.sorted()

    @Synchronized
    fun tpl(name: String): Bitmap? {
        cache[name]?.let { return it }
        val f = File(tplDir, "$name.png")
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        cache[name] = b
        return b
    }

    @Synchronized
    fun saveTpl(name: String, bmp: Bitmap) {
        File(tplDir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        cache.remove(name)
    }

    @Synchronized
    fun delTpl(name: String): Boolean {
        cache.remove(name)
        return File(tplDir, "$name.png").delete()
    }

    // ---- sequences (plain text, one step per line) ----
    fun seqNames(): List<String> =
        (seqDir.listFiles() ?: emptyArray()).filter { it.extension == "seq" }.map { it.nameWithoutExtension }
            .filter { it != "current" }.sorted()

    fun saveSeq(name: String, steps: List<Step>) {
        File(seqDir, "$name.seq").writeText(steps.joinToString("\n") { it.toLine() } + "\n")
    }

    /** Returns steps + parse errors, or null if the file does not exist. */
    fun loadSeq(name: String): Pair<List<Step>, List<String>>? {
        val f = File(seqDir, "$name.seq")
        if (!f.exists()) return null
        return StepParser.parseScript(f.readText())
    }

    fun delSeq(name: String): Boolean = File(seqDir, "$name.seq").delete()

    // ---- error log + time log (plain text files next to the sequences) ----
    private val errFile = File(root, "errors.log")
    private val timeFile = File(root, "times.log")

    @Synchronized
    private fun append(f: File, line: String) {
        try {
            f.appendText(line + "\n")
            if (f.length() > 120_000) f.writeText(f.readLines().takeLast(600).joinToString("\n") + "\n")
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun tail(f: File, n: Int): List<String> =
        try {
            if (f.exists()) f.readLines().filter { it.isNotBlank() }.takeLast(n) else emptyList()
        } catch (_: Exception) {
            emptyList()
        }

    fun appendError(line: String) = append(errFile, line)
    fun errors(n: Int): List<String> = tail(errFile, n)
    fun clearErrors() { errFile.delete() }
    fun appendTime(line: String) = append(timeFile, line)
    fun times(n: Int): List<String> = tail(timeFile, n)
    fun clearTimes() { timeFile.delete() }
}
