package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * NEON CYBERPUNK: a vertical rail of slanted blades with neon outlines. It "boots" with a glitch
 * burst (sliced bands jump sideways, RGB-split text), keeps faint scanlines and a flickering neon
 * edge, and a HUD bracket slides to the selected blade. Drag to scroll if the list is taller than
 * the rail. Android 13+ adds a real AGSL glitch/scanline pass over the whole rail.
 */
class NeonCanvas : StyleCanvas() {
    private val bracket = Spring(0f, 300f, 0.55f, 0.5f)
    private val scroll = Spring(0f, 180f, 0.9f, 0.5f)
    private val slide = ArrayList<Spring>()
    private val jolt = ArrayList<Spring>()
    private var glitchAt = -10f
    private var now = 0f
    private var itemH = 0f
    private var top = 0f
    private var lastSel = -1

    private val bg = Paint()
    private val stripe = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val blade = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        letterSpacing = 0.1f
    }
    private val fade = Paint()
    private val scan = Paint()
    private val path = Path()
    private val tmp = RectF()

    private val n get() = items.size
    private val neon: Int get() = th.promptColor
    private val neon2: Int get() = th.glowColor or (0xFF shl 24)

    override val viewEffect: String get() = Agsl.GLITCH

    override fun effectAmount(t: Float): Float = 0.12f + glitchAmount(t)

    private fun glitchAmount(t: Float): Float = if (reduced) 0f else exp(-(t - glitchAt) * 7f).coerceIn(0f, 1f)

    override fun onItems(old: List<MenuItem>) {
        while (slide.size < n) slide.add(Spring(0f, 260f, 0.72f))
        while (jolt.size < n) jolt.add(Spring(0f, 900f, 0.3f, 0.3f))
        if (w > 0f) onSize()
    }

    override fun onSize() {
        top = d * 6f
        itemH = max(d * 44f, (h - top * 2f) / max(1, n))
        bg.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(withAlpha(Color.BLACK, 0xE0), withAlpha(mix(Color.BLACK, neon, 0.12f), 0xD0)), null, Shader.TileMode.CLAMP)
    }

    private val maxScroll: Float get() = max(0f, top * 2f + itemH * n - h)

    private fun itemTop(i: Int): Float = top + i * itemH - scroll.value

    override fun onSelect(old: String?, new: String?) {
        glitchAt = now
    }

    override fun update(dt: Float, t: Float): Boolean {
        now = t
        var moving = super.update(dt, t)
        val o = open.value
        val opening = open.target > 0.5f
        if (opening && o < 0.3f && t - glitchAt > 0.6f) glitchAt = t
        for (i in 0 until n) {
            val ready = !opening || o > 0.08f + 0.5f * i / max(1, n - 1)
            slide[i].to(if (opening && ready) 1f else if (opening) slide[i].target else 0f, reduced)
            slide[i].step(dt)
            jolt[i].step(dt)
            if (!slide[i].settled || !jolt[i].settled) moving = true
        }
        val sel = idx(selected).let { if (it < 0) lastSel.coerceAtLeast(0) else it }
        bracket.to(itemTop(sel) + scroll.value + itemH / 2f, reduced)
        bracket.step(dt)
        scroll.step(dt)
        if (!bracket.settled || !scroll.settled) moving = true
        return moving || glitchAmount(t) > 0.01f
    }

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value.coerceIn(0f, 1f)
        if (o < 0.01f && open.target < 0.5f) return
        val g = glitchAmount(t)
        val rnd = Random((t * 14f).toInt())

        // panel body with faint hazard stripes
        c.save()
        c.clipRect(0f, 0f, w * MotionMath.easeOutCubic(o), h)
        c.drawRect(0f, 0f, w, h, bg)
        stripe.strokeWidth = d * 6f
        stripe.color = withAlpha(neon, 0x0E)
        var sx = -h
        while (sx < w) {
            c.drawLine(sx, h, sx + h, 0f, stripe)
            sx += d * 22f
        }
        c.restore()

        // neon edge line drawing itself downwards, with flicker
        val flick = if (reduced) 1f else 0.85f + 0.15f * (if (rnd.nextFloat() > 0.93f) 0.2f else 1f)
        edge.strokeWidth = d * 6f
        edge.color = withAlpha(neon, (0x30 * flick).roundToInt())
        c.drawLine(w - d * 2f, 0f, w - d * 2f, h * o, edge)
        edge.strokeWidth = d * 1.6f
        edge.color = withAlpha(neon, (0xFF * flick).roundToInt())
        c.drawLine(w - d * 2f, 0f, w - d * 2f, h * o, edge)

        // blades
        c.save()
        c.clipRect(0f, 0f, w, h)
        val sel = idx(selected)
        for (i in 0 until n) {
            val y0 = itemTop(i)
            if (y0 > h || y0 + itemH < 0f) continue
            val sp = slide[i].value
            if (sp < 0.01f) continue
            var off = (1f - sp) * -w + jolt[i].value * d * 3f
            if (g > 0.05f && rnd.nextFloat() < g * 0.35f) off += (rnd.nextFloat() - 0.5f) * d * 26f * g
            drawBlade(c, i, off, y0, i == sel || i == pressed, sp, g, rnd)
        }
        c.restore()

        // fades hint that the rail scrolls
        val ms = maxScroll
        if (ms > 0f) {
            if (scroll.value < ms - d * 2f) {
                fade.shader = LinearGradient(0f, h - d * 28f, 0f, h, 0, withAlpha(Color.BLACK, 0xE0), Shader.TileMode.CLAMP)
                c.drawRect(0f, h - d * 28f, w, h, fade)
                Icons.draw(c, Icon.HIDE, w / 2f, h - d * 9f, d * 12f, withAlpha(neon, 0xC0))
            }
            if (scroll.value > d * 2f) {
                fade.shader = LinearGradient(0f, 0f, 0f, d * 28f, withAlpha(Color.BLACK, 0xE0), 0, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, d * 28f, fade)
            }
        }

        // HUD bracket at the selected blade
        if (sel >= 0) {
            val by = bracket.value - scroll.value
            val bh = itemH * 0.62f
            edge.strokeWidth = d * 2f
            edge.color = neon2
            path.reset()
            path.moveTo(d * 9f, by - bh / 2f)
            path.lineTo(d * 3f, by - bh / 2f)
            path.lineTo(d * 3f, by + bh / 2f)
            path.lineTo(d * 9f, by + bh / 2f)
            c.drawPath(path, edge)
        }

        // scanlines (the AGSL pass adds its own on Android 13+)
        if (!Agsl.on) {
            scan.color = withAlpha(Color.BLACK, 0x30)
            var y = 0f
            while (y < h) {
                c.drawRect(0f, y, w, y + d, scan)
                y += d * 3f
            }
        }
    }

    private fun drawBlade(c: Canvas, i: Int, off: Float, y0: Float, hot: Boolean, sp: Float, g: Float, rnd: Random) {
        val item = items[i]
        val skew = d * 8f
        val l = d * 12f + off
        val r = w - d * 10f + off
        val t0 = y0 + d * 4f
        val b0 = y0 + itemH - d * 4f
        path.reset()
        path.moveTo(l + skew, t0)
        path.lineTo(r, t0)
        path.lineTo(r - skew, b0)
        path.lineTo(l, b0)
        path.close()
        val a = (255 * sp).roundToInt()
        if (hot) {
            fill.shader = LinearGradient(l, 0f, r, 0f, withAlpha(neon, a), withAlpha(neon2, a), Shader.TileMode.CLAMP)
            c.drawPath(path, fill)
            fill.shader = null
        } else {
            fill.color = withAlpha(Color.BLACK, (0x90 * sp).roundToInt())
            c.drawPath(path, fill)
        }
        blade.strokeWidth = d * 5f
        blade.color = withAlpha(neon, (0x28 * sp).roundToInt())
        c.drawPath(path, blade)
        blade.strokeWidth = d * 1.2f
        blade.color = withAlpha(if (hot) Color.WHITE else neon, a)
        c.drawPath(path, blade)

        val cy = (t0 + b0) / 2f
        val ink = if (hot) withAlpha(Color.BLACK, a) else withAlpha(if (item.toggle && item.on) neon2 else th.logColor, a)
        Icons.draw(c, item.icon, l + skew + d * 12f, cy, d * 17f, ink)
        text.textSize = d * 12f
        val room = r - (l + skew + d * 26f) - skew - (if (item.toggle) d * 14f else d * 4f)
        if (text.measureText(item.short.uppercase()) > room) text.textSize = d * 10.5f
        val label = fit(text, item.short.uppercase(), room)
        val tx = l + skew + d * 26f
        val ty = mid(text, cy)
        if (g > 0.08f && !hot) {
            // chromatic split ghosts during a glitch burst
            text.color = withAlpha(0xFF2A6B, (a * 0.7f).roundToInt())
            c.drawText(label, tx - d * 2f * g, ty, text)
            text.color = withAlpha(0x22F2FF, (a * 0.7f).roundToInt())
            c.drawText(label, tx + d * 2f * g, ty, text)
        }
        text.color = ink
        c.drawText(label, tx, ty, text)
        if (item.toggle) {
            fill.color = withAlpha(if (item.on) neon2 else th.hintColor, a)
            c.drawRect(r - skew - d * 10f, cy - d * 3f, r - skew - d * 4f, cy + d * 3f, fill)
        }
        if (rnd.nextFloat() < 0.002f && !reduced) glitchAt = now
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || x < 0f || x > w) return -1
        val i = ((y - top + scroll.value) / itemH).toInt()
        return if (i in 0 until n && y >= 0f && y <= h) i else -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        val y0 = itemTop(i)
        if (y0 + itemH < 0f || y0 > h) return false
        out.set(0f, max(0f, y0), w, min(h, y0 + itemH))
        return true
    }

    override fun onDown(i: Int, x: Float, y: Float) {
        super.onDown(i, x, y)
        if (i >= 0) jolt[i].kick(-14f)
    }

    override fun activate(i: Int) {
        lastSel = i
        glitchAt = now
        super.activate(i)
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (maxScroll <= 0f || abs(dy) < abs(dx)) return false
        scroll.snap((scroll.value - dy).coerceIn(-d * 40f, maxScroll + d * 40f))
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        val target = (scroll.value - vy * 0.25f).coerceIn(0f, maxScroll)
        scroll.to(target, reduced)
    }
}
