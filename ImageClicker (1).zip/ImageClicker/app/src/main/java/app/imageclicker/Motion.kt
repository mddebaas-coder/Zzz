package app.imageclicker

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * A damped spring. Every menu animation is built from these, so any animation can be
 * interrupted at any moment: change [target] and the motion bends toward it, keeping its velocity.
 *
 * [stiffness] ~ 100 soft .. 1500 snappy; [dampingRatio] < 1 overshoots, 1 = critically damped.
 * [eps] = how close counts as "arrived" (use ~0.001 for 0..1 values, ~0.5 for pixels).
 */
class Spring(
    initial: Float = 0f,
    var stiffness: Float = 380f,
    var dampingRatio: Float = 0.8f,
    private val eps: Float = 0.001f
) {
    var value: Float = initial
        private set
    var target: Float = initial
    var velocity: Float = 0f

    val settled: Boolean get() = abs(value - target) <= eps && abs(velocity) <= eps * 10f

    /** Advances the simulation by [dt] seconds (semi-implicit Euler in <= 8 ms sub-steps). */
    fun step(dt: Float) {
        if (settled) {
            value = target
            velocity = 0f
            return
        }
        val total = dt.coerceIn(0f, 0.064f)
        val n = ceil(total / 0.008f).toInt().coerceAtLeast(1)
        val h = total / n
        val w0 = sqrt(stiffness)
        repeat(n) {
            val a = -stiffness * (value - target) - 2f * dampingRatio * w0 * velocity
            velocity += a * h
            value += velocity * h
        }
        if (settled) {
            value = target
            velocity = 0f
        }
    }

    /** Jump straight to [v] with no motion. */
    fun snap(v: Float) {
        value = v
        target = v
        velocity = 0f
    }

    /** Animate to [t]; with [reduced] motion it jumps there instead. */
    fun to(t: Float, reduced: Boolean = false) {
        target = t
        if (reduced) snap(t)
    }

    fun kick(v: Float) {
        velocity += v
    }
}

/** Small pure helpers shared by the styles (kept free of Android types so they can be unit-tested). */
object MotionMath {
    fun clamp01(x: Float): Float = x.coerceIn(0f, 1f)

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    /** 0 before [start], 1 after [end], linear in between. */
    fun phase(x: Float, start: Float, end: Float): Float = if (end <= start) (if (x >= end) 1f else 0f) else clamp01((x - start) / (end - start))

    /** Stagger: progress of item [i] of [n] when the whole group is at [p] (0..1). */
    fun stagger(p: Float, i: Int, n: Int, spread: Float = 0.5f): Float {
        if (n <= 1) return clamp01(p)
        val start = spread * i / (n - 1)
        return phase(p, start, start + (1f - spread))
    }

    fun easeOutCubic(t: Float): Float {
        val u = 1f - clamp01(t)
        return 1f - u * u * u
    }

    fun easeOutBack(t: Float, s: Float = 1.7f): Float {
        val u = clamp01(t) - 1f
        return 1f + u * u * ((s + 1f) * u + s)
    }

    /** Wraps an angle in radians to (-PI, PI]. */
    fun wrapAngle(a: Float): Float {
        val twoPi = (2 * PI).toFloat()
        var x = a % twoPi
        if (x <= -PI) x += twoPi
        if (x > PI) x -= twoPi
        return x
    }

    /**
     * For [n] items evenly spaced on a ring rotated by [rotation] radians,
     * returns the index whose angle is closest to [focusAngle].
     */
    fun nearestOnRing(n: Int, rotation: Float, focusAngle: Float): Int {
        if (n <= 0) return -1
        val step = (2 * PI / n).toFloat()
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in 0 until n) {
            val d = abs(wrapAngle(i * step + rotation - focusAngle))
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    /** Ring rotation that puts item [i] of [n] exactly at [focusAngle], nearest to [current]. */
    fun rotationFor(n: Int, i: Int, focusAngle: Float, current: Float): Float {
        val step = (2 * PI / n).toFloat()
        val ideal = focusAngle - i * step
        return current + wrapAngle(ideal - current)
    }

    /**
     * Fan layout for a hand of [n] cards: returns the rotation (degrees) of card [i]
     * when the hand is spread by [spread] (0 = stacked, 1 = fully fanned over [maxDeg]).
     */
    fun fanAngle(n: Int, i: Int, spread: Float, maxDeg: Float): Float {
        if (n <= 1) return 0f
        val f = i / (n - 1f) - 0.5f
        return f * maxDeg * clamp01(spread)
    }

    /** Value of a slowly varying, smooth pseudo-noise in [-1, 1] (sum of sines, deterministic). */
    fun wobble(t: Float, seed: Float): Float =
        (kotlin.math.sin(t * 1.3f + seed * 3.1f) * 0.5f +
            kotlin.math.sin(t * 2.17f + seed * 5.3f) * 0.3f +
            kotlin.math.sin(t * 3.71f + seed * 1.7f) * 0.2f)

    /** Exponential approach factor for frame-rate independent smoothing. */
    fun approach(dt: Float, ratePerSecond: Float): Float = 1f - exp(-ratePerSecond * dt)
}

/** Truncates [text] with "…" so that [measure] of the result fits in [maxWidth]. */
object TextFit {
    fun fit(text: String, maxWidth: Float, measure: (String) -> Float): String {
        if (maxWidth <= 0f) return ""
        if (measure(text) <= maxWidth) return text
        if (measure("…") > maxWidth) return ""
        var lo = 0
        var hi = text.length
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (measure(text.substring(0, mid).trimEnd() + "…") <= maxWidth) lo = mid else hi = mid - 1
        }
        return text.substring(0, lo).trimEnd() + "…"
    }
}

/** Night window math (minutes after midnight), separate from Android so it can be tested. */
object NightWindow {
    fun contains(start: Int, end: Int, minute: Int): Boolean = when {
        start == end -> false
        start < end -> minute in start until end
        else -> minute >= start || minute < end
    }

    /** Parses "22:00-08:00" into minutes, or null if invalid. */
    fun parse(s: String): Pair<Int, Int>? {
        val m = Regex("^(\\d{1,2}):(\\d{2})\\s*-\\s*(\\d{1,2}):(\\d{2})$").find(s.trim()) ?: return null
        val (h1, m1, h2, m2) = m.destructured
        val a = h1.toInt()
        val b = m1.toInt()
        val c = h2.toInt()
        val e = m2.toInt()
        if (a > 23 || c > 23 || b > 59 || e > 59) return null
        return Pair(a * 60 + b, c * 60 + e)
    }
}
