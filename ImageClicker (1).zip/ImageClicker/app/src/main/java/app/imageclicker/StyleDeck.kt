package app.imageclicker

import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * CARD DECK: the menu is a hand of playing cards. It arrives as a stacked deck, then fans out.
 * Swipe sideways to rotate the hand. Pressing lifts a card; tapping flips it over in 3D and it
 * activates as it lands. The selected card stays raised. Serif card faces with corner indices.
 */
class DeckCanvas : StyleCanvas() {
    private val spread = Spring(0f, 150f, 0.72f)
    private val rise = Spring(0f, 190f, 0.8f)
    private val offset = Spring(0f, 160f, 0.85f, 0.01f)
    private val lift = ArrayList<Spring>()
    private val flip = ArrayList<Spring>()
    private var flipping = -1
    private var cw = 0f
    private var ch = 0f
    private var radius = 0f
    private var pivotX = 0f
    private var pivotY = 0f
    private val maxDeg = 64f
    private val camera = Camera()
    private val m = Matrix()

    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val back = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hatch = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val serif = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
    private val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        textAlign = Paint.Align.CENTER
    }
    private val rc = RectF()

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (lift.size < n) lift.add(Spring(0f, 320f, 0.6f))
        while (flip.size < n) flip.add(Spring(0f, 110f, 0.9f))
        if (w > 0f) onSize()
    }

    override fun onSize() {
        ch = min(h - d * 34f, d * 112f)
        cw = ch * 0.7f
        radius = max(d * 260f, w * 0.75f)
        pivotX = w / 2f
        // the centre card sits near the top; the fan droops so outer cards stay inside the view
        pivotY = ch / 2f + d * 12f + radius
    }

    /** Rotation (degrees) of card [i] in the hand right now. */
    private fun cardDeg(i: Int): Float =
        MotionMath.fanAngle(n, i, MotionMath.clamp01(spread.value), maxDeg) + offset.value * spread.value.coerceIn(0f, 1f)

    private fun liftOf(i: Int): Float {
        val sel = if (items.getOrNull(i)?.id == selected) d * 12f else 0f
        return lift[i].value * d * 20f + sel + (1f - rise.value) * (h + ch)
    }

    /** Card centre for card [i]. */
    private fun center(i: Int, out: FloatArray) {
        val a = Math.toRadians(cardDeg(i).toDouble())
        val r = radius + liftOf(i) * -1f
        out[0] = pivotX + (sin(a) * r).toFloat()
        out[1] = pivotY - (cos(a) * r).toFloat()
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val o = open.value
        val opening = open.target > 0.5f
        rise.to(if (opening) 1f else 0f, reduced)
        spread.to(if (opening && o > 0.35f) 1f else if (opening) spread.target else 0f, reduced)
        rise.step(dt)
        spread.step(dt)
        offset.step(dt)
        for (i in 0 until n) {
            lift[i].to(if (i == pressed) 1f else 0f, reduced)
            lift[i].step(dt)
            flip[i].step(dt)
            if (!lift[i].settled || !flip[i].settled) moving = true
        }
        // a flipped card activates when it lands face-down, then turns back over
        val f = flipping
        if (f >= 0 && flip[f].value > 0.97f && flip[f].target == 1f) {
            flip[f].to(0f, reduced)
            flipping = -1
            super.activate(f)
        }
        if (!rise.settled || !spread.settled || !offset.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = false

    private val pt = FloatArray(2)

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        if (open.value < 0.01f && open.target < 0.5f) return
        // draw back to front: outer cards first, the centre on top; a lifted/flipping card goes last
        val order = (0 until n).sortedWith(compareBy({ it == pressed || it == flipping }, { -abs(it - (n - 1) / 2f) }))
        for (i in order) drawCard(c, i)
    }

    private fun drawCard(c: Canvas, i: Int) {
        val item = items[i]
        center(i, pt)
        val deg = cardDeg(i)
        val fl = flip[i].value.coerceIn(0f, 1f)
        val showBack = fl > 0.5f
        c.save()
        c.translate(pt[0], pt[1])
        c.rotate(deg)
        // shadow
        rc.set(-cw / 2f + d * 3f, -ch / 2f + d * 5f, cw / 2f + d * 3f, ch / 2f + d * 5f)
        shadow.color = withAlpha(Color.BLACK, 0x55)
        c.drawRoundRect(rc, d * 9f, d * 9f, shadow)
        // 3D flip around the card's vertical axis
        camera.save()
        camera.rotateY(fl * 180f)
        camera.getMatrix(m)
        camera.restore()
        c.concat(m)
        if (showBack) c.scale(-1f, 1f)
        rc.set(-cw / 2f, -ch / 2f, cw / 2f, ch / 2f)
        if (showBack) drawBack(c) else drawFace(c, item, i)
        c.restore()
    }

    private fun drawFace(c: Canvas, item: MenuItem, i: Int) {
        val hot = item.id == selected || i == pressed
        val paper = mix(Color.WHITE, th.chipBg or (0xFF shl 24), 0.1f) or (0xFF shl 24)
        val paper2 = mix(Color.WHITE, th.chipBg or (0xFF shl 24), 0.24f) or (0xFF shl 24)
        face.shader = LinearGradient(0f, -ch / 2f, 0f, ch / 2f, paper, paper2, Shader.TileMode.CLAMP)
        c.drawRoundRect(rc, d * 9f, d * 9f, face)
        face.shader = null
        edge.strokeWidth = if (hot) d * 2.4f else d * 1f
        edge.color = if (hot) th.promptColor else withAlpha(Color.BLACK, 0x40)
        c.drawRoundRect(rc, d * 9f, d * 9f, edge)
        // inner frame like a court card
        rc.inset(d * 5f, d * 5f)
        edge.strokeWidth = d * 0.8f
        edge.color = withAlpha(th.promptColor, 0x70)
        c.drawRoundRect(rc, d * 5f, d * 5f, edge)
        rc.inset(-d * 5f, -d * 5f)
        val ink = mix(th.promptColor, Color.BLACK, 0.35f)
        // corner indices
        serif.textSize = d * 10f
        serif.color = ink
        serif.textAlign = Paint.Align.LEFT
        val idx = fit(serif, item.short.uppercase(), cw * 0.6f)
        c.drawText(idx, -cw / 2f + d * 7f, -ch / 2f + d * 16f, serif)
        c.save()
        c.rotate(180f)
        c.drawText(idx, -cw / 2f + d * 7f, -ch / 2f + d * 16f, serif)
        c.restore()
        // centre pip = the icon
        Icons.draw(c, item.icon, 0f, -ch * 0.05f, cw * 0.48f, if (item.toggle && !item.on) withAlpha(ink, 0x80) else ink)
        name.textSize = d * 9.5f
        name.color = withAlpha(Color.BLACK, 0xB0)
        c.drawText(fit(name, item.label, cw - d * 12f), 0f, ch * 0.3f, name)
        if (item.toggle) {
            name.color = if (item.on) th.promptColor else withAlpha(Color.BLACK, 0x70)
            name.textSize = d * 8f
            c.drawText(if (item.on) "on" else "off", 0f, ch * 0.3f + d * 11f, name)
        }
    }

    private fun drawBack(c: Canvas) {
        back.color = mix(th.promptColor, Color.BLACK, 0.25f) or (0xFF shl 24)
        c.drawRoundRect(rc, d * 9f, d * 9f, back)
        c.save()
        c.clipRect(rc.left + d * 5f, rc.top + d * 5f, rc.right - d * 5f, rc.bottom - d * 5f)
        hatch.strokeWidth = d * 1f
        hatch.color = withAlpha(Color.WHITE, 0x40)
        var x = -ch
        while (x < ch) {
            c.drawLine(x, -ch / 2f, x + ch, ch / 2f, hatch)
            c.drawLine(x + ch, -ch / 2f, x, ch / 2f, hatch)
            x += d * 9f
        }
        c.restore()
        edge.strokeWidth = d * 1.5f
        edge.color = withAlpha(Color.WHITE, 0xC0)
        c.drawRoundRect(rc, d * 9f, d * 9f, edge)
        serif.textAlign = Paint.Align.CENTER
        serif.textSize = d * 22f
        serif.color = Color.WHITE
        c.drawText("◆", 0f, mid(serif, 0f), serif)
    }

    /** Hit test in each card's own rotated frame, topmost first. */
    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || n == 0) return -1
        val order = (0 until n).sortedWith(compareBy({ it == pressed || it == flipping }, { -abs(it - (n - 1) / 2f) })).reversed()
        for (i in order) {
            center(i, pt)
            val a = Math.toRadians(-cardDeg(i).toDouble())
            val dx = x - pt[0]
            val dy = y - pt[1]
            val lx = (dx * cos(a) - dy * sin(a)).toFloat()
            val ly = (dx * sin(a) + dy * cos(a)).toFloat()
            val padX = max(0f, (d * 48f - cw) / 2f)
            if (abs(lx) <= cw / 2f + padX && abs(ly) <= ch / 2f) return i
        }
        return -1
    }

    /**
     * Cards overlap, so report the part of each card that is actually visible (the strip on its
     * outer side that its neighbours do not cover); TalkBack highlights and taps land there.
     */
    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        center(i, pt)
        val cx0 = pt[0]
        val cy0 = pt[1]
        val a = Math.toRadians(cardDeg(i).toDouble())
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        val side = if (i < (n - 1) / 2f) -1f else 1f
        for (k in 0..8) {
            val lx = side * (cw * 0.4f - k * cw * 0.1f)
            for (ly in floatArrayOf(-ch * 0.3f, 0f, ch * 0.3f)) {
                val x = cx0 + lx * ca - ly * sa
                val y = cy0 + lx * sa + ly * ca
                if (hit(x, y) == i) {
                    val r = d * 18f
                    out.set(x - r, y - r, x + r, y + r)
                    return true
                }
            }
        }
        val r = max(cw, ch) / 2f
        out.set(cx0 - cw / 2f, cy0 - r, cx0 + cw / 2f, cy0 + r)
        return true
    }

    override fun onUp(i: Int, click: Boolean) {
        pressed = -1
        if (!click || i < 0) return
        if (reduced) {
            super.activate(i)
            return
        }
        // a new tap interrupts any card still flipping: it turns back and the new one flips
        val f = flipping
        if (f >= 0 && f != i) flip[f].to(0f)
        flipping = i
        flip[i].to(1f)
        kit.haptic(Haptic.PRESS)
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (abs(dx) < abs(dy) * 1.2f) return false
        val degPerPx = maxDeg / max(1f, w)
        offset.snap((offset.value + dx * degPerPx * 0.9f).coerceIn(-maxDeg * 0.55f, maxDeg * 0.55f))
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        val degPerPx = maxDeg / max(1f, w)
        offset.velocity = vx * degPerPx * 0.9f
        // let it drift, then spring back toward the middle so no card stays lost off-screen
        offset.to((offset.value + vx * degPerPx * 0.25f).coerceIn(-maxDeg * 0.45f, maxDeg * 0.45f), reduced)
    }
}
