package app.imageclicker

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

// =====================================================================================================
//  Shared menu model + the base class every drawn menu style extends.
//  Nothing in this file touches android.view, so styles can also be rendered off-device for previews.
// =====================================================================================================

/** One thing the menu can do. The same list feeds every style. */
class MenuItem(
    val id: String,
    val label: String,
    val short: String,
    val icon: Icon,
    val toggle: Boolean = false,
    val on: Boolean = false,
    val primary: Boolean = false
)

/** The shared menu, in the order every style shows it. */
object MenuModel {
    val ids = listOf("toggle", "thr", "snap", "tap", "hold", "log", "settings", "theme", "night", "mini", "hide")

    /** Items that switch the content area; a style may highlight the one that is showing. */
    val paneIds = setOf("log", "thr", "settings", "tap")

    /** Demo items for previews and tests (same ids, fixed state). */
    fun demo(running: Boolean = false): List<MenuItem> = ids.map { id -> item(id, running, nightOn = true, miniOn = false) }

    fun item(id: String, running: Boolean, nightOn: Boolean, miniOn: Boolean): MenuItem = when (id) {
        "toggle" -> if (running) MenuItem(id, "Stop", "stop", Icon.STOP, primary = true)
        else MenuItem(id, "Run forever", "run", Icon.LOOP, primary = true)
        "thr" -> MenuItem(id, "Thr sliders", "thr", Icon.SLIDER)
        "snap" -> MenuItem(id, "Snap image", "snap", Icon.SNAP)
        "tap" -> MenuItem(id, "Tap folder", "tap", Icon.FOLDER)
        "hold" -> MenuItem(id, "Hold a spot", "hold", Icon.HOLD)
        "log" -> MenuItem(id, "Log", "log", Icon.LIST)
        "settings" -> MenuItem(id, "Settings", "set", Icon.GEAR)
        "theme" -> MenuItem(id, "Next theme", "theme", Icon.THEME)
        "night" -> MenuItem(id, "Night mode", "night", Icon.MOON, toggle = true, on = nightOn)
        "mini" -> MenuItem(id, "Mini mode", "mini", Icon.EXPAND, toggle = true, on = miniOn)
        "hide" -> MenuItem(id, "Hide menu", "hide", Icon.HIDE)
        else -> throw IllegalArgumentException("unknown menu id $id")
    }
}

object Haptic {
    const val TICK = 1
    const val PRESS = 2
    const val CONFIRM = 3
    const val REJECT = 4
}

/** What a style needs from its host: density, colours, motion setting, haptics. */
class Kit(val d: Float, var theme: Theme, var reduced: Boolean, val sdk: Int) {
    var haptic: (Int) -> Unit = {}

    /** True when the canvas is hardware accelerated; AGSL paint shaders are only used then. */
    var hw = false
    fun dp(v: Float): Float = v * d
}

/**
 * Base class of a drawn menu style. The host view feeds it size, items, touches and time;
 * the style animates with [Spring]s and draws everything on a Canvas.
 */
abstract class StyleCanvas {
    lateinit var kit: Kit
    var w = 0f
        private set
    var h = 0f
        private set

    var items: List<MenuItem> = emptyList()
        set(v) {
            val old = field
            field = v
            onItems(old)
        }

    /** Id of the content pane showing (log / thr / settings), highlighted by styles that care. */
    var selected: String? = null
        set(v) {
            if (v == field) return
            val o = field
            field = v
            onSelect(o, v)
        }

    /** 0 = closed, 1 = open. The host moves the target; styles read [open].value. */
    val open = Spring(0f, 230f, 0.8f)
    var pressed = -1
        protected set
    var onPick: (Int) -> Unit = {}

    /** True inside the style gallery: smaller, loops its open animation, lower frame rate. */
    var preview = false

    protected val d: Float get() = kit.d
    protected val th: Theme get() = kit.theme
    protected val reduced: Boolean get() = kit.reduced

    fun size(width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        if (w > 0f && h > 0f) onSize()
    }

    open fun onSize() {}
    open fun onItems(old: List<MenuItem>) {}
    open fun onSelect(old: String?, new: String?) {}
    open fun onTheme() {}

    /** Advances springs by [dt] seconds. Returns true while anything is still moving. */
    open fun update(dt: Float, t: Float): Boolean {
        open.step(dt)
        return !open.settled
    }

    abstract fun draw(c: Canvas, t: Float)

    /** Index of the item under (x, y), or -1. Hit areas should be at least 48 dp. */
    abstract fun hit(x: Float, y: Float): Int

    /** Bounds of item [i] for accessibility tools; false if it is not on screen. */
    abstract fun itemBounds(i: Int, out: RectF): Boolean

    open fun onDown(i: Int, x: Float, y: Float) {
        pressed = i
    }

    open fun onUp(i: Int, click: Boolean) {
        pressed = -1
        if (click && i >= 0) activate(i)
    }

    /** Return true to take over a drag (spin, swipe, scroll); the press is then cancelled. */
    open fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean = false

    open fun onFling(vx: Float, vy: Float) {}

    open fun cancelPress() {
        pressed = -1
    }

    /** Default: act at once. Styles may play an animation first and call [onPick] later. */
    open fun activate(i: Int) {
        kit.haptic(Haptic.CONFIRM)
        onPick(i)
    }

    /** Keeps animating even when every spring has settled (glitch, aurora, particles idling...). */
    open val ambient: Boolean get() = true

    /** Optional AGSL effect (Android 13+) applied over everything this style draws; needs `content`. */
    open val viewEffect: String? = null

    /** Value for the effect's `amount` uniform (e.g. glitch strength) at time [t]. */
    open fun effectAmount(t: Float): Float = 1f

    // ---- drawing helpers ----

    protected fun icon(c: Canvas, item: MenuItem, cx: Float, cy: Float, size: Float, color: Int) =
        Icons.draw(c, item.icon, cx, cy, size, color)

    protected fun fit(p: Paint, s: String, maxW: Float): String = TextFit.fit(s, maxW) { p.measureText(it) }

    /** Baseline y that vertically centres text drawn with [p] on [cy]. */
    protected fun mid(p: Paint, cy: Float): Float = cy - (p.ascent() + p.descent()) / 2f

    protected fun idx(id: String?): Int = if (id == null) -1 else items.indexOfFirst { it.id == id }
}

/** A tiny 5x7 bitmap font for the Pixel Arcade style (drawn as squares, no font files needed). */
object PixelFont {
    private val glyphs: Map<Char, Array<String>> = mapOf(
        'A' to arrayOf(".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
        'B' to arrayOf("####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."),
        'C' to arrayOf(".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."),
        'D' to arrayOf("####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."),
        'E' to arrayOf("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
        'F' to arrayOf("#####", "#....", "#....", "####.", "#....", "#....", "#...."),
        'G' to arrayOf(".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"),
        'H' to arrayOf("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
        'I' to arrayOf(".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."),
        'J' to arrayOf("..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."),
        'K' to arrayOf("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"),
        'L' to arrayOf("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
        'M' to arrayOf("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"),
        'N' to arrayOf("#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"),
        'O' to arrayOf(".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
        'P' to arrayOf("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."),
        'Q' to arrayOf(".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"),
        'R' to arrayOf("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"),
        'S' to arrayOf(".####", "#....", "#....", ".###.", "....#", "....#", "####."),
        'T' to arrayOf("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
        'U' to arrayOf("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
        'V' to arrayOf("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."),
        'W' to arrayOf("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."),
        'X' to arrayOf("#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"),
        'Y' to arrayOf("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."),
        'Z' to arrayOf("#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"),
        '0' to arrayOf(".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
        '1' to arrayOf("..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."),
        '2' to arrayOf(".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
        '3' to arrayOf("####.", "....#", "....#", ".###.", "....#", "....#", "####."),
        '4' to arrayOf("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."),
        '5' to arrayOf("#####", "#....", "####.", "....#", "....#", "#...#", ".###."),
        '6' to arrayOf(".###.", "#....", "#....", "####.", "#...#", "#...#", ".###."),
        '7' to arrayOf("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."),
        '8' to arrayOf(".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."),
        '9' to arrayOf(".###.", "#...#", "#...#", ".####", "....#", "....#", ".###."),
        ' ' to arrayOf(".....", ".....", ".....", ".....", ".....", ".....", "....."),
        '-' to arrayOf(".....", ".....", ".....", "#####", ".....", ".....", "....."),
        '.' to arrayOf(".....", ".....", ".....", ".....", ".....", ".##..", ".##.."),
        ':' to arrayOf(".....", ".##..", ".##..", ".....", ".##..", ".##..", "....."),
        '!' to arrayOf("..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.."),
        '?' to arrayOf(".###.", "#...#", "....#", "...#.", "..#..", ".....", "..#.."),
        '>' to arrayOf(".#...", "..#..", "...#.", "....#", "...#.", "..#..", ".#..."),
        '<' to arrayOf("...#.", "..#..", ".#...", "#....", ".#...", "..#..", "...#."),
        '/' to arrayOf("....#", "....#", "...#.", "..#..", ".#...", "#....", "#...."),
        '*' to arrayOf(".....", "#.#.#", ".###.", "#####", ".###.", "#.#.#", "....."),
        '+' to arrayOf(".....", "..#..", "..#..", "#####", "..#..", "..#..", "....."),
        '=' to arrayOf(".....", ".....", "#####", ".....", "#####", ".....", ".....")
    )

    /** Width in pixels of [s] drawn with block size [px] (5 columns + 1 gap per char). */
    fun width(s: String, px: Float): Float = if (s.isEmpty()) 0f else (s.length * 6 - 1) * px

    fun has(c: Char): Boolean = glyphs.containsKey(c.uppercaseChar())

    /** Draws [s] (uppercased) with its top-left at (x, y). */
    fun draw(c: Canvas, s: String, x: Float, y: Float, px: Float, paint: Paint) {
        var cx = x
        for (ch in s.uppercase()) {
            val g = glyphs[ch] ?: glyphs['?']!!
            for (row in 0 until 7) {
                val line = g[row]
                for (col in 0 until 5) {
                    if (line[col] == '#') c.drawRect(cx + col * px, y + row * px, cx + (col + 1) * px, y + (row + 1) * px, paint)
                }
            }
            cx += 6 * px
        }
    }
}
