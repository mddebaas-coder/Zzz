package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * ORBITAL: items orbit a glowing core. Spin the ring with your finger (it keeps momentum, then
 * settles on the nearest item with a haptic tick). The item at the top is in focus; tap the core
 * to use it, or tap any orbiting item to swing it to the top and use it. Opening spirals the items
 * out of the core; comet trails follow fast spins. Wide-tracked "mission control" lettering.
 */
class OrbitalCanvas : StyleCanvas() {
    private var angle = 0f
    private var vel = 0f
    private var dragging = false
    private var snapping = false
    private val snap = Spring(0f, 140f, 0.78f, 0.0005f)
    private var pending = -1
    private var focus = 0
    private var lastX = 0f
    private var lastY = 0f
    private var downOnCore = false
    private val grow = ArrayList<Spring>()
    private val pulse = Spring(0f, 500f, 0.35f)
    private val focusGlow = Spring(1f, 300f, 0.6f)

    private var cx = 0f
    private var cy = 0f
    private var ringR = 0f
    private var coreR = 0f
    private var itemR = 0f
    private val focusAngle = (-PI / 2).toFloat()

    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trail = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bead = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.32f
    }
    private val arc = RectF()
    private val stars = Array(46) { FloatArray(4) }

    private val n get() = items.size
    private val step get() = (2 * PI / max(1, n)).toFloat()

    init {
        val r = Random(7)
        for (s in stars) {
            s[0] = r.nextFloat()
            s[1] = r.nextFloat()
            s[2] = 0.4f + r.nextFloat()
            s[3] = r.nextFloat() * 6f
        }
    }

    override fun onSize() {
        cx = w / 2f
        cy = h / 2f
        val s = min(w, h)
        ringR = s / 2f - d * 34f
        coreR = s * 0.15f
        itemR = min(d * 20f, ringR * 2.2f / max(1, n))
        disc.shader = RadialGradient(
            cx, cy, s / 2f,
            intArrayOf(mix(th.menuBg, th.promptColor, 0.22f) or (0xFF shl 24), withAlpha(th.menuBg, 0xF2), withAlpha(th.menuBg, 0xFA)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onTheme() {
        if (w > 0f) onSize()
    }

    override fun onItems(old: List<MenuItem>) {
        while (grow.size < n) grow.add(Spring(0f, 170f, 0.7f))
        if (old.isEmpty() && n > 0) {
            // start with the first item (run / stop) in focus at the top
            angle = MotionMath.rotationFor(n, 0, focusAngle, 0f)
            snap.snap(angle)
            focus = 0
        }
    }

    private fun itemAngle(i: Int, o: Float): Float = i * step + angle - (1f - o) * 2.4f

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val o = open.value
        val opening = open.target > 0.5f
        for (i in 0 until n) {
            val ready = !opening || o > 0.1f + 0.45f * i / max(1, n - 1)
            grow[i].to(if (opening && ready) 1f else if (opening) grow[i].target else 0f, reduced)
            grow[i].step(dt)
            if (!grow[i].settled) moving = true
        }
        if (!dragging) {
            if (abs(vel) > 0.9f && !reduced) {
                angle += vel * dt
                vel *= exp(-2.6f * dt)
                snapping = false
                moving = true
            } else {
                vel = 0f
                if (!snapping) {
                    snapping = true
                    snap.snap(angle)
                    val target = if (pending >= 0) pending else MotionMath.nearestOnRing(n, angle, focusAngle)
                    snap.target = MotionMath.rotationFor(n, target.coerceAtLeast(0), focusAngle, angle)
                    if (reduced) snap.snap(snap.target)
                }
                snap.step(dt)
                angle = snap.value
                if (!snap.settled) moving = true
                // act as soon as the item has swung into place (about 4 degrees off); the ring keeps settling
                if (pending >= 0 && abs(snap.value - snap.target) < 0.07f) {
                    val p = pending
                    pending = -1
                    super.activate(p)
                }
            }
        }
        val f = MotionMath.nearestOnRing(n, angle, focusAngle)
        if (f != focus && f >= 0) {
            focus = f
            focusGlow.snap(0f)
            if (open.value > 0.5f) kit.haptic(Haptic.TICK)
        }
        focusGlow.to(1f, reduced)
        focusGlow.step(dt)
        pulse.step(dt)
        if (!focusGlow.settled || !pulse.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value.coerceIn(0f, 1.15f)
        if (o < 0.01f && open.target < 0.5f) return
        val oc = o.coerceAtMost(1f)
        val accent = th.promptColor

        // the disc
        val discR = (min(w, h) / 2f - d * 2f) * MotionMath.easeOutBack(oc, 1.2f)
        c.drawCircle(cx, cy, discR, disc)
        rim.strokeWidth = d * 1.2f
        rim.color = withAlpha(th.chipStroke, (0xB0 * oc).roundToInt())
        c.drawCircle(cx, cy, discR, rim)

        // stars
        for (s in stars) {
            val sx = cx + (s[0] - 0.5f) * discR * 1.7f
            val sy = cy + (s[1] - 0.5f) * discR * 1.7f
            if (hypot(sx - cx, sy - cy) > discR - d * 6f) continue
            val tw = if (reduced) 0.6f else 0.35f + 0.65f * (0.5f + 0.5f * sin(t * 1.6f + s[3]))
            dot.color = withAlpha(Color.WHITE, (150 * tw * oc).roundToInt())
            c.drawCircle(sx, sy, s[2] * d * 0.8f, dot)
        }

        // orbit rings with slowly travelling dots
        rim.strokeWidth = d
        rim.color = withAlpha(th.logColor, (0x30 * oc).roundToInt())
        c.drawCircle(cx, cy, ringR, rim)
        c.drawCircle(cx, cy, ringR * 0.6f, rim)
        for (k in 0 until 60) {
            val a = k * 0.1047f + t * 0.12f
            dot.color = withAlpha(th.logColor, (0x55 * oc).roundToInt())
            c.drawCircle(cx + cos(a) * ringR, cy + sin(a) * ringR, d * 0.9f, dot)
        }

        // comet trails while spinning
        val speed = abs(vel) + abs(snap.velocity) * 0.5f
        if (speed > 0.5f && !reduced && oc > 0.97f && grow.all { it.settled }) {
            val len = (speed * 9f).coerceAtMost(55f)
            val dir = if (vel + snap.velocity >= 0f) -1f else 1f
            arc.set(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
            trail.strokeWidth = itemR * 1.1f
            for (i in 0 until n) {
                val a = Math.toDegrees(itemAngle(i, 1f).toDouble()).toFloat()
                trail.color = withAlpha(accent, 0x24)
                c.drawArc(arc, a, dir * len, false, trail)
            }
        }

        // focus marker at the top of the ring
        rim.strokeWidth = d * 2f
        rim.color = withAlpha(accent, (0xC0 * oc).roundToInt())
        c.drawLine(cx, cy - ringR - itemR - d * 10f, cx, cy - ringR - itemR - d * 3f, rim)

        // orbiting beads
        for (i in 0 until n) {
            val g = grow[i].value
            if (g < 0.02f) continue
            val a = itemAngle(i, g)
            val r = ringR * g
            val x = cx + cos(a) * r
            val y = cy + sin(a) * r
            val isFocus = i == focus
            val sc = (if (isFocus) 1f + 0.3f * focusGlow.value else 1f) * (if (i == pressed) 0.85f else 1f) * g.coerceAtMost(1.1f)
            val br = itemR * sc
            if (isFocus) {
                bead.color = withAlpha(accent, 0x40)
                c.drawCircle(x, y, br + d * 7f, bead)
            }
            bead.color = if (isFocus) accent else withAlpha(th.chipBg, 0xF0)
            c.drawCircle(x, y, br, bead)
            rim.strokeWidth = d * 1.2f
            rim.color = if (isFocus) Color.WHITE else th.chipStroke
            c.drawCircle(x, y, br, rim)
            val ink = if (isFocus) Color.WHITE else if (items[i].toggle && items[i].on) accent else th.chipText
            Icons.draw(c, items[i].icon, x, y, br * 1.05f, ink)
        }

        // the core: shows the item in focus
        val pr = 1f + 0.12f * pulse.value + (if (reduced) 0f else 0.03f * sin(t * 2.2f))
        val cr = coreR * MotionMath.easeOutBack(oc, 1.6f) * pr
        if (cr > 1f) {
            core.shader = RadialGradient(
                cx - cr * 0.3f, cy - cr * 0.35f, cr * 1.4f,
                intArrayOf(mix(accent, Color.WHITE, 0.45f), accent, mix(accent, Color.BLACK, 0.55f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            bead.color = withAlpha(accent, 0x38)
            c.drawCircle(cx, cy, cr + d * 10f, bead)
            c.drawCircle(cx, cy, cr, core)
            val fItem = items[focus.coerceIn(0, n - 1)]
            Icons.draw(c, fItem.icon, cx, cy - cr * 0.12f, cr * 0.85f, Color.WHITE)
            label.textSize = d * 8.5f
            label.color = withAlpha(Color.WHITE, (0xE0 * oc).roundToInt())
            c.drawText(fit(label, fItem.short.uppercase(), cr * 1.6f), cx, cy + cr * 0.62f, label)
        }
        // full name in the inner ring, under the core
        label.textSize = d * 9f
        label.color = withAlpha(th.menuText, (0xD0 * oc).roundToInt())
        val item = items[focus.coerceIn(0, n - 1)]
        val name = item.label.uppercase() + if (item.toggle) (if (item.on) " · ON" else " · OFF") else ""
        c.drawText(fit(label, name, ringR * 1.15f), cx, cy + coreR + d * 20f, label)
    }

    private fun beadCenter(i: Int, out: FloatArray) {
        val a = itemAngle(i, grow.getOrNull(i)?.value ?: 1f)
        out[0] = cx + cos(a) * ringR
        out[1] = cy + sin(a) * ringR
    }

    private val pt = FloatArray(2)

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || n == 0) return -1
        if (hypot(x - cx, y - cy) < coreR * 1.15f) return focus
        val touch = max(itemR * 1.4f, d * 24f)
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in 0 until n) {
            beadCenter(i, pt)
            val dd = hypot(x - pt[0], y - pt[1])
            if (dd < touch && dd < bestD) {
                bestD = dd
                best = i
            }
        }
        return best
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        beadCenter(i, pt)
        val half = max(itemR * 1.3f, d * 24f)
        out.set(pt[0] - half, pt[1] - half, pt[0] + half, pt[1] + half)
        return true
    }

    override fun onDown(i: Int, x: Float, y: Float) {
        super.onDown(i, x, y)
        downOnCore = hypot(x - cx, y - cy) < coreR * 1.15f
        lastX = x
        lastY = y
        if (downOnCore) pulse.kick(6f)
    }

    override fun onUp(i: Int, click: Boolean) {
        pressed = -1
        if (!click || i < 0) return
        if (downOnCore || i == focus) {
            pulse.kick(8f)
            super.activate(i)
        } else {
            // swing the tapped item to the top first, then use it
            pending = i
            snapping = false
            vel = 0f
        }
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (!dragging) {
            if (hypot(lastX - cx, lastY - cy) < coreR * 0.9f) return false
            dragging = true
            pending = -1
        }
        val a1 = atan2(lastY - cy, lastX - cx)
        val a2 = atan2(y - cy, x - cx)
        angle += MotionMath.wrapAngle(a2 - a1)
        lastX = x
        lastY = y
        snapping = false
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        dragging = false
        val rx = lastX - cx
        val ry = lastY - cy
        val r2 = rx * rx + ry * ry
        vel = if (r2 > 1f) ((rx * vy - ry * vx) / r2).coerceIn(-14f, 14f) else 0f
        snapping = false
    }
}
