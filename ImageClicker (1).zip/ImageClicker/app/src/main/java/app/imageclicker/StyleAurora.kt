package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * AURORA: a night-sky curtain that descends with a wavy hem. Aurora ribbons ripple across it;
 * the items are dark glass pills, and the selection is a band of the same aurora light that flows
 * from pill to pill (its width lags behind its position, so it stretches as it travels).
 * Thin, airy uppercase type. Android 13+ renders the aurora with an AGSL shader.
 */
class AuroraCanvas : StyleCanvas() {
    private val hx = Spring(0f, 200f, 0.72f, 0.5f)
    private val hy = Spring(0f, 200f, 0.72f, 0.5f)
    private val hw = Spring(0f, 120f, 0.8f, 0.5f)
    private val glowP = ArrayList<Spring>()
    private val pills = ArrayList<RectF>()
    private var shader: Shader? = null
    private var tried = false
    private var lastPicked = 0
    private val stars = Array(40) { FloatArray(3) }

    private val sky = Paint()
    private val ribbon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val light = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-thin", Typeface.BOLD)
        letterSpacing = 0.16f
    }
    private val path = Path()
    private val clip = Path()
    private val lm = Matrix()
    private val rc = RectF()

    private val n get() = items.size

    init {
        val r = Random(21)
        for (s in stars) {
            s[0] = r.nextFloat()
            s[1] = r.nextFloat()
            s[2] = r.nextFloat() * 6f
        }
    }

    override fun onItems(old: List<MenuItem>) {
        while (glowP.size < n) glowP.add(Spring(0f, 220f, 0.7f))
        if (w > 0f) onSize()
    }

    override fun onSize() {
        // flow the pills into centred rows; a pill is at most half the width (long labels are cut with …)
        pills.clear()
        text.textSize = d * 11f
        val gap = d * 8f
        val margin = d * 12f
        val maxW = (w - margin * 2f - gap) / 2f
        val widths = items.map { min(maxW, d * 40f + text.measureText(it.short.uppercase())) }
        val rows = ArrayList<IntRange>()
        var a = 0
        var x = 0f
        for (i in 0 until n) {
            if (i > a && x + widths[i] > w - margin * 2f) {
                rows.add(a until i)
                a = i
                x = 0f
            }
            x += widths[i] + gap
        }
        if (n > 0) rows.add(a until n)
        // rows sit at the bottom of the curtain; they get slimmer if there are too many to fit
        val room = h - d * 20f
        val ph = min(d * 34f, (room - gap * (rows.size - 1)) / max(1, rows.size)).coerceAtLeast(d * 22f)
        var y = h - d * 12f - rows.size * ph - (rows.size - 1) * gap
        for (r in rows) {
            val total = r.sumOf { widths[it].toDouble() }.toFloat() + gap * (r.count() - 1)
            var px = (w - total) / 2f
            for (i in r) {
                pills.add(RectF(px, y, px + widths[i], y + ph))
                px += widths[i] + gap
            }
            y += ph + gap
        }
        sky.shader = LinearGradient(0f, 0f, 0f, h, mix(Color.BLACK, th.menuBg or (0xFF shl 24), 0.4f), th.menuBg or (0xFF shl 24), Shader.TileMode.CLAMP)
        val i = focusIndex()
        if (i >= 0) {
            hx.snap(pills[i].centerX())
            hy.snap(pills[i].centerY())
            hw.snap(pills[i].width())
        }
    }

    override fun onTheme() {
        if (w > 0f) onSize()
    }

    private fun focusIndex(): Int {
        val sel = idx(selected)
        return when {
            pressed >= 0 -> pressed
            sel >= 0 -> sel
            else -> lastPicked
        }.coerceIn(-1, n - 1)
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val o = open.value
        val f = focusIndex()
        if (f in pills.indices) {
            hx.to(pills[f].centerX(), reduced)
            hy.to(pills[f].centerY(), reduced)
            hw.to(pills[f].width(), reduced)
        }
        hx.step(dt)
        hy.step(dt)
        hw.step(dt)
        for (i in 0 until n) {
            val ready = !opening || o > 0.3f + 0.5f * i / max(1, n - 1)
            glowP[i].to(if (opening && ready) 1f else if (opening) glowP[i].target else 0f, reduced)
            glowP[i].step(dt)
            if (!glowP[i].settled) moving = true
        }
        if (!hx.settled || !hy.settled || !hw.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    /** Aurora fill: AGSL on Android 13+, otherwise a drifting multi-colour gradient. */
    private fun auroraPaint(p: Paint, t: Float, alpha: Int) {
        if (!tried && kit.hw) {
            tried = true
            shader = Agsl.make(Agsl.AURORA)
        }
        val s = shader
        val c1 = th.promptColor or (0xFF shl 24)
        val c2 = th.bubbleA or (0xFF shl 24)
        val c3 = th.bubbleB or (0xFF shl 24)
        if (s != null) {
            Agsl.float(s, "size", w, h)
            Agsl.float(s, "time", if (reduced) 0f else t)
            Agsl.color(s, "c1", c1)
            Agsl.color(s, "c2", c2)
            Agsl.color(s, "c3", c3)
            p.shader = s
        } else {
            val g = LinearGradient(0f, 0f, w * 0.7f, h * 0.3f, intArrayOf(c1, c2, c3, c1), null, Shader.TileMode.MIRROR)
            lm.setTranslate(if (reduced) 0f else (t * d * 28f) % (w * 1.4f), 0f)
            g.setLocalMatrix(lm)
            p.shader = g
        }
        p.alpha = alpha
    }

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value.coerceIn(0f, 1.1f)
        if (o < 0.01f && open.target < 0.5f) return

        // the curtain comes down with a wavy hem
        clip.reset()
        val hem = h * MotionMath.easeOutCubic(o.coerceAtMost(1f))
        clip.moveTo(0f, 0f)
        clip.lineTo(w, 0f)
        var x = w
        while (x >= 0f) {
            val wave = if (o >= 0.99f || reduced) 0f else sin(x / (d * 30f) + t * 3f) * d * 8f * (1f - o.coerceAtMost(1f))
            clip.lineTo(x, hem + wave)
            x -= d * 8f
        }
        clip.close()
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, 0f, w, h, sky)

        // stars
        for (s in stars) {
            val tw = if (reduced) 0.6f else 0.3f + 0.7f * (0.5f + 0.5f * sin(t * 1.4f + s[2]))
            dot.color = withAlpha(Color.WHITE, (140 * tw).roundToInt())
            c.drawCircle(s[0] * w, s[1] * h * 0.55f, d * 0.8f, dot)
        }

        // aurora ribbons: wavy bands of light, fading top and bottom
        for (k in 0 until 3) {
            path.reset()
            val base = h * (0.18f + 0.12f * k)
            val thick = h * (0.32f - 0.06f * k)
            var xx = -d * 10f
            path.moveTo(xx, base)
            while (xx <= w + d * 10f) {
                val y = base + sin(xx / (d * (70f + 25f * k)) + t * (0.6f + 0.2f * k) + k * 2f) * h * 0.08f
                path.lineTo(xx, y)
                xx += d * 10f
            }
            xx -= d * 10f
            while (xx >= -d * 10f) {
                val y = base + thick + sin(xx / (d * (55f + 20f * k)) + t * (0.8f + 0.15f * k) + k) * h * 0.06f
                path.lineTo(xx, y)
                xx -= d * 10f
            }
            path.close()
            auroraPaint(ribbon, t + k * 7f, (0x60 - k * 0x14))
            c.drawPath(path, ribbon)
        }
        // soft dark band behind the pills for contrast
        light.shader = LinearGradient(0f, h * 0.45f, 0f, h, 0, withAlpha(Color.BLACK, 0x90), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * 0.45f, w, h, light)
        light.shader = null

        // the flowing aurora highlight behind the focused pill
        val f = focusIndex()
        if (f >= 0 && o > 0.4f) {
            val ph = pills[f].height()
            rc.set(hx.value - hw.value / 2f, hy.value - ph / 2f, hx.value + hw.value / 2f, hy.value + ph / 2f)
            auroraPaint(light, t, 0xFF)
            c.drawRoundRect(rc, ph / 2f, ph / 2f, light)
            light.shader = null
            rim.strokeWidth = d * 1.2f
            rim.color = withAlpha(Color.WHITE, 0xB0)
            c.drawRoundRect(rc, ph / 2f, ph / 2f, rim)
        }

        // pills
        for (i in 0 until n) {
            val g = glowP[i].value.coerceIn(0f, 1f)
            if (g < 0.02f) continue
            val r = pills[i]
            rc.set(r)
            rc.offset(0f, (1f - g) * d * 14f)
            val a = (255 * g).roundToInt()
            val focused = i == f
            if (!focused) {
                pill.color = withAlpha(Color.BLACK, (0x70 * g).roundToInt())
                c.drawRoundRect(rc, rc.height() / 2f, rc.height() / 2f, pill)
                rim.strokeWidth = d * 1f
                rim.color = withAlpha(Color.WHITE, (0x40 * g).roundToInt())
                c.drawRoundRect(rc, rc.height() / 2f, rc.height() / 2f, rim)
            }
            val item = items[i]
            val ink = if (focused) Color.WHITE else if (item.toggle && item.on) th.promptColor else withAlpha(Color.WHITE, 0xD0)
            Icons.draw(c, item.icon, rc.left + d * 18f, rc.centerY(), d * 16f, withAlpha(ink, a))
            text.color = withAlpha(ink, a)
            c.drawText(fit(text, item.short.uppercase(), rc.width() - d * 40f), rc.left + d * 31f, mid(text, rc.centerY()), text)
        }
        c.restore()
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f) return -1
        for (i in 0 until n) {
            rc.set(pills[i])
            val grow = max(0f, (d * 48f - rc.height()) / 2f)
            rc.inset(-d * 3f, -grow)
            if (rc.contains(x, y)) return i
        }
        return -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in pills.indices) return false
        out.set(pills[i])
        return true
    }

    override fun activate(i: Int) {
        lastPicked = i
        super.activate(i)
    }
}
