package app.imageclicker

import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/** What the terminal needs from the overlay service. All functions are safe to call from any thread. */
interface Host {
    val store: Store
    val settings: ClickerSettings
    val runner: Runner
    fun out(s: String)
    fun capturer(): ScreenCapturer?

    /** Hides the overlay windows, waits for the screen to repaint, runs [block], then restores them. */
    suspend fun <T> withUiHidden(block: suspend () -> T): T

    /** Shows a frozen [shot] and lets the user drag a box. Returns the box in bitmap pixels or null. */
    /** Drag a box on a frozen screenshot. [hint] replaces the default instruction, [initial] = box to start from. */
    suspend fun selectRegion(shot: Bitmap, hint: String? = null, initial: Rect? = null): Rect?

    /** Lets the user tap a point on the live screen. Returns screen pixels or null if cancelled. */
    suspend fun pickPoint(): Point?

    fun mark(r: Rect)

    /** null = next theme, otherwise a theme name or its number. */
    fun switchTheme(name: String?)

    /** Moves the "martijn's project" label to the top-left (true) or top-right (false). */
    fun setLabelSide(left: Boolean)

    /** Prints the error log ("errors") or time log ("times") or clears it. */
    fun showLog(kind: String, clear: Boolean)

    /** Mini mode: only the small run bar instead of the menu. null = toggle. */
    fun setMini(on: Boolean?)

    /** Opens the threshold slider editor for the current steps. */
    fun openEditor()

    /** Night mode: "on", "off", or a window like "22:00-08:00". */
    fun setNight(arg: String)

    /** Opens the "tap" folder: saved images (tap one to watch it) and saved sequences (▶ to run). */
    fun openLibrary()

    /** Prints the report of the last crash (or clears it). */
    fun showCrash(clear: Boolean)

    /** Menu style by name or number; null / "list" prints them, "next" cycles. */
    fun setMenuStyle(name: String?)

    /** Opens the settings page (style gallery, themes, options). */
    fun openSettings()

    /** Opens the menu in the current style. */
    fun openMenu()
    fun hidePanel()
    fun clearLog()
    fun exit()
}

class Terminal(private val h: Host, private val scope: CoroutineScope) {

    private val steps = ArrayList<Step>()
    private val nameRe = Regex("^[A-Za-z0-9_-]{1,40}$")

    /** Name of the sequence last loaded or saved, so the slider editor can save back to it. */
    var seqName: String? = null
        private set

    fun stepsSnapshot(): List<Step> = steps.toList()

    /** Sets the threshold of image step [index] (0-based). null = use the default. */
    fun setStepThr(index: Int, thr: Double?) {
        if (index !in steps.indices || !steps[index].isImage) return
        steps[index] = steps[index].copy(thr = thr)
        persist()
    }

    /** Saves the current steps under [seqName]; returns the name or null if there is none yet. */
    fun saveCurrent(): String? {
        val n = seqName ?: return null
        h.store.saveSeq(n, steps)
        return n
    }

    init {
        h.store.loadSeq("current")?.let { (s, _) -> steps.addAll(s) }
    }

    fun banner() {
        h.out("Image Clicker terminal. type 'help'")
        if (steps.isNotEmpty()) h.out("restored ${steps.size} step(s) from last session")
    }

    fun exec(line: String) {
        val l = line.trim()
        if (l.isEmpty()) return
        h.out("> $l")
        val parts = l.split(Regex("\\s+"), limit = 2)
        val cmd = parts[0].lowercase()
        val rest = parts.getOrElse(1) { "" }.trim()
        try {
            dispatch(cmd, rest)
        } catch (e: IllegalArgumentException) {
            h.out("! ${e.message}")
        } catch (e: Exception) {
            h.out("! error: ${e.javaClass.simpleName}: ${e.message}")
        }
        persist()
    }

    private fun persist() {
        try {
            h.store.saveSeq("current", steps)
        } catch (_: Exception) {
        }
    }

    private fun name(s: String): String {
        if (!nameRe.matches(s)) throw IllegalArgumentException("name must be 1-40 chars: letters, digits, _ or -")
        return s
    }

    private fun index(s: String): Int {
        val i = s.toIntOrNull() ?: throw IllegalArgumentException("'$s' is not a step number")
        if (i < 1 || i > steps.size) throw IllegalArgumentException("step number must be 1..${steps.size}")
        return i
    }

    private fun warnMissing(st: Step) {
        if (st.isImage && h.store.tpl(st.tpl) == null) h.out("  note: no template '${st.tpl}' yet (use: snap ${st.tpl})")
    }

    private fun dispatch(cmd: String, rest: String) {
        when (cmd) {
            "help", "?" -> help()
            "status" -> status()

            // ---- templates ----
            "snap" -> snap(name(rest))
            "resnap" -> {
                val n = name(rest)
                val old = h.store.tpl(n)
                    ?: throw IllegalArgumentException("no image '$n' to resnap (see: tpl). use snap $n to make a new one")
                h.out("replacing '$n' (was ${old.width}x${old.height}). cancel keeps the old one")
                snap(n)
            }
            "snapxy" -> snapxy(rest)
            "tpl" -> tpl(rest)
            "find" -> find(rest)
            "area", "areas" -> area(rest)

            // ---- editing the sequence ----
            "add" -> {
                val st = StepParser.parse(rest)
                steps.add(st)
                h.out("#${steps.size} ${st.toLine()}")
                warnMissing(st)
            }
            "ins" -> {
                val p = rest.split(Regex("\\s+"), limit = 2)
                if (p.size < 2) throw IllegalArgumentException("usage: ins <n> <step>")
                val i = p[0].toIntOrNull() ?: throw IllegalArgumentException("'${p[0]}' is not a step number")
                if (i < 1 || i > steps.size + 1) throw IllegalArgumentException("n must be 1..${steps.size + 1}")
                val st = StepParser.parse(p[1])
                steps.add(i - 1, st)
                h.out("#$i ${st.toLine()}")
                warnMissing(st)
            }
            "edit" -> {
                val p = rest.split(Regex("\\s+"), limit = 2)
                if (p.size < 2) throw IllegalArgumentException("usage: edit <n> <step>")
                val i = index(p[0])
                val st = StepParser.parse(p[1])
                steps[i - 1] = st
                h.out("#$i ${st.toLine()}")
                warnMissing(st)
            }
            "del", "rm" -> {
                if (cmd == "rm" && rest.isNotEmpty() && rest.toIntOrNull() == null) {
                    // rm <name> = delete saved sequence
                    val n = name(rest)
                    h.out(if (h.store.delSeq(n)) "deleted sequence '$n'" else "no sequence '$n'")
                } else {
                    val i = index(rest)
                    val st = steps.removeAt(i - 1)
                    h.out("removed #$i ${st.toLine()}")
                }
            }
            "mv" -> {
                val p = rest.split(Regex("\\s+"))
                if (p.size != 2) throw IllegalArgumentException("usage: mv <from> <to>")
                val from = index(p[0])
                val to = index(p[1])
                steps.add(to - 1, steps.removeAt(from - 1))
                list()
            }
            "clear" -> {
                if (rest.equals("log", true)) {
                    h.clearLog()
                } else {
                    steps.clear()
                    h.out("sequence cleared")
                }
            }
            "steps", "ls", "cat" -> list()

            // ---- saved sequences ----
            "save" -> {
                val n = name(rest)
                h.store.saveSeq(n, steps)
                seqName = n
                h.out("saved '$n' (${steps.size} steps) -> ${h.store.root.absolutePath}/sequences/$n.seq")
            }
            "load" -> {
                val n = name(rest)
                val r = h.store.loadSeq(n) ?: throw IllegalArgumentException("no sequence '$n' (see: seqs)")
                steps.clear()
                steps.addAll(r.first)
                seqName = n
                r.second.forEach { h.out("  skipped $it") }
                h.out("loaded '$n' (${steps.size} steps)")
            }
            "seqs" -> {
                val l = h.store.seqNames()
                h.out(if (l.isEmpty()) "no saved sequences" else l.joinToString("  "))
            }

            // ---- running ----
            "run" -> {
                val loops = when {
                    rest.isEmpty() -> 1
                    rest.equals("inf", true) || rest.equals("forever", true) -> -1
                    else -> rest.toIntOrNull()?.takeIf { it > 0 }
                        ?: throw IllegalArgumentException("usage: run [count|inf]")
                }
                h.runner.start(steps.toList(), loops)
            }
            "stop", "release" -> h.runner.stop()
            "hold" -> hold(rest)
            "do" -> {
                val st = StepParser.parse(rest)
                warnMissing(st)
                h.runner.start(listOf(st), 1)
            }

            "theme" -> h.switchTheme(rest.ifBlank { null })
            "label" -> when (rest.lowercase()) {
                "left" -> h.setLabelSide(true)
                "right" -> h.setLabelSide(false)
                else -> throw IllegalArgumentException("usage: label left|right")
            }
            "errors" -> h.showLog("errors", rest.equals("clear", true))
            "times" -> h.showLog("times", rest.equals("clear", true))
            "mini" -> h.setMini(
                when (rest.lowercase()) {
                    "on" -> true
                    "off" -> false
                    "" -> null
                    else -> throw IllegalArgumentException("usage: mini [on|off]")
                }
            )
            "editor", "sliders" -> h.openEditor()
            "night" -> h.setNight(rest)
            "style", "styles" -> h.setMenuStyle(rest.ifBlank { null })
            "crash" -> h.showCrash(rest.equals("clear", true))
            "watch" -> watch(rest)
            "tapfolder", "library", "lib", "images" -> h.openLibrary()
            "settings" -> h.openSettings()
            "menu" -> h.openMenu()
            "set" -> set(rest)
            "hide", "min" -> h.hidePanel()
            "exit", "quit" -> h.exit()
            else -> h.out("unknown command '$cmd'. type 'help'")
        }
    }

    private fun help() {
        h.out(
            """
            -- templates --
            snap <name>          drag a box on screen to save an image
            resnap <name>        redo an existing image (steps keep working)
            snapxy <n> x y w h   save image from coordinates
            tpl | tpl rm <name>  list / delete images
            find <name> [thr=]   test-match now and mark it
            area <name>          drag a box: that image is only searched inside it (area <name> off)
            area all             drag a box for all images that have no area of their own
            area                 list the areas      area show   flash them on screen
            -- sequence --
            add <step>           append a step
            ins <n> <step>       insert before #n
            edit <n> <step>      replace #n
            del <n>   mv <a> <b>
            steps                show sequence
            clear                empty the sequence   (clear log = clear screen)
            save <n>  load <n>  seqs  rm <n>   (saved sequences)
            -- run --
            run [count|inf]      start (panel hides, tap the red ■ to stop)
            watch <img> [img..]  tap each image once every time it appears; nothing else (until ■)
            tapfolder            your saved images + sequences: tap an image to watch it, ▶ runs a sequence
            stop | release       stop the run / let go of a hold
            hold                 tap a spot, finger stays down until you tap ■
            hold <x> <y> [ms=]   hold a point now (ms=0 or none = until ■)
            hold <img> [ms=]     find the image, hold it now
            do <step>            run one step right now, e.g. do swipe 500 1500 500 500
            set thr|poll|loopdelay|marks|restartdelay|steady <v>
            editor               sliders to tune each step's thr
            errors [clear]       error log      times [clear]   time log of runs
            mini [on|off]        only the small run bar, no menu
            night [on|off|22:00-08:00]  auto run inf at night, restart if an image is not found
            theme [name|n]       next look, or pick one (◐ button does the same)
            style [name|n|next]  menu style (13 of them); style list shows all
            menu   settings      open the menu (☰) / the settings page (⚙)
            crash [clear]        why the app closed last time (if it crashed)
            label left|right     move the project label to that top corner
            status  hide  exit
            -- step syntax --
            tap <img> [thr=0.9] [timeout=ms, default waits forever] [dx= dy=] [roi=x,y,w,h] [after=300] [skip]
            waitimg <img> [..]   wait until visible
            goneimg <img> [..]   wait until gone
            hold <img> [ms=0] [..]  long press on image (ms=0 = until stopped)
            holdxy <x> <y> [ms=0]   long press on a point
            tapxy <x> <y>   swipe <x1> <y1> <x2> <y2> [ms=300]
            wait <ms>   back   home
            watch <img> [thr=] [again=ms] [after=500]   tap once per appearance (only with other watch steps)
            """.trimIndent()
        )
    }

    private fun status() {
        val a11y = ClickerAccessibilityService.instance != null
        val cap = h.capturer()
        val s = h.settings
        h.out("accessibility: ${if (a11y) "on" else "OFF"}")
        h.out("capture: ${if (cap != null) "${cap.width}x${cap.height}" else "OFF"}")
        h.out("steps: ${steps.size}   templates: ${h.store.tplNames().size}   running: ${h.runner.running}")
        h.out("thr=${fmt(s.thr)} poll=${s.pollMs}ms loopdelay=${s.loopDelayMs}ms marks=${if (s.marks) "on" else "off"}")
        h.out("files: ${h.store.root.absolutePath}")
    }

    private fun list() {
        if (steps.isEmpty()) {
            h.out("(empty) try: add tap <template>")
            return
        }
        steps.forEachIndexed { i, st -> h.out("${i + 1}. ${st.toLine()}") }
    }

    private fun set(rest: String) {
        val s = h.settings
        val p = rest.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (p.isEmpty()) {
            h.out("thr=${fmt(s.thr)} poll=${s.pollMs} loopdelay=${s.loopDelayMs} marks=${if (s.marks) "on" else "off"} steady=${if (s.steady) "on" else "off"}")
            return
        }
        if (p.size != 2) throw IllegalArgumentException("usage: set <thr|poll|loopdelay|marks|restartdelay|steady> <value>")
        when (p[0].lowercase()) {
            "thr" -> {
                val v = p[1].toDoubleOrNull()
                if (v == null || v < 0.0 || v > 1.0) throw IllegalArgumentException("thr must be 0..1")
                s.thr = v
            }
            "poll" -> s.pollMs = (p[1].toLongOrNull() ?: throw IllegalArgumentException("poll must be a number")).coerceIn(50, 10_000)
            "loopdelay" -> s.loopDelayMs = (p[1].toLongOrNull() ?: throw IllegalArgumentException("loopdelay must be a number")).coerceIn(0, 600_000)
            "marks" -> s.marks = p[1].lowercase() in setOf("on", "1", "true", "yes")
            "steady" -> {
                s.steady = p[1].lowercase() in setOf("on", "1", "true", "yes")
                h.out(if (s.steady) "steady on: an image is tapped only when it is found in the same place twice in a row"
                else "steady off: an image is tapped the first time it is found")
            }
            "restartdelay" -> s.restartDelayMs =
                (p[1].toLongOrNull() ?: throw IllegalArgumentException("restartdelay must be a number")).coerceIn(0, 600_000)
            else -> throw IllegalArgumentException("unknown setting '${p[0]}'")
        }
        h.out("ok")
    }

    /** hold                -> pick a point with a tap, then hold it
     *  hold <x> <y> [ms=]  -> hold that point
     *  hold <img> [...]    -> find the image and hold it */
    fun hold(rest: String) {
        if (h.runner.running) {
            h.out("already running (tap the red ■ to stop)")
            return
        }
        val p = rest.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (p.isEmpty()) {
            scope.launch(Dispatchers.Default) {
                try {
                    h.withUiHidden {
                        val pt = h.pickPoint()
                        if (pt == null) {
                            h.out("hold cancelled")
                        } else {
                            h.out("tip: to add this as a step type: add holdxy ${pt.x} ${pt.y}")
                            // started while the panel is still hidden, so it never covers the spot
                            h.runner.start(listOf(Step(op = Op.HOLDXY, x = pt.x, y = pt.y, ms = 0, after = 0)), 1)
                        }
                    }
                } catch (e: Exception) {
                    h.out("${ERR}hold failed: ${e.message}")
                }
            }
            return
        }
        val st = if (p.size >= 2 && p[0].toIntOrNull() != null && p[1].toIntOrNull() != null) {
            StepParser.parse("holdxy $rest")
        } else {
            StepParser.parse("hold $rest")
        }
        warnMissing(st)
        h.runner.start(listOf(st.copy(after = 0)), 1)
    }

    /** watch <img> [<img> ...] [thr=..] [again=..] : runs right away, the current steps stay as they are. */
    private fun watch(rest: String) {
        val toks = rest.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val imgs = toks.filter { '=' !in it }
        val opts = toks.filter { '=' in it }.joinToString(" ")
        if (imgs.isEmpty()) throw IllegalArgumentException("usage: watch <image> [more images] [thr=0.9] [again=ms]")
        val ws = imgs.map { StepParser.parse("watch ${name(it)} $opts") }
        ws.forEach { warnMissing(it) }
        h.runner.start(ws, -1)
    }

    /** The "tap" folder: watch these images now. */
    fun watchImages(imgs: List<String>) {
        if (imgs.isEmpty()) return
        exec("watch " + imgs.joinToString(" "))
    }

    /** The "tap" folder: save [imgs] as a watch sequence called [n]. Returns false if the name is not valid. */
    fun saveWatch(n: String, imgs: List<String>): Boolean {
        if (!nameRe.matches(n) || imgs.isEmpty()) {
            h.out("! name must be 1-40 chars: letters, digits, _ or -")
            return false
        }
        val ws = imgs.map { Step(op = Op.WATCH, tpl = it, after = defaultAfter(Op.WATCH)) }
        h.store.saveSeq(n, ws)
        h.out("saved watch sequence '$n': ${imgs.joinToString(", ")}")
        return true
    }

    /** The "tap" folder: load a saved sequence and run it ([loops] < 0 = forever; watch sequences always run until ■). */
    fun runSaved(n: String, loops: Int) {
        exec("load $n")
        if (seqName == n) exec(if (loops < 0) "run inf" else "run $loops")
    }

    private fun tpl(rest: String) {
        val p = rest.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (p.isEmpty()) {
            val names = h.store.tplNames()
            if (names.isEmpty()) {
                h.out("no templates yet. use: snap <name>")
                return
            }
            names.forEach { n ->
                val b = h.store.tpl(n)
                h.out("  $n ${if (b != null) "${b.width}x${b.height}" else "(unreadable)"}")
            }
        } else if (p[0].equals("rm", true) && p.size == 2) {
            val n = name(p[1])
            h.out(if (h.store.delTpl(n)) "deleted template '$n'" else "no template '$n'")
        } else {
            throw IllegalArgumentException("usage: tpl | tpl rm <name>")
        }
    }

    private fun saveTemplate(n: String, b: Bitmap) {
        h.store.saveTpl(n, b)
        val c = TemplateMatcher.contrast(b)
        h.out("saved '$n' ${b.width}x${b.height}")
        if (c < 12.0) h.out("  warning: this area is almost flat, it may match anywhere. include some edges/text/icon")
        if (b.width < 16 || b.height < 16) h.out("  warning: very small image, matching may be unreliable")
    }

    private fun snap(n: String) {
        val cap = h.capturer() ?: throw IllegalArgumentException("screen capture is not running")
        scope.launch(Dispatchers.Default) {
            try {
                var picked: Bitmap? = null
                h.withUiHidden {
                    val shot = cap.grab()
                    if (shot == null) {
                        h.out("could not capture the screen")
                    } else {
                        val r = h.selectRegion(shot)
                        if (r != null) picked = Bitmap.createBitmap(shot, r.left, r.top, r.width(), r.height())
                    }
                }
                val b = picked
                if (b == null) h.out("snap cancelled") else saveTemplate(n, b)
            } catch (e: Exception) {
                h.out("${ERR}snap failed: ${e.message}")
            }
        }
    }

    private fun snapxy(rest: String) {
        val p = rest.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (p.size != 5) throw IllegalArgumentException("usage: snapxy <name> <x> <y> <w> <h>")
        val n = name(p[0])
        val v = p.drop(1).map { it.toIntOrNull() ?: throw IllegalArgumentException("'$it' is not a number") }
        if (v[2] < 8 || v[3] < 8) throw IllegalArgumentException("w and h must be at least 8")
        val cap = h.capturer() ?: throw IllegalArgumentException("screen capture is not running")
        scope.launch(Dispatchers.Default) {
            try {
                val shot = h.withUiHidden { cap.grab() }
                if (shot == null) {
                    h.out("could not capture the screen")
                    return@launch
                }
                val x = v[0]
                val y = v[1]
                if (x < 0 || y < 0 || x + v[2] > shot.width || y + v[3] > shot.height) {
                    h.out("! box is outside the screen (${shot.width}x${shot.height})")
                    return@launch
                }
                saveTemplate(n, Bitmap.createBitmap(shot, x, y, v[2], v[3]))
            } catch (e: Exception) {
                h.out("${ERR}snapxy failed: ${e.message}")
            }
        }
    }

    private fun find(rest: String) {
        val st = StepParser.parse("waitimg $rest")
        val tpl = h.store.tpl(st.tpl) ?: throw IllegalArgumentException("no template '${st.tpl}' (see: tpl)")
        val cap = h.capturer() ?: throw IllegalArgumentException("screen capture is not running")
        val thr = st.thr ?: h.settings.thr
        val area = Area.pick(Area.of(st.roi), h.store.areaOf(st.tpl), h.settings.allArea)
        scope.launch(Dispatchers.Default) {
            try {
                val shot = h.withUiHidden { cap.grab() }
                if (shot == null) {
                    h.out("could not capture the screen")
                    return@launch
                }
                val roi = area?.let { Area.usable(it, tpl.width, tpl.height, shot.width, shot.height) }
                    ?.let { Rect(it.x, it.y, it.right, it.bottom) }
                if (area != null) h.out("searching only in area $area")
                val m = TemplateMatcher.find(shot, tpl, roi)
                if (m == null) {
                    h.out("template does not fit in the search area")
                    return@launch
                }
                val ok = m.score >= thr
                h.out("${st.tpl}: ${fmt(m.score)} at (${m.cx},${m.cy}) -> ${if (ok) "FOUND" else "no match"} (thr ${fmt(thr)})")
                h.mark(Rect(m.left, m.top, m.left + m.w, m.top + m.h))
            } catch (e: Exception) {
                h.out("${ERR}find failed: ${e.message}")
            }
        }
    }

    /**
     * area                  list areas            area show         flash them on screen
     * area <img>            drag a box            area all          drag the box for all images
     * area <img|all> off    remove                area <img|all> x y w h   set by numbers
     */
    private fun area(rest: String) {
        val p = rest.split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        val s = h.settings
        if (p.isEmpty() || p[0].lowercase() in setOf("list", "show")) {
            val all = s.allArea
            h.out("area for all images: ${all ?: "whole screen"}")
            val own = h.store.tplNames().mapNotNull { n -> h.store.areaOf(n)?.let { n to it } }
            if (own.isEmpty()) h.out("no image has its own area") else own.forEach { (n, a) -> h.out("  $n: $a") }
            if (p.isEmpty()) {
                h.out("drag one: area <image>   area all      remove: area <image|all> off      see them: area show")
            } else {
                all?.let { h.mark(Rect(it.x, it.y, it.right, it.bottom)) }
                own.forEach { (_, a) -> h.mark(Rect(a.x, a.y, a.right, a.bottom)) }
            }
            return
        }
        val target = if (p[0].equals("all", true)) "all" else name(p[0])
        val forAll = target == "all"
        if (!forAll && h.store.tpl(target) == null) throw IllegalArgumentException("no image '$target' (see: tpl)")
        val label = if (forAll) "all images" else "'$target'"
        fun save(a: Area?) {
            if (forAll) s.allArea = a else h.store.setArea(target, a)
            if (a == null) {
                h.out("$label: searched on the whole screen again" + if (!forAll && s.allArea != null) " (well, in the area for all images: ${s.allArea})" else "")
            } else {
                h.out("$label: only searched inside $a (x,y,w,h)")
                h.mark(Rect(a.x, a.y, a.right, a.bottom))
            }
        }
        if (p.size == 2 && p[1].lowercase() in setOf("off", "clear", "none", "rm")) {
            save(null)
            return
        }
        if (p.size > 1) {
            val a = Area.parse(p.drop(1).joinToString(","))
                ?: throw IllegalArgumentException("usage: area <image|all> [x y w h | off]")
            save(a)
            return
        }
        val cap = h.capturer() ?: throw IllegalArgumentException("screen capture is not running")
        val current = if (forAll) s.allArea else h.store.areaOf(target)
        scope.launch(Dispatchers.Default) {
            try {
                var picked: Rect? = null
                h.withUiHidden {
                    val shot = cap.grab()
                    if (shot == null) {
                        h.out("could not capture the screen")
                    } else {
                        picked = h.selectRegion(
                            shot,
                            if (forAll) "Drag the area to search in (all images)" else "Drag the area to search for $target",
                            current?.let { Rect(it.x, it.y, it.right, it.bottom) }
                        )
                    }
                }
                val r = picked
                if (r == null) h.out("area cancelled") else save(Area(r.left, r.top, r.width(), r.height()))
            } catch (e: Exception) {
                h.out("${ERR}area failed: ${e.message}")
            }
        }
    }

    private fun fmt(d: Double): String = String.format(Locale.US, "%.2f", d)
}
