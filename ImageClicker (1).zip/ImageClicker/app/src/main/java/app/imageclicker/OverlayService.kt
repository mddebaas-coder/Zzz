package app.imageclicker

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewAnimationUtils
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.min

/**
 * Foreground service that owns: screen capture, the floating bubble, the terminal panel,
 * the sequence runner. UI is built in code so the project needs no layout resources.
 */
class OverlayService : Service(), Host {

    companion object {
        const val ACTION_START = "app.imageclicker.START"
        const val ACTION_STOP_RUN = "app.imageclicker.STOP_RUN"
        const val ACTION_EXIT = "app.imageclicker.EXIT"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val PROJECT_LABEL = "martijn's project v1.8"
        private const val ERR_COLOR = 0xFFFF6B6B.toInt()
        private const val OK_COLOR = 0xFF4ADE80.toInt()
        private const val CHANNEL = "imageclicker"
        private const val NOTIF_ID = 1

        @Volatile
        var alive = false
            private set
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var wm: WindowManager
    private lateinit var imm: InputMethodManager

    override val store: Store by lazy { Store(applicationContext) }
    override val settings: ClickerSettings by lazy { ClickerSettings(applicationContext) }
    override val runner: Runner by lazy {
        Runner(scope, { cap }, store, settings, { s -> out(s) }, { r -> onRunState(r) }, { r -> mark(r) })
    }

    @Volatile private var cap: ScreenCapturer? = null
    private var term: Terminal? = null

    // views
    private lateinit var bubble: BubbleView
    private lateinit var panel: FrameLayout
    private lateinit var backdrop: ThemeBackdrop
    private lateinit var content: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var promptView: TextView
    private lateinit var themeChip: TextView
    private lateinit var label: TextView
    private lateinit var labelLp: WindowManager.LayoutParams
    private var labelAdded = false
    // style menu window (one of the 13 drawn styles, placed where that style lives on screen)
    private lateinit var menuRoot: OverlayRoot
    private lateinit var menuScrim: View
    private lateinit var menuLp: WindowManager.LayoutParams
    private var menuView: StyleView? = null
    private var menuStyleId = ""
    private var menuAdded = false
    private var menuShowing = false
    private var afterMenuClosed: (() -> Unit)? = null
    private val menuCloseTimeout = Runnable { if (!menuShowing) removeMenuWindow() }

    // settings window (style gallery with live previews, themes, options)
    private lateinit var setRoot: OverlayRoot
    private lateinit var setScrim: View
    private lateinit var setCard: FrameLayout
    private lateinit var setBackdrop: ThemeBackdrop
    private lateinit var setScroll: ScrollView
    private lateinit var setList: LinearLayout
    private lateinit var setLp: WindowManager.LayoutParams
    private var settingsAdded = false
    private var settingsWanted = false
    private var galleryCols = 0
    private val previews = ArrayList<StyleView>()
    private val tiles = ArrayList<Pair<String, View>>()

    // the "tap" folder: saved images (tap one = watch it) and saved sequences (▶ = run)
    private lateinit var libRoot: OverlayRoot
    private lateinit var libScrim: View
    private lateinit var libCard: FrameLayout
    private lateinit var libBackdrop: ThemeBackdrop
    private lateinit var libScroll: ScrollView
    private lateinit var libList: LinearLayout
    private lateinit var libLp: WindowManager.LayoutParams
    private var libAdded = false
    private var libWanted = false
    private val libSel = LinkedHashSet<String>()
    private var libName: String? = null
    private var libConfirm: String? = null
    private var libConfirmAt = 0L
    private val chips = ArrayList<TextView>()
    private var curTheme: Theme = Themes.get(0)
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    private var bubbleAdded = false
    private var panelAdded = false
    private var uiVisible = true
    private var panelWanted = true
    private var running = false
    private var finished = false

    private class LogLine(val t: Long, val s: String, val err: Boolean)

    private val logLines = ArrayDeque<LogLine>()
    private var logDirty = false
    private lateinit var clockView: TextView
    private lateinit var inputRow: LinearLayout
    private val clockFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val shortFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    // mini run bar
    private lateinit var mini: LinearLayout
    private lateinit var miniLp: WindowManager.LayoutParams
    private var miniAdded = false
    private var miniWanted = false
    private lateinit var miniRun: TextView
    private lateinit var miniTime: TextView
    private lateinit var miniStatus: TextView
    private lateinit var miniFix: TextView
    private lateinit var miniExpand: TextView
    private lateinit var miniClose: TextView
    private val miniChips = ArrayList<TextView>()
    private var miniErr = false

    // threshold slider editor
    private lateinit var editorBox: LinearLayout
    private lateinit var editorScroll: ScrollView
    private lateinit var editorList: LinearLayout
    private lateinit var editorTitle: TextView
    private var editorOpen = false
    private var editorFocus = -1

    // night mode
    private var wasInNight: Boolean? = null
    private var nightOwned = false
    private var restartPending = false
    private var restartCount = 0
    private var keepAwake = false
    private val tick = object : Runnable {
        override fun run() {
            onTick()
            if (alive && !finished) main.postDelayed(this, 1000L)
        }
    }
    private val restartRunnable = Runnable { doNightRestart() }
    private val history = ArrayList<String>()
    private var histPos = 0

    // ------------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP_RUN -> if (alive) runner.stop()
            ACTION_EXIT -> shutdown()
            else -> if (!alive) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (alive) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        // Must be foreground (type mediaProjection) before the projection token is used.
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return
        }
        try {
            val c = ScreenCapturer(this, code, data)
            c.onStopped = { main.post { out("${ERR}screen capture was stopped by the system"); shutdown() } }
            c.start()
            cap = c
        } catch (e: Exception) {
            finished = true
            android.widget.Toast.makeText(
                this, "Image Clicker: screen capture failed to start (${e.message})", android.widget.Toast.LENGTH_LONG
            ).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        alive = true
        buildUi()
        val t = Terminal(this, scope)
        term = t
        t.banner()
        CrashLog.read(this)?.let { out("${ERR}the app crashed last time: ${CrashLog.summary(it)}. type: crash") }
        if (settings.miniMode) panelWanted = false
        updateMini()
        updateKeepAwake()
        syncWindows()
        main.post(tick)
    }

    private fun shutdown() {
        if (finished) return
        finished = true
        alive = false
        try { runner.stop() } catch (_: Exception) {}
        main.removeCallbacks(tick)
        main.removeCallbacks(restartRunnable)
        main.post {
            try { removeWindows() } catch (_: Exception) {}
        }
        cap?.let { c -> c.onStopped = null; c.release() }
        cap = null
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!finished) {
            finished = true
            alive = false
            cap?.let { c -> c.onStopped = null; c.release() }
            cap = null
            scope.cancel()
            try { removeWindows() } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!alive) return
        layoutPanelSize()
        if (panelAdded) try { wm.updateViewLayout(panel, panelLp) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Image Clicker", NotificationManager.IMPORTANCE_LOW))
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Image Clicker")
            .setContentText("Overlay terminal is active")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop run", pi(ACTION_STOP_RUN, 1))
            .addAction(android.R.drawable.ic_delete, "Exit", pi(ACTION_EXIT, 2))
            .build()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun layoutPanelSize() {
        val dm = resources.displayMetrics
        panelLp.width = min(dm.widthPixels - dp(16), dp(460))
        panelLp.height = min((dm.heightPixels * 0.55).toInt(), dp(340))
    }

    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        curTheme = Themes.get(settings.theme)

        // ---- bubble ----
        bubble = BubbleView(this)
        bubbleLp = WindowManager.LayoutParams(
            dp(52), dp(52), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(220)
        }
        makeDraggable(bubble, bubbleLp, bubble) {
            if (running) {
                runner.stop()
            } else {
                panelWanted = !panelWanted
                syncWindows()
            }
        }

        // ---- panel = animated theme backdrop with the terminal on top ----
        panel = FrameLayout(this)
        backdrop = ThemeBackdrop(this)
        panel.addView(
            backdrop,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(
            content,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            pivotX = 0f
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        clockView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setSingleLine(true)
            setPadding(dp(4), 0, dp(2), 0)
        }
        header.addView(clockView)
        themeChip = chip("◐", Icon.THEME) { cycleTheme() }
        header.addView(themeChip)
        header.addView(chip("hold", Icon.HOLD) { term?.hold("") })
        header.addView(chip("tap", Icon.FOLDER) { openLibraryUi() })
        header.addView(chip("⚙", Icon.GEAR) { openSettingsUi() })
        header.addView(chip("☰", Icon.MENU) { toggleStyleMenu() })
        content.addView(header)

        logView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextIsSelectable(false)
            setLineSpacing(dp(1).toFloat(), 1f)
            setPadding(0, dp(4), 0, dp(4))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(logView)
        }
        content.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- threshold slider editor (replaces the log while open) ----
        editorTitle = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }
        val edHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(2))
        }
        edHead.addView(editorTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        edHead.addView(chip("save", Icon.SAVE) { saveFromEditor() })
        edHead.addView(chip("done", Icon.CHECK) { closeEditor() })
        editorList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        editorScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(editorList)
        }
        editorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(edHead)
            addView(editorScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        content.addView(editorBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        promptView = TextView(this).apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f) }
        input = EditText(this).apply {
            hint = "help"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            setOnEditorActionListener { _, actionId, event ->
                val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
                if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                    submit()
                    true
                } else {
                    false
                }
            }
        }
        row.addView(promptView)
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(chip("^", Icon.UP) { recall() })
        row.addView(chip("go", Icon.SEND) { submit() })
        content.addView(row)
        inputRow = row

        // ---- style menu + settings: their own full-screen windows ----
        buildMenuWindow()
        buildSettingsWindow()
        buildLibraryWindow()

        // ---- project label, always on screen while the app runs (never touchable) ----
        label = TextView(this).apply {
            text = PROJECT_LABEL
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setSingleLine(true)
            setPadding(dp(9), dp(3), dp(9), dp(3))
        }
        labelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (settings.labelLeft) Gravity.START else Gravity.END)
            x = dp(8)
            y = statusBarHeight() + dp(4)
        }

        // ---- mini run bar: run inf / stop, timer, last status, fix thr, expand ----
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        miniRun = miniChip(Icon.LOOP) {
            if (running) runner.stop() else term?.exec("run inf")
        }
        miniTime = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setSingleLine(true)
            setPadding(dp(7), 0, dp(4), 0)
        }
        miniStatus = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(170)
            setPadding(dp(2), 0, dp(6), 0)
            text = "ready"
        }
        miniFix = miniChip(Icon.SLIDER) {
            expandPanel()
            openEditorUi(runner.failIndex)
        }
        miniExpand = miniChip(Icon.EXPAND) { expandPanel() }
        miniClose = miniChip(Icon.CLOSE) {
            miniWanted = false
            syncWindows()
        }
        mini.addView(miniRun)
        mini.addView(miniTime)
        mini.addView(miniStatus)
        mini.addView(miniFix)
        mini.addView(miniExpand)
        mini.addView(miniClose)
        miniLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = statusBarHeight() + dp(34)
        }
        makeDraggable(miniStatus, miniLp, mini, null)
        makeDraggable(miniTime, miniLp, mini, null)

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(4)
            y = dp(40)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }
        layoutPanelSize()
        makeDraggable(header, panelLp, panel, null)
        applyTheme(curTheme, null)

        // replay anything logged before the views existed
        renderLog()
    }

    private class ChipSpec(val label: String, val icon: Icon)

    private fun chip(label: String, icon: Icon, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        tag = ChipSpec(label, icon)
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setPadding(dp(8), dp(5), dp(8), dp(5))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(4) }
        setOnClickListener { v ->
            pokeAt(v)
            onClick()
        }
        chips.add(this)
    }

    /** Puts [prefix] in the input and opens the keyboard, e.g. "snap " so you only type the name. */
    private fun startTyping(prefix: String) {
        input.setText(prefix)
        input.setSelection(prefix.length)
        input.requestFocus()
        imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Tells the animated background where something was tapped (Morphogen grows there). */
    private fun pokeAt(v: View) {
        if (!::backdrop.isInitialized || !panel.isAttachedToWindow) return
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        panel.getLocationInWindow(b)
        backdrop.poke((a[0] - b[0] + v.width / 2).toFloat(), (a[1] - b[1] + v.height / 2).toFloat())
    }

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    /** Irregular corner radii, stable per [seed], for organic pebble-shaped buttons. */
    private fun pebble(seed: String): FloatArray {
        val r = java.util.Random(seed.hashCode().toLong())
        return FloatArray(8) { dp(5 + r.nextInt(12)).toFloat() }
    }

    // ------------------------------------------------------------------ themes

    private fun styleChip(c: TextView, th: Theme) {
        val spec = c.tag as? ChipSpec
        c.typeface = th.chipFont
        c.setTextColor(th.chipText)
        val organic = th.organicChips && spec != null
        c.background = GradientDrawable().apply {
            setColor(th.chipBg)
            if (organic) cornerRadii = pebble(spec!!.label) else cornerRadius = th.chipRadiusDp * resources.displayMetrics.density
            setStroke(dp(1), th.chipStroke)
        }
        c.rotation = if (organic) (Math.floorMod(spec!!.label.hashCode(), 5) - 2) * 1.3f else 0f
        if (th.iconChips && spec != null) {
            c.text = ""
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(IconDrawable(spec.icon, th.chipText, dp(18)), null, null, null)
            c.setPadding(dp(9), dp(5), dp(9), dp(5))
        } else {
            if (spec != null) c.text = spec.label
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
            c.setPadding(dp(8), dp(5), dp(8), dp(5))
        }
    }

    private fun styleLabel(th: Theme) {
        label.typeface = th.titleFont
        label.setTextColor(th.menuText)
        label.letterSpacing = min(th.titleSpacing, 0.1f)
        label.setShadowLayer(th.glowDp * resources.displayMetrics.density, 0f, 0f, th.glowColor)
        label.background = GradientDrawable().apply {
            setColor(th.menuBg)
            setStroke(dp(1), th.chipStroke)
            if (th.organicChips) cornerRadii = pebble("label") else cornerRadius = th.chipRadiusDp * resources.displayMetrics.density + dp(2)
        }
    }

    /** Restyles every widget for [th]. With [revealFrom] the new look spreads out from that view. */
    private fun applyTheme(th: Theme, revealFrom: View?) {
        curTheme = th
        backdrop.theme = th
        bubble.theme = th
        val p = backdrop.padPx
        content.setPadding(p + dp(8), p + dp(5), p + dp(8), p + dp(4))
        val glow = th.glowDp * resources.displayMetrics.density
        titleView.text = th.title
        titleView.typeface = th.titleFont
        titleView.setTextColor(th.titleColor)
        titleView.letterSpacing = th.titleSpacing
        titleView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        logView.typeface = th.logFont
        logView.setTextColor(th.logColor)
        logView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        promptView.text = th.prompt
        promptView.typeface = th.logFont
        promptView.setTextColor(th.promptColor)
        promptView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        input.typeface = th.logFont
        input.setTextColor(th.inputColor)
        input.setHintTextColor(th.hintColor)
        if (Build.VERSION.SDK_INT >= 29) {
            input.textCursorDrawable = GradientDrawable().apply {
                setColor(th.cursorColor)
                setSize(dp(th.cursorWidthDp), dp(18))
            }
        }
        for (c in chips) styleChip(c, th)
        menuView?.themeChanged(th)
        if (::setRoot.isInitialized) {
            setBackdrop.theme = th
            if (settingsAdded) buildSettingsContent()
        }
        if (::libRoot.isInitialized) {
            libBackdrop.theme = th
            if (libAdded) buildLibraryContent()
        }
        styleLabel(th)
        styleMini(th)
        clockView.typeface = th.logFont
        clockView.setTextColor(th.hintColor)
        editorTitle.typeface = th.titleFont
        editorTitle.setTextColor(th.titleColor)
        if (editorOpen) term?.let { buildEditorRows(it) }
        renderLog()
        updateClock()
        if (revealFrom != null && panelAdded && panel.isAttachedToWindow) reveal(revealFrom)
    }

    private fun cycleTheme() {
        setThemeIndex(settings.theme + 1, themeChip)
    }

    private fun setThemeIndex(i: Int, from: View?) {
        val idx = Math.floorMod(i, Themes.all.size)
        settings.theme = idx
        applyTheme(Themes.get(idx), from)
        out("theme: ${curTheme.name}  (${idx + 1}/${Themes.all.size})")
    }

    /** Circular wipe from the theme button + the title popping in. */
    private fun reveal(from: View) {
        try {
            val a = IntArray(2)
            val b = IntArray(2)
            from.getLocationInWindow(a)
            panel.getLocationInWindow(b)
            val cx = a[0] - b[0] + from.width / 2
            val cy = a[1] - b[1] + from.height / 2
            val r = hypot(panel.width.toDouble(), panel.height.toDouble()).toFloat()
            ViewAnimationUtils.createCircularReveal(panel, cx, cy, 0f, r).apply {
                duration = 560L
                interpolator = DecelerateInterpolator(1.6f)
            }.start()
            titleView.alpha = 0f
            titleView.scaleX = 0.7f
            titleView.scaleY = 0.7f
            titleView.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(140L).setDuration(460L).setInterpolator(OvershootInterpolator(2.2f)).start()
        } catch (_: Exception) {
        }
    }

    override fun setLabelSide(left: Boolean) {
        main.post {
            settings.labelLeft = left
            if (!::label.isInitialized) return@post
            labelLp.gravity = Gravity.TOP or (if (left) Gravity.START else Gravity.END)
            if (labelAdded) try { wm.updateViewLayout(label, labelLp) } catch (_: Exception) {}
            out("label moved to the ${if (left) "left" else "right"}")
        }
    }

    override fun switchTheme(name: String?) {
        main.post {
            if (!::backdrop.isInitialized) return@post
            if (name.isNullOrBlank()) {
                cycleTheme()
                return@post
            }
            val n = name.trim()
            val idx = n.toIntOrNull()?.minus(1) ?: Themes.all.indexOfFirst {
                it.name.replace(" ", "").startsWith(n.replace(" ", ""), ignoreCase = true)
            }
            if (idx < 0 || idx >= Themes.all.size) {
                out("! no theme '$n'. themes: " + Themes.all.mapIndexed { i, t -> "${i + 1}=${t.name}" }.joinToString(", "))
            } else {
                setThemeIndex(idx, if (panelAdded) themeChip else null)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, lp: WindowManager.LayoutParams, target: View, onClick: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun submit() {
        val t = input.text.toString()
        input.setText("")
        if (t.isBlank()) return
        if (editorOpen) closeEditor()
        pokeAt(input)
        history.add(t)
        histPos = history.size
        term?.exec(t)
    }

    private fun recall() {
        if (history.isEmpty()) return
        histPos = if (histPos <= 0) history.size - 1 else histPos - 1
        input.setText(history[histPos])
        input.setSelection(input.text.length)
    }

    /** Adds/removes the overlay windows so they match the current state. Main thread only. */
    private fun syncWindows() {
        if (!alive || finished) return
        if (!labelAdded && ::label.isInitialized) {
            try {
                wm.addView(label, labelLp)
                labelAdded = true
            } catch (_: Exception) {
            }
        }
        val miniMode = settings.miniMode
        val wantPanel = uiVisible && panelWanted && !running
        val wantBubble = uiVisible && !miniMode
        val wantMini = uiVisible && !wantPanel && (miniMode || miniWanted)
        if (wantMini && !miniAdded) {
            try {
                wm.addView(mini, miniLp)
                miniAdded = true
                mini.alpha = 0f
                mini.translationY = -dp(10).toFloat()
                mini.animate().alpha(1f).translationY(0f).setDuration(220L).setInterpolator(DecelerateInterpolator()).start()
                updateClock()
            } catch (_: Exception) {
            }
        } else if (!wantMini && miniAdded) {
            try { wm.removeView(mini) } catch (_: Exception) {}
            miniAdded = false
        }
        if (wantBubble && !bubbleAdded) {
            wm.addView(bubble, bubbleLp); bubbleAdded = true
        } else if (!wantBubble && bubbleAdded) {
            wm.removeView(bubble); bubbleAdded = false
        }
        if (wantPanel && !panelAdded) {
            wm.addView(panel, panelLp); panelAdded = true
            if (logDirty) renderLog()
            updateClock()
        } else if (!wantPanel && panelAdded) {
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            wm.removeView(panel); panelAdded = false
        }
        val wantSettings = uiVisible && settingsWanted && !running
        if (wantSettings && !settingsAdded) {
            addSettingsWindow()
        } else if (!wantSettings && settingsAdded) {
            removeSettingsWindow()
        }
        val wantLib = uiVisible && libWanted && !running
        if (wantLib && !libAdded) {
            addLibraryWindow()
        } else if (!wantLib && libAdded) {
            removeLibraryWindow()
        }
        // the menu never stays up while a run is going or while the screen is being captured
        if ((!uiVisible || running) && (menuShowing || menuAdded)) closeStyleMenu(instant = true)
    }

    private fun removeWindows() {
        if (!::wm.isInitialized) return
        if (panelAdded) { try { wm.removeView(panel) } catch (_: Exception) {}; panelAdded = false }
        if (bubbleAdded) { try { wm.removeView(bubble) } catch (_: Exception) {}; bubbleAdded = false }
        if (labelAdded) { try { wm.removeView(label) } catch (_: Exception) {}; labelAdded = false }
        if (miniAdded) { try { wm.removeView(mini) } catch (_: Exception) {}; miniAdded = false }
        if (menuAdded) { try { wm.removeView(menuRoot) } catch (_: Exception) {}; menuAdded = false }
        if (settingsAdded) { try { wm.removeView(setRoot) } catch (_: Exception) {}; settingsAdded = false }
        if (libAdded) { try { wm.removeView(libRoot) } catch (_: Exception) {}; libAdded = false }
        menuShowing = false
    }

    private fun onRunState(r: Boolean) {
        main.post {
            running = r
            if (::bubble.isInitialized) bubble.running = r
            if (r) {
                settingsWanted = false
                libWanted = false
                cancelRestart()
                miniErr = false
                if (!settings.miniMode) miniWanted = false
                if (editorOpen) closeEditor()
            } else {
                runEnded()
            }
            updateMini()
            updateKeepAwake()
            syncWindows()
            refreshMenu()
        }
    }

    /** Writes the time log, decides what the screen shows next, and lets night mode restart. */
    private fun runEnded() {
        val now = System.currentTimeMillis()
        val end = runner.lastEnd
        val took = Runner.dur(now - runner.startedAt)
        val endTxt = when (end) {
            RunEnd.FINISHED -> "finished"
            RunEnd.STOPPED -> "stopped"
            RunEnd.NOT_FOUND -> "image not found: ${runner.lastFail}"
            RunEnd.FAILED -> "failed: ${runner.lastFail}"
        }
        store.appendTime(
            "${dayFmt.format(Date(runner.startedAt))} · $took · ${runner.loopsDone} ${runner.unit} · $endTxt" +
                (if (nightOwned) " · night" else "")
        )
        out("run ended after $took · ${runner.loopsDone} ${runner.unit} · $endTxt")
        val restart = settings.nightOn && (end == RunEnd.NOT_FOUND || end == RunEnd.FAILED) &&
            runner.loopsWanted < 0 && inNight()
        nightOwned = false
        when {
            settings.miniMode -> panelWanted = false
            end == RunEnd.NOT_FOUND || restart -> {
                panelWanted = false
                miniWanted = true
            }
            else -> panelWanted = true
        }
        if (end == RunEnd.NOT_FOUND || end == RunEnd.FAILED) {
            miniErr = true
            setMiniStatus(runner.lastFail, true)
        } else {
            setMiniStatus("$endTxt · $took · ${runner.loopsDone} ${runner.unit}", false)
        }
        if (restart) scheduleRestart()
    }

    // ------------------------------------------------------------------ mini run bar

    private class MiniSpec(var icon: Icon)

    private fun miniChip(icon: Icon, onClick: () -> Unit): TextView = TextView(this).apply {
        tag = MiniSpec(icon)
        gravity = Gravity.CENTER
        setPadding(dp(7), dp(5), dp(7), dp(5))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(3) }
        setOnClickListener { onClick() }
        miniChips.add(this)
    }

    private fun setChipIcon(c: TextView, icon: Icon, color: Int) {
        (c.tag as? MiniSpec)?.icon = icon
        c.setCompoundDrawablesRelativeWithIntrinsicBounds(IconDrawable(icon, color, dp(18)), null, null, null)
    }

    private fun styleMini(th: Theme) {
        if (!::mini.isInitialized) return
        val density = resources.displayMetrics.density
        mini.background = GradientDrawable().apply {
            setColor(th.menuBg)
            setStroke(dp(1), th.chipStroke)
            if (th.organicChips) cornerRadii = pebble("mini") else cornerRadius = (min(th.cornerDp, 16f) + 4f) * density
        }
        mini.elevation = dp(8).toFloat()
        for (c in miniChips) {
            c.background = GradientDrawable().apply {
                setColor(th.chipBg)
                setStroke(dp(1), th.chipStroke)
                if (th.organicChips) cornerRadii = pebble("m" + (c.tag as MiniSpec).icon.name)
                else cornerRadius = th.chipRadiusDp * density
            }
            setChipIcon(c, (c.tag as MiniSpec).icon, th.chipText)
        }
        miniTime.typeface = th.logFont
        miniTime.setTextColor(th.menuText)
        miniStatus.typeface = th.logFont
        miniStatus.setTextColor(if (miniErr) ERR_COLOR else th.menuText)
    }

    private fun updateMini() {
        if (!::mini.isInitialized) return
        setChipIcon(miniRun, if (running) Icon.STOP else Icon.LOOP, curTheme.chipText)
        miniFix.visibility =
            if (!running && runner.lastEnd == RunEnd.NOT_FOUND && runner.failIndex >= 0) View.VISIBLE else View.GONE
        miniClose.visibility = if (settings.miniMode) View.GONE else View.VISIBLE
        miniStatus.setTextColor(if (miniErr) ERR_COLOR else curTheme.menuText)
        updateClock()
    }

    private fun setMiniStatus(s: String, err: Boolean) {
        if (!::miniStatus.isInitialized) return
        val clean = s.removePrefix(ERR).replace(Regex("^\\[[^]]*] "), "")
        miniStatus.text = if (err) ERR + clean else clean
        miniStatus.setTextColor(if (err) ERR_COLOR else curTheme.menuText)
    }

    private fun expandPanel() {
        miniWanted = false
        panelWanted = true
        syncWindows()
    }

    private fun updateClock() {
        val now = System.currentTimeMillis()
        val moon = if (settings.nightOn) "☾ " else ""
        if (::clockView.isInitialized && panelAdded) clockView.text = moon + clockFmt.format(Date(now))
        if (::miniTime.isInitialized && miniAdded) {
            miniTime.text = moon + when {
                running -> "⏱ " + Runner.dur(now - runner.startedAt)
                restartPending -> "↻ " + shortFmt.format(Date(now))
                else -> shortFmt.format(Date(now))
            }
        }
    }

    private fun updateKeepAwake() {
        if (!::labelLp.isInitialized) return
        val want = running || settings.nightOn
        if (want == keepAwake) return
        keepAwake = want
        labelLp.flags = if (want) {
            labelLp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            labelLp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        }
        if (labelAdded) try { wm.updateViewLayout(label, labelLp) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ night mode

    private fun hm(minutes: Int): String = String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

    private fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    /** Inside the night window right now (window may cross midnight). */
    private fun inNight(): Boolean = NightWindow.contains(settings.nightStart, settings.nightEnd, nowMinutes())

    private fun onTick() {
        updateClock()
        if (!settings.nightOn) {
            wasInNight = null
            return
        }
        val inside = inNight()
        val was = wasInNight
        wasInNight = inside
        if (was == null || was == inside) return
        if (inside) {
            if (!running && !restartPending) {
                out("☾ ${hm(settings.nightStart)} night mode: starting run inf")
                nightOwned = true
                term?.exec("run inf")
            }
        } else {
            cancelRestart()
            if (running && nightOwned) {
                out("☾ ${hm(settings.nightEnd)} night mode over: stopping its run")
                runner.stop()
            } else {
                out("☾ ${hm(settings.nightEnd)} night mode over")
            }
        }
    }

    private fun scheduleRestart() {
        restartPending = true
        restartCount++
        val wait = settings.restartDelayMs
        out("↻ night mode: restarting run inf in ${Runner.secs(wait)} (restart #$restartCount)")
        setMiniStatus("↻ restarting in ${Runner.secs(wait)}", false)
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, wait)
    }

    private fun cancelRestart() {
        restartPending = false
        main.removeCallbacks(restartRunnable)
    }

    private fun doNightRestart() {
        if (!alive || finished || !restartPending) return
        restartPending = false
        if (running) return
        if (!settings.nightOn || !inNight()) {
            out("☾ night window is over, not restarting")
            return
        }
        nightOwned = true
        term?.exec("run inf")
    }

    override fun setNight(arg: String) {
        main.post {
            val a = arg.trim().lowercase()
            val looksLikeRange = Regex("^\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}$").matches(a)
            val range = NightWindow.parse(a)
            when {
                a.isEmpty() -> {
                    out(
                        "night mode ${if (settings.nightOn) "on" else "off"} · ${hm(settings.nightStart)}–${hm(settings.nightEnd)}" +
                            " · now ${if (inNight()) "inside" else "outside"} the window · restarts so far $restartCount" +
                            " · restart delay ${Runner.secs(settings.restartDelayMs)}"
                    )
                }
                a == "on" -> {
                    settings.nightOn = true
                    wasInNight = null
                    out(
                        "☾ night mode on: at ${hm(settings.nightStart)} it starts run inf, and until ${hm(settings.nightEnd)} " +
                            "it restarts run inf whenever an image isn't found. The screen stays on."
                    )
                    if (inNight() && !running) {
                        out("☾ it's night now: starting run inf")
                        nightOwned = true
                        term?.exec("run inf")
                    }
                }
                a == "off" -> {
                    settings.nightOn = false
                    cancelRestart()
                    out("night mode off")
                }
                range != null -> {
                    val (s1, s2) = range
                    settings.nightStart = s1
                    settings.nightEnd = s2
                    wasInNight = null
                    out("night window set to ${hm(s1)}–${hm(s2)}" + if (!settings.nightOn) " (turn it on with: night on)" else "")
                }
                looksLikeRange -> out("! times must be like 22:00-08:00 (hours 0-23, minutes 0-59)")
                else -> out("! usage: night [on|off|22:00-08:00]")
            }
            updateMini()
            updateKeepAwake()
            updateClock()
        }
    }

    // ------------------------------------------------------------------ logs / mini mode / editor (Host)

    override fun showLog(kind: String, clear: Boolean) {
        main.post {
            if (kind == "errors") {
                if (clear) {
                    store.clearErrors()
                    out("error log cleared")
                    return@post
                }
                val l = store.errors(40)
                out(if (l.isEmpty()) "error log is empty" else "-- last ${l.size} errors · ${store.root.absolutePath}/errors.log --")
                l.forEach { out("  $it") }
            } else {
                if (clear) {
                    store.clearTimes()
                    out("time log cleared")
                    return@post
                }
                val l = store.times(25)
                out(if (l.isEmpty()) "time log is empty (a line is added when a run ends)" else "-- last ${l.size} runs: start · duration · loops · result --")
                l.forEach { out("  $it") }
                if (running) out("  now: running for ${Runner.dur(System.currentTimeMillis() - runner.startedAt)}, ${runner.loopsDone} ${runner.unit} done")
            }
        }
    }

    override fun setMini(on: Boolean?) {
        main.post {
            val v = on ?: !settings.miniMode
            settings.miniMode = v
            if (v) {
                panelWanted = false
                out("mini mode on: only the run bar shows. ⤢ opens the full menu")
            } else {
                miniWanted = false
                panelWanted = true
                out("mini mode off")
            }
            updateMini()
            syncWindows()
        }
    }

    override fun openEditor() {
        main.post {
            expandPanel()
            openEditorUi(-1)
        }
    }

    private fun f2(v: Double): String = String.format(Locale.US, "%.2f", v)

    private fun thrToProgress(v: Double): Int = ((v - 0.5) * 100).roundToInt().coerceIn(0, 50)

    private fun progressToThr(p: Int): Double = 0.5 + p / 100.0

    /** Shows the slider editor instead of the log. [focus] = step index to highlight (e.g. the one that failed). */
    private fun openEditorUi(focus: Int) {
        val t = term ?: return
        if (!::editorBox.isInitialized) return
        editorOpen = true
        editorFocus = focus
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        scroll.visibility = View.GONE
        inputRow.visibility = View.GONE
        editorBox.visibility = View.VISIBLE
        buildEditorRows(t)
        editorBox.alpha = 0f
        editorBox.translationY = dp(14).toFloat()
        editorBox.animate().alpha(1f).translationY(0f).setDuration(240L).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeEditor() {
        if (!editorOpen) return
        editorOpen = false
        editorBox.visibility = View.GONE
        scroll.visibility = View.VISIBLE
        inputRow.visibility = View.VISIBLE
        renderLog()
    }

    private fun saveFromEditor() {
        val t = term ?: return
        val n = t.saveCurrent()
        if (n != null) {
            out("saved '$n' with the new thresholds")
        } else {
            closeEditor()
            startTyping("save ")
            out("type a name and press go to save this sequence")
        }
    }

    private fun buildEditorRows(t: Terminal) {
        val th = curTheme
        editorList.removeAllViews()
        val steps = t.stepsSnapshot()
        editorTitle.text = (t.seqName?.let { "'$it'" } ?: "current steps") + " · thr"
        editorList.addView(
            sliderRow(th, "default thr (steps without their own)", settings.thr, null, own = true, isDefault = true, onReset = null) { v, done ->
                if (done) {
                    settings.thr = v
                    out("default thr → ${f2(v)}")
                    buildEditorRows(t)
                }
            }
        )
        if (steps.isEmpty()) editorList.addView(textRow(th, "no steps yet: add some with  add tap <image>"))
        var focusView: View? = null
        steps.forEachIndexed { i, st ->
            if (!st.isImage) {
                editorList.addView(textRow(th, "${i + 1}. ${st.toLine()}"))
                return@forEachIndexed
            }
            val row = sliderRow(
                th, "${i + 1}. ${st.op.name.lowercase()} ${st.tpl}", st.thr ?: settings.thr, runner.bestScores[i],
                own = st.thr != null, isDefault = false,
                onReset = {
                    t.setStepThr(i, null)
                    out("step ${i + 1} thr → default")
                    buildEditorRows(t)
                }
            ) { v, done ->
                if (done) {
                    t.setStepThr(i, v)
                    out("step ${i + 1} thr → ${f2(v)}")
                }
            }
            if (i == editorFocus) {
                row.background = GradientDrawable().apply {
                    setColor(withAlpha(th.chipStroke, 0x33))
                    setStroke(dp(1), withAlpha(ERR_COLOR, 0xAA))
                    cornerRadius = dp(8).toFloat()
                }
                focusView = row
            }
            editorList.addView(row)
        }
        val fv = focusView
        if (fv != null) editorScroll.post { editorScroll.smoothScrollTo(0, max(0, fv.top - dp(8))) }
    }

    private fun textRow(th: Theme, text: String): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        typeface = th.logFont
        setTextColor(th.hintColor)
        setPadding(dp(6), dp(5), dp(6), dp(5))
    }

    private fun sliderRow(
        th: Theme,
        title: String,
        value: Double,
        last: Double?,
        own: Boolean,
        isDefault: Boolean,
        onReset: (() -> Unit)?,
        onChange: (Double, Boolean) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = th.logFont
            setTextColor(th.logColor)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }
        val valueView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(th.logFont, Typeface.BOLD)
            setTextColor(th.promptColor)
            setPadding(dp(6), 0, dp(2), 0)
        }
        top.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(valueView)
        if (onReset != null && own) {
            top.addView(TextView(this).apply {
                text = "↺ default"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                typeface = th.chipFont
                setTextColor(th.hintColor)
                setPadding(dp(8), dp(2), dp(2), dp(2))
                setOnClickListener { onReset() }
            })
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val bar = SeekBar(this).apply {
            max = 50
            progress = thrToProgress(value)
            progressTintList = ColorStateList.valueOf(th.promptColor)
            thumbTintList = ColorStateList.valueOf(th.promptColor)
            progressBackgroundTintList = ColorStateList.valueOf(withAlpha(th.logColor, 0x55))
        }
        val lastView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = th.logFont
            setPadding(dp(4), 0, 0, 0)
        }
        var isOwn = own
        fun refresh(v: Double) {
            valueView.text = f2(v) + if (!isOwn && !isDefault) " (default)" else ""
            when {
                isDefault -> lastView.text = ""
                last == null -> {
                    lastView.text = "last —"
                    lastView.setTextColor(th.hintColor)
                }
                else -> {
                    lastView.text = "last ${f2(last)}"
                    lastView.setTextColor(if (last >= v) OK_COLOR else ERR_COLOR)
                }
            }
        }
        refresh(value)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                isOwn = true
                refresh(progressToThr(p))
                onChange(progressToThr(p), false)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                onChange(progressToThr(sb.progress), true)
            }
        })
        bottom.addView(bar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(lastView)
        box.addView(top)
        box.addView(bottom)
        return box
    }


    // ------------------------------------------------------------------ style menu window

    private val density: Float get() = resources.displayMetrics.density

    private fun reducedMotion(): Boolean = StyleView.reducedMotion() || settings.calmMotion

    private fun newKit(): Kit = Kit(density, curTheme, reducedMotion(), Build.VERSION.SDK_INT)

    /** A focusable full-screen overlay (Back closes it). Hardware accelerated so AGSL effects can run. */
    private fun fullScreenLp(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType(),
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
    }

    private fun buildMenuWindow() {
        menuRoot = OverlayRoot(this, onBack = { closeStyleMenu() }, onSize = { _, _ -> placeMenu() })
        menuScrim = View(this).apply {
            alpha = 0f
            contentDescription = "Close menu"
            setOnClickListener { closeStyleMenu() }
        }
        menuRoot.addView(menuScrim, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        menuLp = fullScreenLp()
    }

    private fun menuItemsNow(): List<MenuItem> =
        MenuModel.ids.map { MenuModel.item(it, running, settings.nightOn, settings.miniMode) }

    /** Which content is showing, so styles can mark it (log / thr sliders / settings). */
    private fun currentPane(): String? = when {
        libWanted -> "tap"
        settingsWanted -> "settings"
        editorOpen && panelAdded -> "thr"
        panelAdded -> "log"
        else -> null
    }

    private fun ensureMenuView(): StyleView {
        val info = StyleFactory.resolve(settings.menuStyle)
        menuView?.let { if (menuStyleId == info.id) return it }
        discardMenuView()
        val v = StyleView(this, info.make(), newKit())
        v.contentDescription = info.name + " menu"
        v.onPickId = { onMenuPick(it) }
        v.onClosed = { if (!menuShowing && menuView === v) removeMenuWindow(keepView = true) }
        v.onOutsideTap = { closeStyleMenu() }
        v.onError = { e ->
            styleFailed(info, e)
            // fall back to the Classic menu instead of leaving a broken one on screen
            if (info.id != StyleFactory.DEFAULT) {
                settings.menuStyle = StyleFactory.DEFAULT
                out("menu switched back to Classic")
                if (menuShowing) closeStyleMenu(instant = true, then = { openStyleMenu() })
            }
        }
        menuRoot.addView(v, FrameLayout.LayoutParams(1, 1))
        menuView = v
        menuStyleId = info.id
        v.setItems(menuItemsNow())
        placeMenu()
        return v
    }

    private fun discardMenuView() {
        menuView?.let { menuRoot.removeView(it) }
        menuView = null
        menuStyleId = ""
    }

    /** Sizes and positions the menu for its style and the current window size (runs again after rotation). */
    private fun placeMenu() {
        val v = menuView ?: return
        val d = density
        val dm = resources.displayMetrics
        val wPx = if (menuRoot.width > 0) menuRoot.width else dm.widthPixels
        val hPx = if (menuRoot.height > 0) menuRoot.height else dm.heightPixels
        val sw = (wPx / d).toInt()
        val sh = (hPx / d).toInt()
        val pl = MenuLayouts.place(menuStyleId, sw, sh)
        val fill = pl.anchor == Anchor.FILL
        v.layoutParams = FrameLayout.LayoutParams(
            if (fill) FrameLayout.LayoutParams.MATCH_PARENT else (pl.w * d).roundToInt(),
            if (fill) FrameLayout.LayoutParams.MATCH_PARENT else (pl.h * d).roundToInt()
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = (pl.left(sw) * d).roundToInt()
            topMargin = (pl.top(sh) * d).roundToInt()
        }
        menuScrim.setBackgroundColor(withAlpha(Color.BLACK, pl.scrim))
    }

    private fun toggleStyleMenu() {
        if (menuShowing) closeStyleMenu() else openStyleMenu()
    }

    private fun openStyleMenu() {
        if (!alive || finished || running || !uiVisible) return
        val v = ensureMenuView()
        afterMenuClosed = null
        main.removeCallbacks(menuCloseTimeout)
        v.kit.reduced = reducedMotion()
        v.style.selected = currentPane()
        v.setItems(menuItemsNow())
        menuShowing = true
        menuLp.flags = menuLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        if (!menuAdded) {
            try {
                wm.addView(menuRoot, menuLp)
                menuAdded = true
            } catch (e: Exception) {
                menuShowing = false
                out("${ERR}could not open the menu: ${e.message}")
                return
            }
        } else {
            try { wm.updateViewLayout(menuRoot, menuLp) } catch (_: Exception) {}
        }
        menuScrim.animate().cancel()
        menuScrim.animate().alpha(1f).setDuration(if (v.kit.reduced) 0L else 220L).start()
        v.setOpen(true)
        v.requestFocus()
    }

    /**
     * Plays the style's own exit animation, then removes the window. [then] runs once it is gone.
     * Safe to call repeatedly: a close in progress keeps going and only the newest [then] runs.
     */
    private fun closeStyleMenu(instant: Boolean = false, then: (() -> Unit)? = null) {
        if (then != null) afterMenuClosed = then
        if (!menuAdded) {
            menuShowing = false
            runAfterMenuClosed()
            return
        }
        val v = menuView
        val wasShowing = menuShowing
        menuShowing = false
        if (instant || v == null) {
            removeMenuWindow(keepView = false)
            return
        }
        if (!wasShowing) return
        // the window lets touches through while it animates away
        menuLp.flags = menuLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(menuRoot, menuLp) } catch (_: Exception) {}
        menuScrim.animate().cancel()
        menuScrim.animate().alpha(0f).setDuration(if (v.kit.reduced) 0L else 200L).start()
        v.setOpen(false)
        main.removeCallbacks(menuCloseTimeout)
        main.postDelayed(menuCloseTimeout, 1600L)
    }

    /** [keepView] = the exit animation finished, so the style is at rest and can be reused next time. */
    private fun removeMenuWindow(keepView: Boolean = false) {
        main.removeCallbacks(menuCloseTimeout)
        menuShowing = false
        menuScrim.animate().cancel()
        menuScrim.alpha = 0f
        if (menuAdded) {
            try { wm.removeView(menuRoot) } catch (_: Exception) {}
            menuAdded = false
        }
        if (!keepView) discardMenuView()
        runAfterMenuClosed()
    }

    private fun runAfterMenuClosed() {
        val f = afterMenuClosed ?: return
        afterMenuClosed = null
        f()
    }

    /** New labels / toggle states / highlighted pane, without rebuilding the style. */
    private fun refreshMenu() {
        val v = menuView ?: return
        v.setItems(menuItemsNow())
        v.style.selected = currentPane()
        v.invalidate()
    }

    private fun onMenuPick(id: String) {
        when (id) {
            "toggle" -> {
                closeStyleMenu()
                if (running) runner.stop() else term?.exec("run inf")
            }
            "thr" -> {
                closeStyleMenu()
                closeSettingsUi()
                expandPanel()
                openEditorUi(-1)
            }
            "snap" -> {
                closeSettingsUi()
                closeLibraryUi()
                expandPanel()
                closeEditor()
                // the keyboard needs the panel to have window focus, so wait for the menu to leave
                closeStyleMenu(then = { startTyping("snap ") })
            }
            "tap" -> {
                closeStyleMenu()
                closeSettingsUi()
                openLibraryUi()
            }
            "hold" -> {
                closeStyleMenu()
                closeSettingsUi()
                term?.hold("")
            }
            "log" -> {
                closeStyleMenu()
                closeSettingsUi()
                expandPanel()
                closeEditor()
            }
            "settings" -> {
                closeStyleMenu()
                openSettingsUi()
            }
            "theme" -> {
                // stays open so you watch the menu take on the new theme
                cycleTheme()
                refreshMenu()
            }
            "night" -> {
                setNight(if (settings.nightOn) "off" else "on")
                main.post { refreshMenu() }
            }
            "mini" -> {
                closeStyleMenu()
                closeSettingsUi()
                setMini(null)
            }
            "hide" -> {
                closeStyleMenu()
                closeSettingsUi()
                panelWanted = false
                syncWindows()
            }
        }
    }

    // ------------------------------------------------------------------ settings window

    private fun buildSettingsWindow() {
        setRoot = OverlayRoot(this, onBack = { closeSettingsUi() }, onSize = { w, h -> placeSettings(w, h) })
        setScrim = View(this).apply {
            setBackgroundColor(withAlpha(Color.BLACK, 0x99))
            contentDescription = "Close settings"
            setOnClickListener { closeSettingsUi() }
        }
        setRoot.addView(setScrim, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setCard = FrameLayout(this).apply {
            isClickable = true
            clipToOutline = true
        }
        setBackdrop = ThemeBackdrop(this)
        setCard.addView(setBackdrop, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(setList)
            // previews stop drawing while off screen; scrolling wakes the ones that come into view
            setOnScrollChangeListener { _, _, _, _, _ -> for (p in previews) p.invalidate() }
        }
        setCard.addView(setScroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setRoot.addView(setCard, FrameLayout.LayoutParams(dp(320), dp(480), Gravity.CENTER))
        setLp = fullScreenLp()
    }

    /** Card size for the window (phone, tablet, landscape); the gallery gets 2 or 3 columns. */
    private fun placeSettings(wPx: Int, hPx: Int) {
        val cw = min(wPx - dp(20), dp(560))
        val ch = min(hPx - dp(36), dp(780))
        val lp = setCard.layoutParams as FrameLayout.LayoutParams
        if (lp.width != cw || lp.height != ch) {
            setCard.layoutParams = FrameLayout.LayoutParams(cw, ch, Gravity.CENTER)
            if (settingsAdded) buildSettingsContent()
        }
    }

    private fun openSettingsUi() {
        if (!alive || finished) return
        if (settingsWanted && settingsAdded) return
        settingsWanted = true
        if (settingsAdded) {
            settingsEnter()
        } else {
            syncWindows()
        }
        refreshMenu()
    }

    private fun closeSettingsUi() {
        if (!settingsWanted) return
        settingsWanted = false
        refreshMenu()
        if (!settingsAdded) return
        val reduced = reducedMotion()
        setScrim.animate().cancel()
        setScrim.animate().alpha(0f).setDuration(if (reduced) 0L else 180L).start()
        setCard.animate().cancel()
        setCard.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).translationY(dp(18).toFloat())
            .setDuration(if (reduced) 0L else 180L).setInterpolator(DecelerateInterpolator())
            .withEndAction { if (!settingsWanted) syncWindows() }
            .start()
    }

    private fun addSettingsWindow() {
        val dm = resources.displayMetrics
        placeSettings(dm.widthPixels, dm.heightPixels)
        try {
            wm.addView(setRoot, setLp)
            settingsAdded = true
        } catch (e: Exception) {
            settingsWanted = false
            out("${ERR}could not open settings: ${e.message}")
            return
        }
        setBackdrop.theme = curTheme
        buildSettingsContent()
        setScroll.scrollTo(0, 0)
        settingsEnter()
    }

    private fun settingsEnter() {
        val reduced = reducedMotion()
        setCard.animate().cancel()
        setCard.alpha = 0f
        setCard.scaleX = 0.9f
        setCard.scaleY = 0.9f
        setCard.translationY = dp(28).toFloat()
        setCard.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(if (reduced) 0L else 340L).setInterpolator(OvershootInterpolator(1.1f)).start()
        setScrim.animate().cancel()
        setScrim.alpha = 0f
        setScrim.animate().alpha(1f).setDuration(if (reduced) 0L else 220L).start()
        setRoot.requestFocus()
    }

    private fun removeSettingsWindow() {
        previews.clear()
        tiles.clear()
        setList.removeAllViews()
        try { wm.removeView(setRoot) } catch (_: Exception) {}
        settingsAdded = false
    }

    /** A pill button with icon and text (settings always shows words, whatever the theme does with chips). */
    private fun pill(th: Theme, label: String, icon: Icon?, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = th.chipFont
        setTextColor(th.chipText)
        setSingleLine(true)
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(10), dp(8), dp(10), dp(8))
        minHeight = dp(40)
        if (icon != null) {
            compoundDrawablePadding = dp(6)
            setCompoundDrawablesRelativeWithIntrinsicBounds(IconDrawable(icon, th.chipText, dp(16)), null, null, null)
        }
        background = RippleDrawable(
            ColorStateList.valueOf(withAlpha(th.chipStroke, 0x66)),
            GradientDrawable().apply {
                setColor(th.chipBg)
                setStroke(dp(1), th.chipStroke)
                cornerRadius = th.chipRadiusDp * density
            },
            null
        )
        setOnClickListener { onClick() }
    }

    private fun sectionTitle(th: Theme, title: String, note: String?, into: LinearLayout = setList) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(0, dp(16), 0, dp(4))
        }
        box.addView(TextView(this).apply {
            text = title.uppercase(Locale.US)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(th.titleFont, Typeface.BOLD)
            letterSpacing = 0.14f
            setTextColor(th.promptColor)
        })
        if (note != null) {
            box.addView(TextView(this).apply {
                text = note
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = th.logFont
                setTextColor(th.hintColor)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(8), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        into.addView(box)
    }

    /** Fills [views] into rows of [cols] equal columns. */
    private fun grid(views: List<View>, cols: Int, gap: Int, into: LinearLayout = setList) {
        var row: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                into.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = gap })
            }
            row!!.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (i % cols != 0) marginStart = gap })
        }
        // pad the last row so its cells keep the same width
        val left = (cols - views.size % cols) % cols
        repeat(left) {
            row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = gap })
        }
    }

    private fun toggleRow(th: Theme, title: String, note: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(48)
            setPadding(0, dp(2), 0, dp(2))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = th.chipFont
            setTextColor(th.logColor)
        })
        texts.addView(TextView(this).apply {
            text = note
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = th.logFont
            setTextColor(th.hintColor)
        })
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = android.widget.Switch(this).apply {
            isChecked = on
            contentDescription = title
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(th.promptColor, mix(th.logColor, Color.GRAY, 0.4f))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(withAlpha(th.promptColor, 0x88), withAlpha(th.logColor, 0x44))
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        setList.addView(row)
    }

    private fun styleTileLook(tile: View, on: Boolean, th: Theme) {
        tile.background = GradientDrawable().apply {
            setColor(if (on) withAlpha(th.promptColor, 0x26) else withAlpha(Color.BLACK, 0x33))
            setStroke(if (on) dp(2) else dp(1), if (on) th.promptColor else withAlpha(th.chipStroke, 0x77))
            cornerRadius = dp(12).toFloat()
        }
        tile.isSelected = on
    }

    /** One gallery tile: a tiny phone screen with the style running live at its real placement. */
    private fun styleTile(info: StyleInfo, index: Int, tileW: Int, th: Theme, current: String): View {
        val d = density
        val vw = 360
        val vh = 600
        val inner = tileW - dp(10)
        val scale = inner / (vw * d)
        val screenH = (vh * d * scale).roundToInt()
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(7))
            isClickable = true
            isFocusable = true
            contentDescription = "${info.name} menu style. ${info.blurb}"
            setOnClickListener { pickStyle(info.id) }
        }
        val screen = FrameLayout(this).apply {
            clipChildren = true
            clipToOutline = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1E3A56.toInt(), 0xFF2E5137.toInt())
            ).apply { cornerRadius = dp(9).toFloat() }
        }
        val virtual = FrameLayout(this).apply {
            pivotX = 0f
            pivotY = 0f
            scaleX = scale
            scaleY = scale
        }
        val pl = MenuLayouts.place(info.id, vw, vh)
        virtual.addView(View(this).apply { setBackgroundColor(withAlpha(Color.BLACK, pl.scrim)) },
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val kit = newKit()
        val sv = StyleView(this, info.make(), kit)
        sv.interactive = false
        sv.style.preview = true
        sv.frameCapMs = 50L
        sv.idleFrameMs = 50L
        sv.setPreviewPhase(index * 0.47f)
        sv.onError = { e -> styleFailed(info, e) }
        sv.setItems(menuItemsNow())
        virtual.addView(sv, FrameLayout.LayoutParams((pl.w * d).roundToInt(), (pl.h * d).roundToInt()).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = (pl.left(vw) * d).roundToInt()
            topMargin = (pl.top(vh) * d).roundToInt()
        })
        screen.addView(virtual, FrameLayout.LayoutParams((vw * d).roundToInt(), (vh * d).roundToInt()))
        tile.addView(screen, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, screenH))
        tile.addView(TextView(this).apply {
            text = "${index + 1}. ${info.name}"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create(th.chipFont, Typeface.BOLD)
            setTextColor(th.logColor)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(2), dp(6), dp(2), 0)
        })
        tile.addView(TextView(this).apply {
            text = info.blurb
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = th.logFont
            setTextColor(th.hintColor)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(2), dp(2), dp(2), 0)
        })
        styleTileLook(tile, info.id == current, th)
        previews.add(sv)
        tiles.add(info.id to tile)
        return tile
    }

    /** (Re)builds the whole settings page for the current theme and card width. */
    private fun buildSettingsContent() {
        val th = curTheme
        val keepY = setScroll.scrollY
        previews.clear()
        tiles.clear()
        setList.removeAllViews()
        setCard.background = GradientDrawable().apply {
            setColor(th.menuBg)
            cornerRadius = (min(th.cornerDp, 18f) + 4f) * density
        }
        val p = setBackdrop.padPx
        setList.setPadding(p + dp(12), p + dp(10), p + dp(12), p + dp(18))
        val cardW = (setCard.layoutParams?.width ?: dp(320)).let { if (it > 0) it else dp(320) }
        val innerW = cardW - 2 * (p + dp(12))
        galleryCols = if (cardW / density >= 470f) 3 else 2
        val gap = dp(8)
        val current = StyleFactory.resolve(settings.menuStyle).id

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = "settings"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = th.titleFont
            setTextColor(th.titleColor)
            letterSpacing = min(th.titleSpacing, 0.12f)
            setShadowLayer(th.glowDp * density, 0f, 0f, th.glowColor)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(pill(th, "close", Icon.CLOSE) { closeSettingsUi() })
        setList.addView(head)

        sectionTitle(th, "menu style", "tap to use · now: ${StyleFactory.resolve(current).name}")
        val tileW = (innerW - gap * (galleryCols - 1)) / galleryCols
        grid(StyleFactory.all.mapIndexed { i, info -> styleTile(info, i, tileW, th, current) }, galleryCols, gap)

        sectionTitle(th, "theme", th.name)
        grid(Themes.all.mapIndexed { i, t ->
            pill(th, (if (i == settings.theme) "● " else "") + t.name, null) { setThemeIndex(i, null) }
        }, galleryCols + 1, gap)

        sectionTitle(th, "options", null)
        toggleRow(th, "Night mode ${hm(settings.nightStart)}–${hm(settings.nightEnd)}",
            "starts run inf at night and restarts it when an image isn't found", settings.nightOn) { on ->
            setNight(if (on) "on" else "off")
            main.post { refreshMenu() }
        }
        toggleRow(th, "Mini mode", "only the small run bar instead of the menu", settings.miniMode) { on ->
            if (on) closeSettingsUi()
            setMini(on)
            main.post { refreshMenu() }
        }
        toggleRow(th, "Label on the left", "where \"martijn's project\" sits", settings.labelLeft) { on -> setLabelSide(on) }
        toggleRow(th, "Calm motion", "menus snap into place instead of animating", settings.calmMotion) { on ->
            settings.calmMotion = on
            menuView?.kit?.reduced = reducedMotion()
            for (pv in previews) {
                pv.kit.reduced = reducedMotion()
                pv.invalidate()
            }
            out("calm motion ${if (on) "on" else "off"}")
        }
        toggleRow(th, "Tap marks", "flash a box where every tap lands", settings.marks) { on ->
            settings.marks = on
            out("marks ${if (on) "on" else "off"}")
        }
        setList.addView(
            sliderRow(th, "default thr (steps without their own)", settings.thr, null, own = true, isDefault = true, onReset = null) { v, done ->
                if (done) {
                    settings.thr = v
                    out("default thr → ${f2(v)}")
                }
            }
        )

        sectionTitle(th, "more", null)
        fun inPanel(block: () -> Unit) {
            closeSettingsUi()
            expandPanel()
            closeEditor()
            block()
        }
        grid(listOf(
            pill(th, "run once", Icon.PLAY) { inPanel { term?.exec("run") } },
            pill(th, "tap folder", Icon.FOLDER) { closeSettingsUi(); openLibraryUi() },
            pill(th, "sliders", Icon.SLIDER) { closeSettingsUi(); expandPanel(); openEditorUi(-1) },
            pill(th, "error log", Icon.WARN) { inPanel { showLog("errors", false) } },
            pill(th, "time log", Icon.CLOCK) { inPanel { showLog("times", false) } },
            pill(th, "status", Icon.INFO) { inPanel { term?.exec("status") } },
            pill(th, "clear log", Icon.CLEAR) { clearLog() },
            pill(th, "help", Icon.HELP) { inPanel { term?.exec("help") } },
            pill(th, "exit app", Icon.EXIT) { shutdown() }
        ), galleryCols + 1, gap)
        setList.addView(TextView(this).apply {
            text = PROJECT_LABEL
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = th.titleFont
            setTextColor(th.hintColor)
            setPadding(0, dp(16), 0, 0)
        })
        if (keepY > 0) setScroll.post { setScroll.scrollTo(0, keepY) }
    }

    private val reportedStyleErrors = HashSet<String>()

    /** A style threw: its view already stopped running it; tell the user once, in the error log. */
    private fun styleFailed(info: StyleInfo, e: Throwable) {
        if (!reportedStyleErrors.add(info.id + ":" + e.javaClass.name)) return
        val at = e.stackTrace.firstOrNull { it.className.startsWith("app.imageclicker") }
        val where = if (at != null) " (${at.fileName}:${at.lineNumber})" else ""
        out("${ERR}menu style ${info.name} hit an error: ${e.javaClass.simpleName}: ${e.message}$where")
    }

    override fun showCrash(clear: Boolean) {
        main.post {
            if (clear) {
                CrashLog.clear(this)
                out("crash report cleared")
                return@post
            }
            val c = CrashLog.read(this)
            if (c == null) {
                out("no crash recorded")
            } else {
                c.lines().take(24).forEach { out(it) }
                out("(the full report is on the setup screen: open Image Clicker, Copy crash report)")
            }
        }
    }

    /** Saves the style and shows it: the old style plays its exit, then the new one enters. */
    private fun pickStyle(id: String) {
        val info = StyleFactory.resolve(id)
        settings.menuStyle = info.id
        out("menu style: ${info.name}")
        for ((tid, t) in tiles) {
            styleTileLook(t, tid == info.id, curTheme)
            if (tid == info.id && !reducedMotion()) {
                t.scaleX = 0.94f
                t.scaleY = 0.94f
                t.animate().scaleX(1f).scaleY(1f).setDuration(260L).setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
        if (menuShowing || menuAdded) closeStyleMenu(then = { openStyleMenu() }) else openStyleMenu()
    }

    override fun setMenuStyle(name: String?) {
        main.post {
            val q = name?.trim().orEmpty()
            val cur = StyleFactory.resolve(settings.menuStyle)
            if (q.isEmpty() || q.equals("list", true)) {
                out("menu styles (now: ${cur.name}). use: style <name|number>, or ⚙ for live previews")
                StyleFactory.all.forEachIndexed { i, s -> out("  ${i + 1}. ${s.name} — ${s.blurb}") }
                return@post
            }
            val info = if (q.equals("next", true)) StyleFactory.get(StyleFactory.index(cur.id) + 1) else StyleFactory.find(q)
            if (info == null) {
                out("! no menu style '$q'. type: style list")
                return@post
            }
            pickStyle(info.id)
        }
    }

    override fun openSettings() {
        main.post { openSettingsUi() }
    }

    override fun openMenu() {
        main.post {
            if (!panelAdded && !settingsAdded) expandPanel()
            openStyleMenu()
        }
    }

    // ------------------------------------------------------------------ the "tap" folder

    private fun buildLibraryWindow() {
        libRoot = OverlayRoot(this, onBack = { closeLibraryUi() }, onSize = { w, h -> placeLibrary(w, h) })
        libScrim = View(this).apply {
            setBackgroundColor(withAlpha(Color.BLACK, 0x99))
            contentDescription = "Close tap folder"
            setOnClickListener { closeLibraryUi() }
        }
        libRoot.addView(libScrim, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        libCard = FrameLayout(this).apply {
            isClickable = true
            clipToOutline = true
        }
        libBackdrop = ThemeBackdrop(this)
        libCard.addView(libBackdrop, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        libList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(libList)
        }
        libCard.addView(libScroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        libRoot.addView(libCard, FrameLayout.LayoutParams(dp(320), dp(480), Gravity.CENTER))
        // resize (not pan) when the keyboard opens for the sequence name
        @Suppress("DEPRECATION")
        libLp = fullScreenLp().apply { softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
    }

    private fun libCols(cardW: Int): Int = if (cardW / density >= 470f) 4 else 3

    /** Card size for the window. Only a change in the number of columns rebuilds the page (not the keyboard opening). */
    private fun placeLibrary(wPx: Int, hPx: Int) {
        val cw = min(wPx - dp(20), dp(560))
        val ch = min(hPx - dp(36), dp(780))
        val lp = libCard.layoutParams as FrameLayout.LayoutParams
        if (lp.width != cw || lp.height != ch) {
            val before = libCols(lp.width)
            libCard.layoutParams = FrameLayout.LayoutParams(cw, ch, Gravity.CENTER)
            if (libAdded && libCols(cw) != before) buildLibraryContent()
        }
    }

    private fun openLibraryUi() {
        if (!alive || finished) return
        if (running) {
            out("stop the run first (tap ■)")
            return
        }
        if (libWanted && libAdded) return
        libWanted = true
        if (libAdded) libraryEnter() else syncWindows()
        refreshMenu()
    }

    private fun closeLibraryUi() {
        if (!libWanted) return
        libWanted = false
        refreshMenu()
        if (!libAdded) return
        val reduced = reducedMotion()
        libScrim.animate().cancel()
        libScrim.animate().alpha(0f).setDuration(if (reduced) 0L else 180L).start()
        libCard.animate().cancel()
        libCard.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).translationY(dp(18).toFloat())
            .setDuration(if (reduced) 0L else 180L).setInterpolator(DecelerateInterpolator())
            .withEndAction { if (!libWanted) syncWindows() }
            .start()
    }

    private fun addLibraryWindow() {
        val dm = resources.displayMetrics
        placeLibrary(dm.widthPixels, dm.heightPixels)
        try {
            wm.addView(libRoot, libLp)
            libAdded = true
        } catch (e: Exception) {
            libWanted = false
            out("${ERR}could not open the tap folder: ${e.message}")
            return
        }
        libBackdrop.theme = curTheme
        buildLibraryContent()
        libScroll.scrollTo(0, 0)
        libraryEnter()
    }

    private fun libraryEnter() {
        val reduced = reducedMotion()
        libCard.animate().cancel()
        libCard.alpha = 0f
        libCard.scaleX = 0.9f
        libCard.scaleY = 0.9f
        libCard.translationY = dp(28).toFloat()
        libCard.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(if (reduced) 0L else 340L).setInterpolator(OvershootInterpolator(1.1f)).start()
        libScrim.animate().cancel()
        libScrim.alpha = 0f
        libScrim.animate().alpha(1f).setDuration(if (reduced) 0L else 220L).start()
        libRoot.requestFocus()
    }

    private fun removeLibraryWindow() {
        imm.hideSoftInputFromWindow(libRoot.windowToken, 0)
        libList.removeAllViews()
        try { wm.removeView(libRoot) } catch (_: Exception) {}
        libAdded = false
    }

    /** Watch [imgs] right away (the folder closes, the run starts). */
    private fun libWatch(imgs: List<String>) {
        closeLibraryUi()
        term?.watchImages(imgs)
    }

    /** Two taps within 4 s on a dangerous button; the first tap only changes its label. */
    private fun libConfirmTap(key: String, button: TextView, action: () -> Unit) {
        val now = SystemClock.uptimeMillis()
        if (libConfirm == key && now - libConfirmAt < 4000L) {
            libConfirm = null
            action()
        } else {
            libConfirm = key
            libConfirmAt = now
            button.text = "tap again to delete"
        }
    }

    private fun libTogglePick(n: String) {
        if (!libSel.remove(n)) libSel.add(n)
        libName = null
        buildLibraryContent()
    }

    /** A free sequence name like watch-coin, watch-coin-gem, watch-coin-2 … */
    private fun libSuggestName(): String {
        val base = ("watch-" + libSel.joinToString("-")).replace(Regex("[^A-Za-z0-9_-]"), "").take(36).trimEnd('-')
        val taken = store.seqNames().toSet()
        if (base !in taken) return base
        var k = 2
        while ("$base-$k" in taken) k++
        return "$base-$k"
    }

    private fun thumb(n: String, sizePx: Int?): android.widget.ImageView = android.widget.ImageView(this).apply {
        scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        store.tpl(n)?.let { setImageBitmap(it) }
        background = GradientDrawable().apply {
            setColor(withAlpha(Color.BLACK, 0x55))
            cornerRadius = dp(6).toFloat()
        }
        val pad = if (sizePx != null) dp(2) else dp(4)
        setPadding(pad, pad, pad, pad)
        contentDescription = n
    }

    private fun imageTile(th: Theme, n: String): View {
        val picked = n in libSel
        val order = libSel.indexOf(n)
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(6))
            isClickable = true
            isFocusable = true
            contentDescription = if (libSel.isEmpty()) "$n. Tap to watch it, long-press to pick several" else "$n, ${if (picked) "picked" else "not picked"}"
            background = GradientDrawable().apply {
                setColor(if (picked) withAlpha(th.promptColor, 0x30) else withAlpha(Color.BLACK, 0x33))
                setStroke(if (picked) dp(2) else dp(1), if (picked) th.promptColor else withAlpha(th.chipStroke, 0x77))
                cornerRadius = dp(10).toFloat()
            }
            // nothing picked: one tap starts watching this image. Picking (long-press) switches taps to pick/unpick.
            setOnClickListener { if (libSel.isEmpty()) libWatch(listOf(n)) else libTogglePick(n) }
            setOnLongClickListener {
                libTogglePick(n)
                true
            }
        }
        tile.addView(thumb(n, null), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))
        tile.addView(TextView(this).apply {
            text = (if (picked) "✓${order + 1} " else "") + n
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = th.chipFont
            setTextColor(if (picked) th.promptColor else th.logColor)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        return tile
    }

    private fun newImageTile(th: Theme): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(5), dp(5), dp(5), dp(6))
        isClickable = true
        isFocusable = true
        contentDescription = "Snap a new image"
        background = GradientDrawable().apply {
            setColor(withAlpha(th.promptColor, 0x14))
            setStroke(dp(1), withAlpha(th.promptColor, 0xAA), dp(5).toFloat(), dp(4).toFloat())
            cornerRadius = dp(10).toFloat()
        }
        addView(TextView(this@OverlayService).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            setTextColor(th.promptColor)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))
        addView(TextView(this@OverlayService).apply {
            text = "new image"
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = th.chipFont
            setTextColor(th.promptColor)
            setPadding(0, dp(4), 0, 0)
        })
        setOnClickListener {
            closeLibraryUi()
            expandPanel()
            closeEditor()
            out("type a name for the new image and press go, then drag a box around it")
            // the keyboard needs the panel to have focus, so wait until the folder has gone
            main.postDelayed({ startTyping("snap ") }, 300L)
        }
    }

    private fun seqRow(th: Theme, sn: String): View {
        val steps = store.loadSeq(sn)?.first ?: emptyList()
        val kind = SeqKind.of(steps)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(withAlpha(Color.BLACK, 0x33))
                setStroke(dp(1), withAlpha(th.chipStroke, 0x77))
                cornerRadius = dp(10).toFloat()
            }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(TextView(this).apply {
            text = sn
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(th.chipFont, Typeface.BOLD)
            setTextColor(th.logColor)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(TextView(this).apply {
            text = when (kind) {
                SeqKind.WATCH -> "watch · ${steps.size} image(s)"
                SeqKind.STEPS -> "${steps.size} step(s)"
                SeqKind.MIXED -> "watch + other steps"
                SeqKind.EMPTY -> "empty"
            }
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = th.logFont
            setTextColor(if (kind == SeqKind.MIXED) ERR_COLOR else th.hintColor)
        })
        box.addView(top)
        // thumbnails of the images it uses
        val used = steps.filter { it.isImage }.map { it.tpl }.distinct()
        if (used.isNotEmpty()) {
            val strip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(6), 0, dp(2))
            }
            for (n in used.take(6)) {
                strip.addView(thumb(n, dp(40)), LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(5) })
            }
            if (used.size > 6) strip.addView(TextView(this).apply {
                text = "+${used.size - 6}"
                setTextColor(th.hintColor)
                gravity = Gravity.CENTER_VERTICAL
            })
            box.addView(strip)
        }
        val runnable = kind == SeqKind.WATCH || kind == SeqKind.STEPS
        val buttons = ArrayList<View>()
        if (kind == SeqKind.WATCH) {
            buttons.add(pill(th, "watch", Icon.PLAY) { closeLibraryUi(); term?.runSaved(sn, -1) })
        } else if (runnable) {
            buttons.add(pill(th, "run ∞", Icon.LOOP) { closeLibraryUi(); term?.runSaved(sn, -1) })
            buttons.add(pill(th, "run 1×", Icon.PLAY) { closeLibraryUi(); term?.runSaved(sn, 1) })
        }
        buttons.add(pill(th, "load", Icon.LIST) {
            closeLibraryUi()
            expandPanel()
            closeEditor()
            term?.exec("load $sn")
            term?.exec("steps")
        })
        lateinit var del: TextView
        del = pill(th, "delete", Icon.CLEAR) {
            libConfirmTap("seq:$sn", del) {
                term?.exec("rm $sn")
                buildLibraryContent()
            }
        }
        buttons.add(del)
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        grid(buttons, 4, dp(6), holder)
        box.addView(holder)
        return box
    }

    /** (Re)builds the folder page: how it works, picked images bar, image grid, saved sequences. */
    private fun buildLibraryContent() {
        val th = curTheme
        val keepY = libScroll.scrollY
        libList.removeAllViews()
        libCard.background = GradientDrawable().apply {
            setColor(th.menuBg)
            cornerRadius = (min(th.cornerDp, 18f) + 4f) * density
        }
        val p = libBackdrop.padPx
        libList.setPadding(p + dp(12), p + dp(10), p + dp(12), p + dp(18))
        val cardW = (libCard.layoutParams?.width ?: dp(320)).let { if (it > 0) it else dp(320) }
        val cols = libCols(cardW)
        val gap = dp(8)
        val names = store.tplNames()
        libSel.retainAll(names.toSet())

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = "tap"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = th.titleFont
            setTextColor(th.titleColor)
            letterSpacing = min(th.titleSpacing, 0.12f)
            setShadowLayer(th.glowDp * density, 0f, 0f, th.glowColor)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(pill(th, "close", Icon.CLOSE) { closeLibraryUi() })
        libList.addView(head)

        sectionTitle(th, "images", "${names.size} saved", libList)
        libList.addView(textRow(th,
            if (libSel.isEmpty()) "Tap an image to watch it: it's tapped once every time it appears, and nothing else is tapped. " +
                "Go to another screen and nothing happens; come back and it taps again. Tap ■ to stop. Long-press to pick several."
            else "Tap images to pick or unpick them. Picked images are watched together."
        ))

        // picked images: watch them together or save them as a sequence
        if (libSel.isNotEmpty()) {
            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = GradientDrawable().apply {
                    setColor(withAlpha(th.promptColor, 0x22))
                    setStroke(dp(1), th.promptColor)
                    cornerRadius = dp(10).toFloat()
                }
            }
            bar.addView(TextView(this).apply {
                text = "picked: " + libSel.joinToString(", ")
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = th.chipFont
                setTextColor(th.logColor)
            })
            val nameRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, 0)
            }
            val edit = EditText(this).apply {
                setText(libName ?: libSuggestName())
                hint = "sequence name"
                setSingleLine(true)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = th.logFont
                setTextColor(th.inputColor)
                setHintTextColor(th.hintColor)
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                setPadding(dp(8), dp(6), dp(8), dp(6))
                background = GradientDrawable().apply {
                    setColor(withAlpha(Color.BLACK, 0x44))
                    setStroke(dp(1), withAlpha(th.chipStroke, 0x99))
                    cornerRadius = dp(8).toFloat()
                }
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) {
                        libName = e?.toString()
                    }
                })
            }
            nameRow.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            nameRow.addView(pill(th, "save", Icon.SAVE) {
                val n = edit.text.toString().trim()
                if (term?.saveWatch(n, libSel.toList()) == true) {
                    imm.hideSoftInputFromWindow(edit.windowToken, 0)
                    libSel.clear()
                    libName = null
                    buildLibraryContent()
                }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
            bar.addView(nameRow)
            val acts = ArrayList<View>()
            acts.add(pill(th, "watch", Icon.PLAY) { libWatch(libSel.toList()) })
            if (libSel.size == 1) {
                val only = libSel.first()
                acts.add(pill(th, "resnap", Icon.SNAP) {
                    closeLibraryUi()
                    libSel.clear()
                    term?.exec("resnap $only")
                })
            }
            lateinit var del: TextView
            del = pill(th, "delete", Icon.CLEAR) {
                libConfirmTap("img:" + libSel.joinToString(","), del) {
                    for (n in libSel.toList()) term?.exec("tpl rm $n")
                    libSel.clear()
                    buildLibraryContent()
                }
            }
            acts.add(del)
            acts.add(pill(th, "unpick", Icon.CLOSE) {
                libSel.clear()
                libName = null
                buildLibraryContent()
            })
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            grid(acts, 4, dp(6), holder)
            bar.addView(holder)
            libList.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = gap })
        }

        grid(names.map { imageTile(th, it) } + newImageTile(th), cols, gap, libList)

        val seqs = store.seqNames()
        sectionTitle(th, "sequences", if (seqs.isEmpty()) "none saved yet" else "${seqs.size} saved", libList)
        if (seqs.isEmpty()) {
            libList.addView(textRow(th, "Long-press images above to pick them, then tap save. Or build one in the terminal and type: save <name>"))
        }
        for (sn in seqs) {
            libList.addView(seqRow(th, sn), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = gap })
        }
        libList.addView(TextView(this).apply {
            text = "images are kept in ${store.root.absolutePath}/templates"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            typeface = th.logFont
            setTextColor(th.hintColor)
            setPadding(0, dp(14), 0, 0)
        })
        if (keepY > 0) libScroll.post { libScroll.scrollTo(0, keepY) }
    }

    override fun openLibrary() {
        main.post {
            closeStyleMenu()
            closeSettingsUi()
            openLibraryUi()
        }
    }

    // ------------------------------------------------------------------ Host

    override fun out(s: String) {
        val now = System.currentTimeMillis()
        main.post {
            val err = s.startsWith(ERR)
            logLines.addLast(LogLine(now, s, err))
            while (logLines.size > 400) logLines.removeFirst()
            if (err) store.appendError(dayFmt.format(Date(now)) + "  " + s.removePrefix(ERR))
            if (running || err) setMiniStatus(s, err)
            if (::logView.isInitialized) {
                if (panelAdded && !editorOpen) renderLog() else logDirty = true
            }
        }
    }

    /** Log with a dim timestamp on every line; errors in red. */
    private fun renderLog() {
        if (!::logView.isInitialized) return
        logDirty = false
        val th = curTheme
        val sb = SpannableStringBuilder()
        var first = true
        for (l in logLines) {
            if (!first) sb.append('\n')
            first = false
            val a = sb.length
            sb.append(clockFmt.format(Date(l.t)))
            sb.setSpan(ForegroundColorSpan(th.hintColor), a, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("  ")
            val b = sb.length
            sb.append(l.s)
            if (l.err) sb.setSpan(ForegroundColorSpan(ERR_COLOR), b, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        logView.text = sb
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun clearLog() {
        main.post {
            logLines.clear()
            renderLog()
        }
    }

    override fun capturer(): ScreenCapturer? = cap

    override fun hidePanel() {
        main.post { panelWanted = false; syncWindows() }
    }

    override fun exit() {
        main.post { shutdown() }
    }

    override suspend fun <T> withUiHidden(block: suspend () -> T): T {
        withContext(Dispatchers.Main) { uiVisible = false; syncWindows() }
        delay(450) // let the screen repaint without our windows
        try {
            return block()
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { uiVisible = true; syncWindows() }
        }
    }

    override suspend fun selectRegion(shot: Bitmap): Rect? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Rect?> { cont ->
            lateinit var view: RegionSelectorView
            view = RegionSelectorView(this@OverlayService, shot) { rect ->
                try { wm.removeView(view) } catch (_: Exception) {}
                if (cont.isActive) cont.resume(rect)
            }
            val lp = WindowManager.LayoutParams(
                shot.width, shot.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wm.addView(view, lp)
            cont.invokeOnCancellation {
                main.post { try { wm.removeView(view) } catch (_: Exception) {} }
            }
        }
    }

    override suspend fun pickPoint(): Point? = withContext(Dispatchers.Main) {
        val c = cap
        val dm = resources.displayMetrics
        val w = c?.width ?: dm.widthPixels
        val hgt = c?.height ?: dm.heightPixels
        suspendCancellableCoroutine<Point?> { cont ->
            lateinit var view: PointPickerView
            view = PointPickerView(this@OverlayService) { pt ->
                try { wm.removeView(view) } catch (_: Exception) {}
                if (cont.isActive) cont.resume(pt)
            }
            val lp = WindowManager.LayoutParams(
                w, hgt, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wm.addView(view, lp)
            cont.invokeOnCancellation {
                main.post { try { wm.removeView(view) } catch (_: Exception) {} }
            }
        }
    }

    override fun mark(r: Rect) {
        main.post {
            if (!alive || finished) return@post
            val c = cap ?: return@post
            val v = HighlightView(this, r)
            val lp = WindowManager.LayoutParams(
                c.width, c.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            try {
                wm.addView(v, lp)
                main.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {} }, 1200)
            } catch (_: Exception) {
            }
        }
    }
}

/** Wraps an [Icon] as a Drawable so it can sit inside buttons and menu rows. */
private class IconDrawable(private val icon: Icon, private var color: Int, private val size: Int) : Drawable() {
    override fun draw(canvas: Canvas) {
        val b = bounds
        Icons.draw(canvas, icon, b.exactCenterX(), b.exactCenterY(), min(b.width(), b.height()).toFloat(), color)
    }

    override fun setAlpha(alpha: Int) {
        color = withAlpha(color, alpha)
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = size

    override fun getIntrinsicHeight(): Int = size
}
