package app.imageclicker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * PARTICLE BURST: a honeycomb of hexagon cells around a central core (run / stop), every cell
 * (outline + icon) made of particles. Opening, they stream in from all over and assemble; once a
 * cell has formed it turns crisp. Pressing a cell bursts it into particles that rush back together
 * as it activates; closing scatters everything. The selected cell shimmers in the accent colour.
 */
class ParticleCanvas : StyleCanvas() {
    // particle state, flat arrays for speed
    private var count = 0
    private var px = FloatArray(0)
    private var py = FloatArray(0)
    private var vx = FloatArray(0)
    private var vy = FloatArray(0)
    private var tx = FloatArray(0)
    private var ty = FloatArray(0)
    private var k = FloatArray(0)
    private var owner = IntArray(0)
    private var start = IntArray(0)
    private var end = IntArray(0)

    private val crisp = ArrayList<Spring>()
    private var cellR = 0f
    private var cx = FloatArray(0)
    private var cy = FloatArray(0)
    private val hexPath = android.graphics.Path()
    private var built = false
    private var wasOpen = false
    private var quiet = true
    private val rnd = Random(4)

    private val tile = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint()
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.08f
    }
    private val rc = RectF()

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (crisp.size < n) crisp.add(Spring(0f, 160f, 0.9f))
        // only rebuild particles when the set of icons changes (e.g. run <-> stop)
        if (old.map { it.icon } != items.map { it.icon }) built = false
        if (w > 0f && !built) build()
    }

    override fun onSize() {
        build()
    }

    /** Bounding box of cell [i] (a pointy-top hexagon of radius [cellR]). */
    private fun tileRect(i: Int, out: RectF) {
        val hw = cellR * SQ3 / 2f
        out.set(cx[i] - hw, cy[i] - cellR, cx[i] + hw, cy[i] + cellR)
    }

    /** Corner [k] (0..5) of cell [i], drawn a little smaller than the honeycomb spacing. */
    private fun corner(i: Int, k: Int, scale: Float = 0.92f): Pair<Float, Float> {
        val a = Math.toRadians((60.0 * k - 90.0)).toFloat()
        return Pair(cx[i] + cos(a) * cellR * scale, cy[i] + sin(a) * cellR * scale)
    }

    private fun hex(i: Int, scale: Float = 0.92f): android.graphics.Path {
        hexPath.reset()
        for (k in 0 until 6) {
            val (x, y) = corner(i, k, scale)
            if (k == 0) hexPath.moveTo(x, y) else hexPath.lineTo(x, y)
        }
        hexPath.close()
        return hexPath
    }

    /** Places the cells: core in the middle, a ring of six, then the outer ring; fits and centres the cluster. */
    private fun layoutCells() {
        val cells = HONEY.take(n)
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        // in units of R
        val ux = FloatArray(n)
        val uy = FloatArray(n)
        for (i in 0 until n) {
            val (q, r) = cells.getOrElse(i) { Pair(i - 9, 3) }
            ux[i] = SQ3 * (q + r / 2f)
            uy[i] = 1.5f * r
            minX = min(minX, ux[i] - SQ3 / 2f)
            maxX = max(maxX, ux[i] + SQ3 / 2f)
            minY = min(minY, uy[i] - 1f)
            maxY = max(maxY, uy[i] + 1f)
        }
        cellR = min(min((w - d * 12f) / (maxX - minX), (h - d * 12f) / (maxY - minY)), d * 54f)
        val ox = (w - (maxX - minX) * cellR) / 2f - minX * cellR
        val oy = (h - (maxY - minY) * cellR) / 2f - minY * cellR
        cx = FloatArray(n) { ox + ux[it] * cellR }
        cy = FloatArray(n) { oy + uy[it] * cellR }
    }

    /** Samples every tile's outline and icon into particle targets. */
    private fun build() {
        if (n == 0 || w <= 0f) return
        layoutCells()
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        val own = ArrayList<Int>()
        val st = IntArray(n)
        val en = IntArray(n)
        val iconPx = (cellR * 0.75f).roundToInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(iconPx, iconPx, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val buf = IntArray(iconPx * iconPx)
        val step = max(2f, d * 2.6f)
        for (i in 0 until n) {
            st[i] = xs.size
            // outline: points along the six edges of the hexagon
            val side = cellR * 0.92f
            val perSide = (side / (d * 6f)).roundToInt().coerceAtLeast(2)
            for (k2 in 0 until 6) {
                val (x0, y0) = corner(i, k2)
                val (x1, y1) = corner(i, (k2 + 1) % 6)
                for (j in 0 until perSide) {
                    val f = j / perSide.toFloat()
                    xs.add(x0 + (x1 - x0) * f)
                    ys.add(y0 + (y1 - y0) * f)
                    own.add(i)
                }
            }
            // icon: render it and keep the opaque pixels
            bmp.eraseColor(0)
            Icons.draw(cv, items[i].icon, iconPx / 2f, iconPx / 2f, iconPx.toFloat(), Color.WHITE)
            bmp.getPixels(buf, 0, iconPx, 0, 0, iconPx, iconPx)
            val ox = cx[i] - iconPx / 2f
            val oy = cy[i] - cellR * 0.16f - iconPx / 2f
            var yy = 0f
            while (yy < iconPx) {
                var xx = 0f
                while (xx < iconPx) {
                    val a = buf[yy.toInt() * iconPx + xx.toInt()] ushr 24
                    if (a > 120) {
                        xs.add(ox + xx)
                        ys.add(oy + yy)
                        own.add(i)
                    }
                    xx += step
                }
                yy += step
            }
            en[i] = xs.size
        }
        count = xs.size
        tx = FloatArray(count) { xs[it] }
        ty = FloatArray(count) { ys[it] }
        owner = IntArray(count) { own[it] }
        start = st
        end = en
        k = FloatArray(count) { 130f + rnd.nextFloat() * 120f }
        px = FloatArray(count)
        py = FloatArray(count)
        vx = FloatArray(count)
        vy = FloatArray(count)
        scatterAll(far = true)
        for (i in 0 until n) crisp[i].snap(0f)
        built = true
        quiet = false
    }

    private fun scatterAll(far: Boolean) {
        for (j in 0 until count) {
            val a = rnd.nextFloat() * 6.283f
            val r = (if (far) max(w, h) * (0.6f + rnd.nextFloat() * 0.6f) else d * 40f)
            px[j] = w / 2f + cos(a) * r
            py[j] = h / 2f + sin(a) * r
            vx[j] = 0f
            vy[j] = 0f
        }
    }

    /** Blows tile [i] apart from its centre. */
    private fun burst(i: Int, power: Float) {
        for (j in start[i] until end[i]) {
            val dx = px[j] - cx[i]
            val dy = py[j] - cy[i]
            val len = max(1f, hypot(dx, dy))
            val p = power * (0.6f + rnd.nextFloat() * 0.8f)
            vx[j] += dx / len * p
            vy[j] += dy / len * p
        }
        crisp[i].snap(0f)
        quiet = false
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        if (!built) return moving
        val opening = open.target > 0.5f
        if (opening && !wasOpen) {
            if (reduced) {
                for (j in 0 until count) {
                    px[j] = tx[j]
                    py[j] = ty[j]
                }
            } else scatterAll(far = true)
            quiet = false
        }
        if (!opening && wasOpen && !reduced) {
            for (i in 0 until n) burst(i, d * 900f)
        }
        wasOpen = opening
        if (!quiet && !reduced) {
            val h2 = dt.coerceAtMost(0.033f)
            var maxV = 0f
            for (j in 0 until count) {
                val kk = k[j]
                val ax: Float
                val ay: Float
                if (opening) {
                    ax = kk * (tx[j] - px[j]) - 12f * vx[j]
                    ay = kk * (ty[j] - py[j]) - 12f * vy[j]
                } else {
                    ax = -1.5f * vx[j]
                    ay = -1.5f * vy[j]
                }
                vx[j] += ax * h2
                vy[j] += ay * h2
                px[j] += vx[j] * h2
                py[j] += vy[j] * h2
                val v = kotlin.math.abs(vx[j]) + kotlin.math.abs(vy[j])
                if (v > maxV) maxV = v
            }
            // opening: quiet once every particle has landed; closing: once the cloud has faded out
            quiet = if (opening) maxV < d * 3f else open.value < 0.02f
            moving = true
        }
        for (i in 0 until n) {
            // a tile turns crisp once its particles have arrived
            var off = 0f
            if (built && end[i] > start[i]) {
                var j = start[i]
                while (j < end[i]) {
                    off = max(off, kotlin.math.abs(px[j] - tx[j]) + kotlin.math.abs(py[j] - ty[j]))
                    j += 3
                }
            }
            crisp[i].to(if (opening && (off < d * 3f || reduced) && i != pressed) 1f else 0f, reduced)
            crisp[i].step(dt)
            if (!crisp[i].settled) moving = true
        }
        return moving
    }

    override val ambient: Boolean get() = !quiet || idx(selected) >= 0

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0 || !built) return
        if (open.value < 0.01f && open.target < 0.5f && quiet) return
        val sel = idx(selected)
        val accent = th.promptColor
        val sz = max(1.5f, d * 1.8f)
        // particles
        for (j in 0 until count) {
            val i = owner[j]
            val cr = crisp[i].value
            if (cr > 0.98f && i != sel) continue
            val base = if (i == sel) accent else th.logColor
            dot.color = withAlpha(base, (230 * (1f - cr * 0.85f)).roundToInt())
            var x = px[j]
            var y = py[j]
            if (i == sel && !reduced) {
                x += sin(t * 6f + j) * d * 0.8f
                y += cos(t * 5f + j * 1.3f) * d * 0.8f
            }
            c.drawRect(x - sz / 2f, y - sz / 2f, x + sz / 2f, y + sz / 2f, dot)
        }
        // crisp tiles fade in over their particles
        for (i in 0 until n) {
            val cr = crisp[i].value.coerceIn(0f, 1f)
            if (cr < 0.02f) continue
            val a = (255 * cr).roundToInt()
            val hot = i == sel
            val core = i == 0 && items[0].primary
            val body = if (hot) mix(th.chipBg or (0xFF shl 24), accent, 0.35f) else if (core) mix(th.chipBg or (0xFF shl 24), accent, 0.15f) else th.chipBg
            tile.color = withAlpha(body, (((th.chipBg ushr 24).coerceAtLeast(0x90)) * cr).roundToInt())
            val path = hex(i)
            c.drawPath(path, tile)
            edge.strokeWidth = if (hot || core) d * 2f else d * 1f
            edge.color = withAlpha(if (hot || core) accent else th.chipStroke, a)
            c.drawPath(path, edge)
            val item = items[i]
            Icons.draw(c, item.icon, cx[i], cy[i] - cellR * 0.16f, cellR * 0.75f,
                withAlpha(if (hot) Color.WHITE else if (item.toggle && item.on) accent else th.chipText, a))
            label.textSize = min(d * 10.5f, cellR * 0.24f)
            label.color = withAlpha(th.chipText, a)
            c.drawText(fit(label, item.short.uppercase(), cellR * 1.3f), cx[i], cy[i] + cellR * 0.55f, label)
            if (item.toggle) {
                dot.color = withAlpha(if (item.on) accent else th.hintColor, a)
                c.drawCircle(cx[i], cy[i] - cellR * 0.68f, d * 3f, dot)
            }
        }
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || !built) return -1
        // point-in-hexagon (pointy-top), using the full honeycomb spacing so there are no dead gaps
        for (i in 0 until n) {
            val dx = kotlin.math.abs(x - cx[i])
            val dy = kotlin.math.abs(y - cy[i])
            if (dx <= cellR * SQ3 / 2f && dy <= cellR - dx / SQ3) return i
        }
        return -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n || !built) return false
        tileRect(i, out)
        return true
    }

    companion object {
        private val SQ3 = kotlin.math.sqrt(3f)

        /** Axial hex coordinates: the core, the ring of six (clockwise from the top right), then the outer ring. */
        private val HONEY = listOf(
            0 to 0,
            1 to -1, 1 to 0, 0 to 1, -1 to 1, -1 to 0, 0 to -1,
            2 to 0, -2 to 0, -1 to 2, 1 to -2, 2 to -1, -2 to 1, 2 to -2, -2 to 2, 1 to 1, -1 to -1, 0 to 2, 0 to -2
        )
    }

    override fun onDown(i: Int, x: Float, y: Float) {
        super.onDown(i, x, y)
        if (i >= 0 && !reduced) burst(i, d * 260f)
    }

    override fun onUp(i: Int, click: Boolean) {
        super.onUp(i, click)
        quiet = false
    }

    override fun cancelPress() {
        super.cancelPress()
        quiet = false
    }
}
