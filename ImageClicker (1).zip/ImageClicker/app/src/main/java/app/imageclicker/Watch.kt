package app.imageclicker

/** What a watcher decided about one image after one look at the screen. */
enum class WatchEvent { NONE, TAP, RETAP, GONE }

/**
 * "Tap once per appearance" for one watched image.
 *
 * - The image shows up: tap it once.
 * - While it stays on screen: nothing (unless [againMs] > 0 and it's still there that long after the tap).
 * - It disappears (you went to another screen, or it closed): the watcher re-arms, but only after it has
 *   been missing for [goneScans] looks in a row, so a single blurry frame doesn't cause a double tap.
 * - It shows up again: tap it once more.
 *
 * Pure logic with no Android types, so it is unit-tested.
 */
class WatchState(private val againMs: Long = 0, private val goneScans: Int = 2) {
    /** True when the next sighting will be tapped. */
    var armed = true
        private set
    var taps = 0
        private set
    var visible = false
        private set
    private var tappedAt = 0L
    private var missing = 0

    fun update(seen: Boolean, now: Long): WatchEvent {
        visible = seen
        if (seen) {
            missing = 0
            if (armed) {
                armed = false
                tappedAt = now
                taps++
                return WatchEvent.TAP
            }
            if (againMs > 0 && now - tappedAt >= againMs) {
                tappedAt = now
                taps++
                return WatchEvent.RETAP
            }
            return WatchEvent.NONE
        }
        if (!armed) {
            missing++
            if (missing >= goneScans) {
                armed = true
                missing = 0
                return WatchEvent.GONE
            }
        }
        return WatchEvent.NONE
    }
}
