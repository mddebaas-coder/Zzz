package app.imageclicker

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * CLASSIC: the original ☰ dropdown, rebuilt on the style system. A themed card grows out of its
 * top-right corner, rows slide in one after another, a ripple spreads from your finger, the open
 * pane gets an accent bar, and toggles have a real switch whose knob springs across.
 */
class ClassicCanvas : StyleCanvas() {
    private val rowIn = ArrayList<Spring>()
    private val knob = ArrayList<Spring>()
    private val bar = Spring(0f, 260f, 0.75f, 0.5f)
    private val ripple = Spring(0f, 90f, 1f, 0.01f)
    private var rippleX = 0f
    private var rippleY = 0f
    private var rippleRow = -1
    private val scroll = Spring(0f, 170f, 0.9f, 0.5f)
    private var rowH = 0f
    private val pad get() = d * 6f

    private val card = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rc = RectF()
    private val sw = RectF()

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (rowIn.size < n) rowIn.add(Spring(0f, 320f, 0.82f))
        while (knob.size < n) knob.add(Spring(0f, 420f, 0.62f))
        for (i in 0 until n) if (items[i].toggle && old.isEmpty()) knob[i].snap(if (items[i].on) 1f else 0f)
        if (w > 0f) onSize()
    }

    override fun onSize() {
        rowH = ((h - pad * 2) / max(1, n)).coerceIn(d * 40f, d * 48f)
        val i = idx(selected)
        if (i >= 0) bar.snap(rowTop(i))
    }

    private val contentH: Float get() = n * rowH + pad * 2
    private val maxScroll: Float get() = max(0f, contentH - h)

    private fun rowTop(i: Int): Float = pad + i * rowH - scroll.value

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val o = open.value
        for (i in 0 until n) {
            val ready = !opening || o > 0.1f + 0.5f * i / max(1, n - 1)
            rowIn[i].to(if (opening && ready) 1f else if (opening) rowIn[i].target else 0f, reduced)
            rowIn[i].step(dt)
            knob[i].to(if (items[i].on) 1f else 0f, reduced)
            knob[i].step(dt)
            if (!rowIn[i].settled || !knob[i].settled) moving = true
        }
        val s = idx(selected)
        if (s >= 0) bar.to(pad + s * rowH, reduced)
        bar.step(dt)
        ripple.step(dt)
        scroll.step(dt)
        if (!bar.settled || !ripple.settled || !scroll.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = false

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value
        if (o < 0.01f && open.target < 0.5f) return
        val e = MotionMath.clamp01(o)
        // the card grows from the top-right corner
        val cw = w * (0.55f + 0.45f * MotionMath.easeOutCubic(e))
        val ch = min(h, contentH) * (0.3f + 0.7f * MotionMath.easeOutCubic(e))
        rc.set(w - cw, 0f, w, ch)
        val radius = min(th.cornerDp, 16f) * d
        card.color = withAlpha(th.menuBg, (alphaOf(th.menuBg) * e).roundToInt().coerceIn(0, 255))
        c.drawRoundRect(rc, radius, radius, card)
        stroke.strokeWidth = d
        stroke.color = withAlpha(th.chipStroke, (alphaOf(th.chipStroke) * e).roundToInt())
        c.drawRoundRect(rc, radius, radius, stroke)

        c.save()
        c.clipRect(rc)
        // accent bar beside the open pane
        val sel = idx(selected)
        if (sel >= 0) {
            val by = bar.value - scroll.value
            fill.color = withAlpha(th.chipStroke, 0x30)
            c.drawRect(rc.left + d * 3f, by + d * 2f, rc.right - d * 3f, by + rowH - d * 2f, fill)
            fill.color = th.promptColor or (0xFF shl 24)
            c.drawRoundRect(rc.left + d * 3f, by + d * 8f, rc.left + d * 6f, by + rowH - d * 8f, d * 2f, d * 2f, fill)
        }
        text.typeface = th.chipFont
        text.textSize = d * 13f
        for (i in 0 until n) {
            val r = rowIn[i].value
            if (r < 0.01f) continue
            val top = rowTop(i)
            if (top > h || top + rowH < 0f) continue
            val dx = (1f - r) * d * 16f
            val a = (255 * MotionMath.clamp01(r)).roundToInt()
            val item = items[i]
            // ripple from the finger on the pressed row
            if (i == rippleRow && ripple.value < 0.999f) {
                val rad = hypot(rc.width(), rowH) * ripple.value
                fill.color = withAlpha(th.chipStroke, (0x60 * (1f - ripple.value)).roundToInt())
                c.save()
                c.clipRect(rc.left, top, rc.right, top + rowH)
                c.drawCircle(rippleX, rippleY, rad, fill)
                c.restore()
            } else if (i == pressed) {
                fill.color = withAlpha(th.chipStroke, 0x40)
                c.drawRect(rc.left, top, rc.right, top + rowH, fill)
            }
            val cy = top + rowH / 2f
            val ink = withAlpha(th.menuText, a)
            Icons.draw(c, item.icon, rc.left + d * 24f + dx, cy, d * 18f, ink)
            text.color = ink
            val right = if (item.toggle) rc.right - d * 50f else rc.right - d * 12f
            c.drawText(fit(text, item.label, right - (rc.left + d * 44f + dx)), rc.left + d * 44f + dx, mid(text, cy), text)
            if (item.toggle) drawSwitch(c, rc.right - d * 40f + dx, cy, knob[i].value, a)
        }
        c.restore()
    }

    private fun alphaOf(c: Int): Int = (c ushr 24) and 0xFF

    private fun drawSwitch(c: Canvas, x: Float, cy: Float, k: Float, a: Int) {
        val tw = d * 30f
        val th2 = d * 16f
        sw.set(x, cy - th2 / 2f, x + tw, cy + th2 / 2f)
        val on = th.promptColor or (0xFF shl 24)
        fill.color = withAlpha(mix(withAlpha(th.menuText, 0x55), on, MotionMath.clamp01(k)), a)
        c.drawRoundRect(sw, th2 / 2f, th2 / 2f, fill)
        fill.color = withAlpha(th.menuBg or (0xFF shl 24), a)
        val kx = sw.left + th2 / 2f + (tw - th2) * k
        c.drawCircle(kx, cy, th2 / 2f - d * 2f, fill)
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f) return -1
        val i = ((y - pad + scroll.value) / rowH).toInt()
        return if (y >= 0f && i in 0 until n && x >= w * 0.0f) i else -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        val top = rowTop(i)
        if (top > h || top + rowH < 0f) return false
        out.set(0f, top, w, top + rowH)
        return true
    }

    override fun onDown(i: Int, x: Float, y: Float) {
        super.onDown(i, x, y)
        if (i >= 0) {
            rippleRow = i
            rippleX = x
            rippleY = y
            ripple.snap(0f)
            ripple.to(1f, reduced)
        }
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (maxScroll <= 0f || abs(dy) < abs(dx)) return false
        scroll.snap((scroll.value - dy).coerceIn(-d * 40f, maxScroll + d * 40f))
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        scroll.to((scroll.value - vy * 0.2f).coerceIn(0f, maxScroll), reduced)
    }
}
