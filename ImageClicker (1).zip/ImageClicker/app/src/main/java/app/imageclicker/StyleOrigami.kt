package app.imageclicker

import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * ORIGAMI: the menu is a strip of paper folded like an accordion. Opening, the panels unfold one
 * after another along their creases (real 3D hinges, shaded by angle); closing folds them back up
 * from the bottom. A ribbon bookmark slides to the selected panel and its corner dog-ears over.
 * Pressing creases a panel inwards. Serif italic labels with roman numerals.
 */
class OrigamiCanvas : StyleCanvas() {
    private val fold = ArrayList<Spring>()
    private val press = ArrayList<Spring>()
    private val ribbon = Spring(0f, 220f, 0.7f, 0.5f)
    private val ear = Spring(0f, 260f, 0.55f)
    private var stripH = 0f
    private var top = 0f
    private val camera = Camera()
    private val m = Matrix()
    private var fiber = Array(70) { FloatArray(4) }

    private val paper = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val crease = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC) }
    private val numeral = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        letterSpacing = 0.1f
    }
    private val ribbonPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rc = RectF()

    private val n get() = items.size

    init {
        val r = Random(11)
        fiber = Array(70) { floatArrayOf(r.nextFloat(), r.nextFloat(), r.nextFloat() * 6.28f, 0.3f + r.nextFloat()) }
    }

    override fun onItems(old: List<MenuItem>) {
        while (fold.size < n) fold.add(Spring(90f, 180f, 0.78f, 0.2f))
        while (press.size < n) press.add(Spring(0f, 400f, 0.5f, 0.2f))
        if (w > 0f) onSize()
    }

    override fun onSize() {
        top = d * 40f
        stripH = max(d * 34f, (h - top - d * 6f) / max(1, n))
    }

    override fun onSelect(old: String?, new: String?) {
        ear.snap(0f)
        ear.to(1f, reduced)
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        for (i in 0 until n) {
            val target = if (opening) {
                // unfold top to bottom: each panel waits for the one above to open most of the way
                if (i == 0 || fold[i - 1].value < 35f) 0f else 90f
            } else {
                // fold back up from the bottom
                if (i == n - 1 || fold[i + 1].value > 55f) 90f else 0f
            }
            // folding away is quicker than unfolding (exits should not keep you waiting)
            fold[i].stiffness = if (opening) 180f else 560f
            fold[i].to(target, reduced)
            fold[i].step(dt)
            press[i].to(if (i == pressed) 18f else 0f, reduced)
            press[i].step(dt)
            if (!fold[i].settled || !press[i].settled) moving = true
        }
        val sel = idx(selected)
        if (sel >= 0) {
            ribbon.to(top + sel * stripH, reduced)
        }
        ribbon.step(dt)
        ear.step(dt)
        if (!ribbon.settled || !ear.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = false

    private fun paperColor(): Int = mix(Color.WHITE, th.menuBg or (0xFF shl 24), 0.12f) or (0xFF shl 24)

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val anyOpen = fold.any { it.value < 89f }
        if (!anyOpen && open.target < 0.5f) return
        val col = paperColor()

        // title card (always flat, slides down with the first panel)
        val f0 = (90f - fold[0].value) / 90f
        if (f0 > 0.01f) {
            rc.set(d * 8f, top - d * 34f, w - d * 8f, top - d * 4f)
            paper.color = withAlpha(col, (255 * f0).roundToInt())
            c.drawRect(rc, paper)
            ink.textSize = d * 15f
            ink.color = withAlpha(mix(th.promptColor, Color.BLACK, 0.4f), (255 * f0).roundToInt())
            c.drawText("Menu", rc.left + d * 12f, mid(ink, rc.centerY()), ink)
            numeral.textSize = d * 9f
            numeral.color = withAlpha(Color.BLACK, (120 * f0).roundToInt())
            val folded = "folded paper"
            c.drawText(folded, rc.right - numeral.measureText(folded) - d * 10f, mid(numeral, rc.centerY()), numeral)
        }

        // accordion panels: each hinges on the bottom edge of the one above
        var y = top
        for (i in 0 until n) {
            val a = fold[i].value + press[i].value * (if (i % 2 == 0) 1f else -1f)
            val dir = if (i % 2 == 0) 1f else -1f
            val projected = stripH * cos(Math.toRadians(a.toDouble())).toFloat().coerceAtLeast(0f)
            if (a < 89.5f) {
                c.save()
                c.translate(w / 2f, y)
                camera.save()
                camera.rotateX(a * dir)
                camera.getMatrix(m)
                camera.restore()
                c.concat(m)
                c.translate(-w / 2f, 0f)
                drawPanel(c, i, a, dir, col)
                c.restore()
            }
            y += projected
        }

        // ribbon bookmark on the left edge
        val sel = idx(selected)
        if (sel >= 0 && fold.getOrNull(sel)?.value ?: 90f < 20f) {
            val ry = ribbon.value
            ribbonPaint.color = th.promptColor or (0xFF shl 24)
            path.reset()
            path.moveTo(d * 2f, ry + d * 4f)
            path.lineTo(d * 14f, ry + d * 4f)
            path.lineTo(d * 14f, ry + stripH - d * 2f)
            path.lineTo(d * 8f, ry + stripH - d * 9f)
            path.lineTo(d * 2f, ry + stripH - d * 2f)
            path.close()
            c.drawPath(path, ribbonPaint)
        }
    }

    private fun drawPanel(c: Canvas, i: Int, angle: Float, dir: Float, col: Int) {
        val item = items[i]
        rc.set(d * 8f, 0f, w - d * 8f, stripH)
        paper.shader = LinearGradient(0f, 0f, 0f, stripH, col, mix(col, Color.BLACK, 0.06f), Shader.TileMode.CLAMP)
        c.drawRect(rc, paper)
        paper.shader = null
        // paper fibres
        for (f in fiber) {
            val fx = rc.left + f[0] * rc.width()
            val fy = f[1] * stripH
            crease.strokeWidth = d * 0.5f
            crease.color = withAlpha(Color.BLACK, 0x10)
            c.drawLine(fx, fy, fx + cos(f[2]) * d * 6f * f[3], fy + sin(f[2]) * d * 6f * f[3], crease)
        }
        // crease line at the hinge and fold shading that deepens with the angle
        crease.strokeWidth = d * 1f
        crease.color = withAlpha(Color.BLACK, 0x26)
        c.drawLine(rc.left, 0f, rc.right, 0f, crease)
        val k = abs(sin(Math.toRadians(angle.toDouble()))).toFloat()
        shade.shader = LinearGradient(
            0f, 0f, 0f, stripH,
            withAlpha(Color.BLACK, ((if (dir > 0) 0.15f else 0.55f) * 255 * k).roundToInt()),
            withAlpha(Color.BLACK, ((if (dir > 0) 0.55f else 0.15f) * 255 * k).roundToInt()),
            Shader.TileMode.CLAMP
        )
        c.drawRect(rc, shade)

        val selected = item.id == this.selected
        val inkCol = mix(th.promptColor, Color.BLACK, 0.45f) or (0xFF shl 24)
        numeral.textSize = d * 10f
        numeral.color = withAlpha(Color.BLACK, 0x80)
        c.drawText(ROMAN.getOrElse(i) { "${i + 1}" }, rc.left + d * 20f, mid(numeral, stripH / 2f), numeral)
        Icons.draw(c, item.icon, rc.left + d * 58f, stripH / 2f, min(stripH * 0.55f, d * 20f), withAlpha(inkCol, if (item.toggle && !item.on) 0x70 else 0xFF))
        ink.textSize = min(d * 15f, stripH * 0.45f)
        ink.color = if (selected) inkCol else withAlpha(Color.BLACK, 0xC8)
        val label = item.label + if (item.toggle) (if (item.on) " — on" else " — off") else ""
        c.drawText(fit(ink, label, rc.right - (rc.left + d * 76f) - d * 24f), rc.left + d * 76f, mid(ink, stripH / 2f), ink)

        // dog-eared corner on the selected panel
        if (selected) {
            val e = ear.value.coerceIn(0f, 1.2f) * min(stripH * 0.6f, d * 20f)
            path.reset()
            path.moveTo(rc.right, 0f)
            path.lineTo(rc.right - e, 0f)
            path.lineTo(rc.right, e)
            path.close()
            paper.color = withAlpha(Color.BLACK, 0x30)
            c.drawPath(path, paper)
            path.reset()
            path.moveTo(rc.right - e, 0f)
            path.lineTo(rc.right - e, e)
            path.lineTo(rc.right, e)
            path.close()
            paper.color = mix(col, th.promptColor, 0.25f) or (0xFF shl 24)
            c.drawPath(path, paper)
        }
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || y < top) return -1
        val i = ((y - top) / stripH).toInt()
        return if (i in 0 until n && fold[i].value < 30f) i else -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        out.set(0f, top + i * stripH, w, top + (i + 1) * stripH)
        return true
    }

    companion object {
        val ROMAN = listOf("i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii")
    }
}
