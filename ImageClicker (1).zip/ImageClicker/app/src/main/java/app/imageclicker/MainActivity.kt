package app.imageclicker

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Setup screen: grant the 3 things the overlay needs, then launch it. */
class MainActivity : Activity() {

    private companion object {
        const val REQ_CAPTURE = 1001
        const val REQ_NOTIF = 1002
    }

    private lateinit var status: TextView

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "Image Clicker"
            textSize = 26f
        })
        col.addView(TextView(this).apply {
            text = OverlayService.PROJECT_LABEL
            textSize = 13f
            setTextColor(Color.GRAY)
        })
        col.addView(TextView(this).apply {
            text = "Overlay terminal that finds images on screen and taps them in a sequence."
            setPadding(0, pad / 2, 0, pad)
        })

        // the app crashed last time: show why, so it can be copied and sent
        val crash = CrashLog.read(this)
        if (crash != null) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
                setBackgroundColor(0x22FF0000)
            }
            box.addView(TextView(this).apply {
                text = "The app crashed last time:\n" + CrashLog.summary(crash)
                setTextColor(0xFFD32F2F.toInt())
                textSize = 14f
            })
            box.addView(TextView(this).apply {
                text = crash.lines().take(14).joinToString("\n")
                textSize = 10f
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(0, pad / 2, 0, pad / 2)
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "Copy crash report"
                isAllCaps = false
                setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Image Clicker crash", crash))
                    text = "Copied"
                }
            })
            row.addView(Button(this).apply {
                text = "Clear"
                isAllCaps = false
                setOnClickListener {
                    CrashLog.clear(this@MainActivity)
                    box.visibility = View.GONE
                }
            })
            box.addView(row)
            col.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = pad
            })
        }

        status = TextView(this).apply { setPadding(0, 0, 0, pad) }
        col.addView(status)

        col.addView(button("1. Allow draw-over-apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("2. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(TextView(this).apply {
            text = "If the toggle is greyed out (sideloaded APK on Android 13+): Settings > Apps > Image Clicker > " +
                "three-dot menu > Allow restricted settings, then try again."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, pad / 2)
        })
        col.addView(button("3. Start overlay terminal") { startOverlay() })
        col.addView(button("Stop overlay") {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_EXIT))
            refresh()
        })

        col.addView(TextView(this).apply {
            text = "\nAfter starting, open your app. Tap the green >_ bubble to open the terminal and type 'help'."
            textSize = 13f
        })

        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val a11y = ClickerAccessibilityService.instance != null
        val running = OverlayService.alive
        fun mark(ok: Boolean) = if (ok) "[x]" else "[ ]"
        status.text = "${mark(overlay)} draw over apps\n" +
            "${mark(a11y)} accessibility service\n" +
            "${mark(running)} overlay running"
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow 'draw over apps' first (step 1)."
            return
        }
        if (OverlayService.alive) {
            status.text = "Overlay is already running. Tap the green >_ bubble."
            return
        }
        if (ClickerAccessibilityService.instance == null) {
            status.text = status.text.toString() + "\nNote: accessibility is off, so runs will not be able to tap (step 2)."
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_START)
                .putExtra(OverlayService.EXTRA_CODE, resultCode)
                .putExtra(OverlayService.EXTRA_DATA, data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else {
            status.text = "Screen capture permission was denied."
        }
    }
}
