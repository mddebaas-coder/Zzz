package app.imageclicker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * LIQUID GLASS: a frosted glass shelf with a drop of glass per item. A coloured liquid indicator
 * (two metaballs: a fast head and a lagging tail) flows to whatever you press or select; while it
 * travels it stretches and melts into the drops it passes (gooey merging). Thin, airy typography.
 */
class GlassCanvas : StyleCanvas() {
    private val head = Spring(0f, 240f, 0.58f, 0.5f)
    private val tail = Spring(0f, 110f, 0.78f, 0.5f)
    private val tip = Spring(0f, 320f, 0.62f)
    private val rise = ArrayList<Spring>()
    private val swell = ArrayList<Spring>()
    private var focus = 0
    private var lastPicked = 0
    private val shelf = RectF()
    private var slot = 0f
    private var dropR = 0f

    // CPU goo field (fallback when AGSL is unavailable)
    private var cell = 2f
    private var gx0 = 0f
    private var gy0 = 0f
    private var gw = 0
    private var gh = 0
    private var gpx = IntArray(0)
    private var gbmp: Bitmap? = null
    private var gooDirty = true
    private val gdst = RectF()
    private var goo: Shader? = null
    private var gooTried = false

    private val shelfFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shelfRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val gooPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tipFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tipRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        letterSpacing = 0.06f
    }
    private val tmp = RectF()

    private val n get() = items.size

    override fun onSize() {
        layout()
    }

    override fun onItems(old: List<MenuItem>) {
        while (rise.size < n) rise.add(Spring(0f, 200f, 0.62f))
        while (swell.size < n) swell.add(Spring(0f, 420f, 0.5f))
        if (w > 0f) layout()
    }

    override fun onSelect(old: String?, new: String?) {
        gooDirty = true
    }

    private var laidW = -1f
    private var laidH = -1f
    private var laidN = -1

    /** Rebuilds geometry only when the size or the number of items changed (not on label/toggle refreshes). */
    private fun layout() {
        if (w == laidW && h == laidH && n == laidN) return
        laidW = w
        laidH = h
        laidN = n
        val sw = w - d * 16f
        shelf.set((w - sw) / 2f, h - d * 76f, (w + sw) / 2f, h - d * 14f)
        slot = if (n > 0) shelf.width() / n else shelf.width()
        dropR = min(d * 17f, slot * 0.4f)
        cell = 2f * d
        gx0 = shelf.left - d * 8f
        gy0 = shelf.top - d * 70f
        gw = ((shelf.width() + d * 16f) / cell).roundToInt().coerceAtLeast(1)
        gh = ((shelf.bottom - gy0 + d * 6f) / cell).roundToInt().coerceAtLeast(1)
        gpx = IntArray(gw * gh)
        gbmp = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
        gdst.set(gx0, gy0, gx0 + gw * cell, gy0 + gh * cell)
        head.snap(cx(focus))
        tail.snap(cx(focus))
        gooDirty = true
    }

    private fun cx(i: Int): Float = shelf.left + slot * (i + 0.5f)

    /** Spread 0.25..1 while the shelf grows open: everything expands out of the centre. */
    private var spread = 1f
    private var wasOpening = false

    private fun px(i: Int): Float = shelf.centerX() + (cx(i) - shelf.centerX()) * spread
    private fun cy(): Float = shelf.centerY()

    private fun dropY(i: Int): Float = cy() + (1f - rise.getOrNull(i)?.value.orZero()) * d * 64f
    private fun dropRad(i: Int): Float {
        val r = rise.getOrNull(i)?.value.orZero().coerceIn(0f, 1.2f)
        return dropR * (0.35f + 0.65f * r) * (1f + 0.32f * swell.getOrNull(i)?.value.orZero())
    }

    private fun Float?.orZero(): Float = this ?: 0f

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val o = open.value
        val sel = idx(selected)
        focus = when {
            pressed >= 0 -> pressed
            sel >= 0 -> sel
            else -> lastPicked.coerceIn(0, max(0, n - 1))
        }
        val opening = open.target > 0.5f
        for (i in 0 until n) {
            // drops rise one after another while opening (centre first), all sink together when closing
            val order = abs(i - (n - 1) / 2f) / max(1f, n / 2f)
            val target = if (opening) (if (o >= 0.05f + 0.45f * order) 1f else rise[i].target) else 0f
            rise[i].to(target, reduced)
            rise[i].step(dt)
            swell[i].to(if (i == pressed) 1f else 0f, reduced)
            swell[i].step(dt)
            if (!rise[i].settled || !swell[i].settled) moving = true
        }
        if (opening && !wasOpening && open.value < 0.6f) {
            // the liquid is poured in from the middle of the shelf
            head.snap(shelf.centerX())
            tail.snap(shelf.centerX())
        }
        wasOpening = opening
        spread = 0.25f + 0.75f * open.value.coerceIn(0f, 1f)
        head.to(px(focus), reduced)
        head.step(dt)
        tail.to(head.value, reduced)
        tail.step(dt)
        tip.to(if (open.target > 0.5f && n > 0) 1f else 0f, reduced)
        tip.step(dt)
        if (!head.settled || !tail.settled || !tip.settled) moving = true
        if (moving) gooDirty = true
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    // ---- goo ----

    private class Ball(var x: Float, var y: Float, var r: Float)

    private val balls = ArrayList<Ball>()

    private fun buildBalls(): Int {
        balls.clear()
        val o = open.value.coerceIn(0f, 1f)
        for (i in 0 until n) balls.add(Ball(px(i), dropY(i), dropRad(i)))
        val liquidR = d * 20f * o
        balls.add(Ball(head.value, cy(), liquidR))
        balls.add(Ball(tail.value, cy(), liquidR * 0.72f))
        return n
    }

    private fun renderGooCpu(glass: Int, accent: Int, rim: Int) {
        val b = gbmp ?: return
        val glassN = buildBalls()
        val bx = FloatArray(balls.size) { balls[it].x }
        val by = FloatArray(balls.size) { balls[it].y }
        val br = FloatArray(balls.size) { balls[it].r * balls[it].r }
        var k = 0
        for (row in 0 until gh) {
            val y = gy0 + (row + 0.5f) * cell
            for (col in 0 until gw) {
                val x = gx0 + (col + 0.5f) * cell
                var gl = 0f
                var lq = 0f
                for (j in bx.indices) {
                    if (br[j] <= 0f) continue
                    val dx = x - bx[j]
                    val dy = y - by[j]
                    val q = br[j] / (dx * dx + dy * dy + 1f)
                    val f = q * q // sharper falloff: drops stay separate, only the liquid bridges them
                    if (j < glassN) gl += f else lq += f
                }
                val f = gl + lq
                val a = smooth(0.9f, 1.1f, f)
                if (a <= 0f) {
                    gpx[k++] = 0
                    continue
                }
                val mixK = smooth(0.3f, 0.7f, if (f > 0f) lq / f else 0f)
                var c = mix(glass, accent, mixK)
                val edge = smooth(0.9f, 1.05f, f) * (1f - smooth(1.05f, 1.7f, f))
                c = mix(c, rim, edge * 0.4f)
                gpx[k++] = withAlpha(c, ((c ushr 24) * a).roundToInt())
            }
        }
        b.setPixels(gpx, 0, gw, 0, 0, gw, gh)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun drawGooAgsl(c: Canvas, glass: Int, accent: Int, rim: Int): Boolean {
        if (!gooTried && kit.hw) {
            gooTried = true
            goo = Agsl.make(Agsl.GOO)
        }
        val s = goo ?: return false
        val glassN = buildBalls()
        // the six glass drops closest to the liquid head join the field; the rest are drawn as plain drops
        val order = (0 until glassN).sortedBy { abs(balls[it].x - head.value) }
        val names = arrayOf("g0", "g1", "g2", "g3", "g4", "g5")
        val inField = HashSet<Int>()
        for (j in names.indices) {
            val bi = order.getOrNull(j)
            if (bi == null) {
                Agsl.float(s, names[j], 0f, 0f, 0f)
            } else {
                inField.add(bi)
                Agsl.float(s, names[j], balls[bi].x, balls[bi].y, balls[bi].r)
            }
        }
        val l0 = balls[glassN]
        val l1 = balls[glassN + 1]
        Agsl.float(s, "l0", l0.x, l0.y, l0.r)
        Agsl.float(s, "l1", l1.x, l1.y, l1.r)
        Agsl.color(s, "glass", glass)
        Agsl.color(s, "accent", accent)
        Agsl.color(s, "rim", rim)
        gooPaint.shader = s
        c.drawRect(gdst, gooPaint)
        gooPaint.shader = null
        gooPaint.color = glass
        for (i in 0 until glassN) if (i !in inField) c.drawCircle(balls[i].x, balls[i].y, balls[i].r, gooPaint)
        return true
    }

    // ---- drawing ----

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value.coerceIn(0f, 1.2f)
        if (o < 0.01f && open.target < 0.5f) return
        val glass = withAlpha(mix(th.menuBg, Color.WHITE, 0.18f), 0xD8)
        val accent = withAlpha(th.promptColor, 0xF0)
        val rim = withAlpha(Color.WHITE, 0xC0)

        // frosted shelf, grows from the centre
        val sw = shelf.width() * (0.25f + 0.75f * o.coerceAtMost(1f))
        tmp.set(shelf.centerX() - sw / 2f, shelf.top, shelf.centerX() + sw / 2f, shelf.bottom)
        val rad = shelf.height() / 2f
        shelfFill.shader = LinearGradient(
            0f, tmp.top, 0f, tmp.bottom,
            intArrayOf(withAlpha(mix(th.menuBg, Color.WHITE, 0.35f), (0xB0 * o.coerceAtMost(1f)).roundToInt()),
                withAlpha(th.menuBg, (0xC8 * o.coerceAtMost(1f)).roundToInt())),
            null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(tmp, rad, rad, shelfFill)
        shelfRim.strokeWidth = d
        shelfRim.color = withAlpha(Color.WHITE, (0x70 * o.coerceAtMost(1f)).roundToInt())
        c.drawRoundRect(tmp, rad, rad, shelfRim)
        // light gliding over the glass
        if (!reduced) {
            val sx = tmp.left + ((t * 0.18f) % 1.6f - 0.3f) * tmp.width()
            sheen.shader = LinearGradient(sx - d * 40f, 0f, sx + d * 40f, 0f,
                intArrayOf(0, withAlpha(Color.WHITE, 0x30), 0), null, Shader.TileMode.CLAMP)
            c.save()
            c.clipRect(tmp)
            c.drawRect(tmp.left, tmp.top, tmp.right, tmp.top + tmp.height() * 0.5f, sheen)
            c.restore()
        }

        // drops + liquid
        if (!drawGooAgsl(c, glass, accent, rim)) {
            if (gooDirty) {
                renderGooCpu(glass, accent, rim)
                gooDirty = false
            }
            gbmp?.let { c.drawBitmap(it, null, gdst, bmpPaint) }
        }

        // highlights + icons
        for (i in 0 until n) {
            val r = dropRad(i)
            if (r < d * 4f) continue
            val x = px(i)
            val y = dropY(i)
            hl.color = withAlpha(Color.WHITE, 0x55)
            tmp.set(x - r * 0.55f, y - r * 0.78f, x + r * 0.1f, y - r * 0.35f)
            c.drawOval(tmp, hl)
            val onLiquid = abs(head.value - x) < slot * 0.35f
            val col = if (onLiquid) Color.WHITE else if (items[i].toggle && items[i].on) th.promptColor else th.chipText
            icon(c, items[i], x, y, r * 1.05f, col)
            if (items[i].toggle && items[i].on) {
                hl.color = th.promptColor
                c.drawCircle(x, y + r + d * 4f, d * 2f, hl)
            }
        }

        // tooltip label riding above the liquid
        val tp = tip.value
        if (tp > 0.02f) {
            val item = items[focus.coerceIn(0, n - 1)]
            label.textSize = d * 13f
            label.color = th.menuText
            val txt = fit(label, item.label, w * 0.6f)
            val tw = label.measureText(txt) + d * 22f
            val th2 = d * 28f
            val x = head.value.coerceIn(tw / 2f + d * 4f, w - tw / 2f - d * 4f)
            val y = shelf.top - d * 22f
            c.save()
            c.translate(x, y)
            c.scale(tp, tp)
            tmp.set(-tw / 2f, -th2 / 2f, tw / 2f, th2 / 2f)
            tipFill.color = withAlpha(mix(th.menuBg, Color.WHITE, 0.2f), 0xE6)
            c.drawRoundRect(tmp, th2 / 2f, th2 / 2f, tipFill)
            tipRim.strokeWidth = d
            tipRim.color = withAlpha(Color.WHITE, 0x80)
            c.drawRoundRect(tmp, th2 / 2f, th2 / 2f, tipRim)
            c.drawText(txt, 0f, mid(label, 0f), label)
            c.restore()
        }
    }

    override fun hit(x: Float, y: Float): Int {
        if (n == 0 || open.value < 0.5f) return -1
        if (y < shelf.top - d * 16f || y > shelf.bottom + d * 14f) return -1
        if (x < shelf.left || x > shelf.right) return -1
        return ((x - shelf.left) / slot).toInt().coerceIn(0, n - 1)
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        val half = max(slot / 2f, d * 24f)
        out.set(cx(i) - half, shelf.top - d * 8f, cx(i) + half, shelf.bottom + d * 8f)
        return true
    }

    override fun activate(i: Int) {
        lastPicked = i
        super.activate(i)
    }

    /** Sliding a finger along the shelf drags the liquid with it (and ticks per item). */
    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (abs(dx) < abs(dy)) return false
        val i = hit(x, shelf.centerY())
        if (i >= 0 && i != pressed) {
            pressed = i
            kit.haptic(Haptic.TICK)
        }
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        val i = pressed
        pressed = -1
        if (i >= 0) activate(i)
    }

}
