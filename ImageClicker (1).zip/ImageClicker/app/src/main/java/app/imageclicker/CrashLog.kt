package app.imageclicker

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * If the app crashes, the reason is written to a file before Android closes it. The next time the
 * app opens, the setup screen and the terminal show it, so it can be copied and sent.
 */
object CrashLog {
    private const val FILE = "last_crash.txt"

    @Volatile
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                write(app, t, e)
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    private fun write(ctx: Context, t: Thread, e: Throwable) {
        val trace = StringWriter().also { e.printStackTrace(PrintWriter(it)) }.toString()
        val text = buildString {
            append("Image Clicker ").append(version(ctx)).append(" crashed\n")
            append("time: ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).append('\n')
            append("phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            append("thread: ").append(t.name).append('\n')
            append(trace.take(12000))
        }
        File(ctx.filesDir, FILE).writeText(text)
    }

    @Suppress("DEPRECATION")
    private fun version(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    fun read(ctx: Context): String? {
        val f = File(ctx.filesDir, FILE)
        return if (f.exists()) f.readText() else null
    }

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    /** Exception line + the first line of our own code, e.g. "IllegalArgumentException: … (StyleBlob.kt:209)". */
    fun summary(text: String): String {
        val lines = text.lines()
        val ex = lines.firstOrNull { it.contains("Exception") || it.contains("Error") } ?: lines.getOrElse(4) { "" }
        val at = lines.firstOrNull { it.trim().startsWith("at app.imageclicker") }
            ?.substringAfter("(")?.substringBefore(")")
        return ex.trim().removePrefix("java.lang.") + (if (at != null) " ($at)" else "")
    }
}
