package app.imageclicker

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeProvider
import kotlin.math.hypot

/**
 * Hosts one [StyleCanvas]: runs its frame loop, turns touches into press / drag / fling / click,
 * maps haptics, honours reduced motion, and exposes every item to TalkBack as a virtual button.
 */
@SuppressLint("ViewConstructor")
class StyleView(ctx: Context, val style: StyleCanvas, val kit: Kit) : View(ctx) {

    /** Called with the item id when the user activates an item. */
    var onPickId: (String) -> Unit = {}

    /** Milliseconds between frames while idle-animating (previews use a lower rate). */
    var idleFrameMs = 16L

    /** When > 16, every frame (not only idle ones) is spaced this far apart; used by gallery previews. */
    var frameCapMs = 0L

    /** False for gallery previews: touches go to the tile underneath, TalkBack skips the items. */
    var interactive = true
        set(v) {
            field = v
            isClickable = v
            isFocusable = v
            importantForAccessibility = if (v) IMPORTANT_FOR_ACCESSIBILITY_YES else IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }

    /** Called once when a close animation has fully finished (every item spring at rest). */
    var onClosed: (() -> Unit)? = null

    /** A tap that started and ended away from every item (used to dismiss the menu). */
    var onOutsideTap: (() -> Unit)? = null

    /**
     * Called once if the style throws while animating, drawing or handling a touch. The view then
     * stops running that style (and shows a short notice) instead of crashing the whole app.
     */
    var onError: ((Throwable) -> Unit)? = null

    /** Set after the style threw; nothing of it runs any more. */
    var failed: Throwable? = null
        private set

    private fun fail(e: Throwable) {
        if (failed != null) return
        failed = e
        val cb = onError
        if (cb != null) ui.post { cb(e) }
        invalidate()
    }

    private val errPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF6B6B.toInt()
        textSize = 12f * ctx.resources.displayMetrics.density
    }

    private var closedFired = true

    /**
     * Callbacks leave the draw pass before they run: styles may report a pick from update()
     * (after a swing or morph), and the host may remove this very view in response.
     */
    private val ui = Handler(Looper.getMainLooper())
    private var previewClock = 0f
    private val visible = Rect()

    private val start = SystemClock.uptimeMillis()
    private var last = 0L
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var downIndex = -1
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    private var tracker: VelocityTracker? = null
    private val tmp = RectF()

    init {
        style.kit = kit
        kit.haptic = { type -> buzz(type) }
        style.onPick = { i ->
            val item = style.items.getOrNull(i)
            if (item != null) {
                sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_CLICKED)
                val id = item.id
                ui.post { onPickId(id) }
            }
        }
        isClickable = true
        isFocusable = true
        isHapticFeedbackEnabled = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    companion object {
        /** True when the user turned animations off (Settings > Accessibility > Remove animations). */
        fun reducedMotion(): Boolean = !ValueAnimator.areAnimatorsEnabled()
    }

    fun setItems(list: List<MenuItem>) {
        if (failed != null) return
        try {
            style.items = list
        } catch (e: Exception) {
            fail(e)
        }
        invalidate()
    }

    fun setOpen(open: Boolean) {
        style.open.to(if (open) 1f else 0f, kit.reduced)
        closedFired = open
        invalidate()
    }

    /** Offsets the gallery loop so neighbouring previews are not in lockstep. */
    fun setPreviewPhase(seconds: Float) {
        previewClock = seconds
    }

    /** Re-reads colours after the theme changed. */
    fun themeChanged(th: Theme) {
        kit.theme = th
        if (failed == null) {
            try {
                style.onTheme()
            } catch (e: Exception) {
                fail(e)
            }
        }
        invalidate()
    }

    /**
     * Gallery loop: open, show the selection moving across a few panes, close, repeat.
     * Driven by the frame clock so it pauses when the preview is off screen.
     */
    private fun previewStep(dt: Float) {
        previewClock += dt
        val cycle = 6.2f
        val p = previewClock % cycle
        val wantOpen = p < 5f
        if (wantOpen != (style.open.target > 0.5f)) style.open.to(if (wantOpen) 1f else 0f, kit.reduced)
        style.selected = when {
            p < 1.6f -> null
            p < 2.8f -> "log"
            p < 4.0f -> "settings"
            else -> "thr"
        }
    }

    private fun buzz(type: Int) {
        val c = when (type) {
            Haptic.TICK -> HapticFeedbackConstants.CLOCK_TICK
            Haptic.PRESS -> HapticFeedbackConstants.VIRTUAL_KEY
            Haptic.CONFIRM -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.KEYBOARD_TAP
            else -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
        }
        performHapticFeedback(c)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        if (failed != null) return
        try {
            style.size(w, h)
        } catch (e: Exception) {
            fail(e)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = 0L
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val err = failed
        if (err != null) {
            canvas.drawText("this style hit an error: " + (err.javaClass.simpleName), 8f * kit.d, 20f * kit.d, errPaint)
            return
        }
        try {
            frame(canvas)
        } catch (e: Exception) {
            fail(e)
        }
    }

    private fun frame(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceIn(0f, 0.064f)
        last = now
        val t = ((now - start) % 3_600_000L) / 1000f
        kit.hw = canvas.isHardwareAccelerated
        if (style.preview) previewStep(dt)
        val moving = style.update(dt, t)
        applyEffect(t)
        style.draw(canvas, t)
        if (!moving && !closedFired && style.open.target < 0.5f) {
            closedFired = true
            onClosed?.let { cb -> ui.post { cb() } }
        }
        if (!isAttachedToWindow || !isShown) return
        // previews only animate while some of them is on screen; scrolling the gallery invalidates them again
        if (style.preview && !getLocalVisibleRect(visible)) return
        val keepGoing = moving || style.preview || (style.ambient && !kit.reduced)
        if (!keepGoing) return
        val gap = if (frameCapMs > 16L) frameCapMs else if (moving) 0L else idleFrameMs
        if (gap <= 17L) postInvalidateOnAnimation() else postInvalidateDelayed(gap)
    }

    // ------------------------------------------------------------------ AGSL view effect

    private var fx: Shader? = null
    private var fxFailed = false
    private var fxOn = false

    private fun applyEffect(t: Float) {
        val src = style.viewEffect
        val want = src != null && Agsl.on && !kit.reduced && !fxFailed
        if (!want) {
            if (fxOn) {
                Effect33.clear(this)
                fxOn = false
            }
            return
        }
        val s = fx ?: Agsl.make(src!!).also { fx = it }
        if (s == null) {
            fxFailed = true
            return
        }
        Agsl.float(s, "size", width.toFloat().coerceAtLeast(1f), height.toFloat().coerceAtLeast(1f))
        Agsl.float(s, "time", t)
        Agsl.float(s, "amount", style.effectAmount(t))
        fxOn = Effect33.apply(this, s)
        if (!fxOn) fxFailed = true
    }

    // ------------------------------------------------------------------ touch

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        if (failed != null) {
            // a broken style still lets you tap it away
            if (e.actionMasked == MotionEvent.ACTION_UP) onOutsideTap?.let { cb -> ui.post { cb() } }
            return true
        }
        return try {
            touch(e)
        } catch (ex: Exception) {
            fail(ex)
            true
        }
    }

    private fun touch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tracker?.recycle()
                tracker = VelocityTracker.obtain().also { it.addMovement(e) }
                downX = e.x
                downY = e.y
                lastX = e.x
                lastY = e.y
                dragging = false
                downIndex = style.hit(e.x, e.y)
                style.onDown(downIndex, e.x, e.y)
                if (downIndex >= 0) kit.haptic(Haptic.PRESS)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(e)
                val dx = e.x - lastX
                val dy = e.y - lastY
                if (!dragging && hypot(e.x - downX, e.y - downY) > slop) {
                    if (style.onDrag(e.x - downX, e.y - downY, e.x, e.y)) {
                        dragging = true
                        style.cancelPress()
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                } else if (dragging) {
                    style.onDrag(dx, dy, e.x, e.y)
                }
                lastX = e.x
                lastY = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                tracker?.addMovement(e)
                if (dragging) {
                    val tr = tracker
                    if (tr != null) {
                        tr.computeCurrentVelocity(1000)
                        style.onFling(tr.xVelocity, tr.yVelocity)
                    } else {
                        style.onFling(0f, 0f)
                    }
                } else {
                    val up = style.hit(e.x, e.y)
                    val click = downIndex >= 0 && up == downIndex
                    style.onUp(downIndex, click)
                    if (click) performClick()
                    if (downIndex < 0 && up < 0) onOutsideTap?.let { cb -> ui.post { cb() } }
                }
                tracker?.recycle()
                tracker = null
                dragging = false
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) style.onFling(0f, 0f) else style.onUp(downIndex, false)
                tracker?.recycle()
                tracker = null
                dragging = false
                invalidate()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    // ------------------------------------------------------------------ accessibility (TalkBack)

    private fun nodeLabel(item: MenuItem): String =
        if (item.toggle) item.label + if (item.on) ", on" else ", off" else item.label

    private val provider = object : AccessibilityNodeProvider() {
        override fun createAccessibilityNodeInfo(virtualViewId: Int): AccessibilityNodeInfo? {
            if (virtualViewId == View.NO_ID) {
                @Suppress("DEPRECATION")
                val info = AccessibilityNodeInfo.obtain(this@StyleView)
                onInitializeAccessibilityNodeInfo(info)
                info.contentDescription = "Menu"
                for (i in style.items.indices) info.addChild(this@StyleView, i)
                return info
            }
            val item = style.items.getOrNull(virtualViewId) ?: return null
            @Suppress("DEPRECATION")
            val info = AccessibilityNodeInfo.obtain(this@StyleView, virtualViewId)
            info.setParent(this@StyleView)
            info.packageName = context.packageName
            info.className = "android.widget.Button"
            info.contentDescription = nodeLabel(item)
            info.isEnabled = true
            info.isClickable = true
            info.isFocusable = true
            if (item.toggle) {
                info.isCheckable = true
                info.isChecked = item.on
            }
            info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)
            val known = failed == null && try {
                style.itemBounds(virtualViewId, tmp)
            } catch (e: Exception) {
                false
            }
            if (known) {
                val loc = IntArray(2)
                getLocationOnScreen(loc)
                val r = Rect(tmp.left.toInt(), tmp.top.toInt(), tmp.right.toInt(), tmp.bottom.toInt())
                @Suppress("DEPRECATION")
                info.setBoundsInParent(r)
                r.offset(loc[0], loc[1])
                info.setBoundsInScreen(r)
                info.isVisibleToUser = true
            }
            return info
        }

        override fun performAction(virtualViewId: Int, action: Int, arguments: Bundle?): Boolean {
            if (virtualViewId == View.NO_ID) return performAccessibilityAction(action, arguments)
            if (action == AccessibilityNodeInfo.ACTION_CLICK && virtualViewId in style.items.indices && failed == null) {
                try {
                    style.activate(virtualViewId)
                } catch (e: Exception) {
                    fail(e)
                }
                invalidate()
                return true
            }
            return false
        }
    }

    override fun getAccessibilityNodeProvider(): AccessibilityNodeProvider = provider

    /** Lets a hardware keyboard / switch access move between items with Tab + Enter. */
    private var keyFocus = -1

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent): Boolean {
        if (failed != null) return super.onKeyDown(keyCode, event)
        return try {
            key(keyCode, event)
        } catch (e: Exception) {
            fail(e)
            true
        }
    }

    private fun key(keyCode: Int, event: android.view.KeyEvent): Boolean {
        val n = style.items.size
        if (n == 0) return super.onKeyDown(keyCode, event)
        when (keyCode) {
            android.view.KeyEvent.KEYCODE_TAB, android.view.KeyEvent.KEYCODE_DPAD_RIGHT, android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                keyFocus = (keyFocus + 1) % n
                style.onDown(keyFocus, 0f, 0f)
                invalidate()
                return true
            }
            android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                keyFocus = if (keyFocus <= 0) n - 1 else keyFocus - 1
                style.onDown(keyFocus, 0f, 0f)
                invalidate()
                return true
            }
            android.view.KeyEvent.KEYCODE_ENTER, android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_SPACE -> {
                if (keyFocus in 0 until n) {
                    style.onUp(keyFocus, true)
                    invalidate()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

@android.annotation.TargetApi(33)
private object Effect33 {
    fun apply(v: View, s: Shader): Boolean = try {
        v.setRenderEffect(RenderEffect.createRuntimeShaderEffect(s as RuntimeShader, "content"))
        true
    } catch (e: Exception) {
        false
    }

    fun clear(v: View) {
        try {
            v.setRenderEffect(null)
        } catch (e: Exception) {
        }
    }
}
