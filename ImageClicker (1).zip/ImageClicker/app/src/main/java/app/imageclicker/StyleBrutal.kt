package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * KINETIC BRUTALIST: huge uppercase words in raw blocks with thick borders and hard shadows.
 * Blocks slam in from alternating sides, overshooting; scrolling makes the type slide sideways
 * with the speed of your finger; the selected block turns accent and grows, shoving the rest
 * down; a press pushes a block into its own shadow. No curves, no gradients.
 */
class BrutalCanvas : StyleCanvas() {
    private val slide = ArrayList<Spring>()
    private val tall = ArrayList<Spring>()
    private val push = ArrayList<Spring>()
    private val wide = ArrayList<Spring>()
    private val headH get() = d * 64f
    private val scroll = Spring(0f, 170f, 0.9f, 0.5f)
    private val kinetic = Spring(0f, 120f, 0.7f, 0.5f)
    private var baseH = 0f
    private var bigH = 0f

    private val block = Paint()
    private val line = Paint().apply { style = Paint.Style.STROKE }
    private val word = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        letterSpacing = -0.02f
    }
    private val mono = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val rc = RectF()

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (slide.size < n) slide.add(Spring(0f, 300f, 0.55f))
        while (tall.size < n) tall.add(Spring(0f, 260f, 0.6f, 0.5f))
        while (push.size < n) push.add(Spring(0f, 700f, 0.5f, 0.2f))
        while (wide.size < n) wide.add(Spring(0f, 240f, 0.62f))
        if (w > 0f) onSize()
    }

    override fun onSize() {
        baseH = max(d * 52f, min(d * 66f, h / 7.2f))
        bigH = baseH * 1.38f
        for (i in 0 until n) tall[i].snap(rowH(i, target = true))
    }

    private fun rowH(i: Int, target: Boolean = false): Float =
        if (target) (if (items.getOrNull(i)?.id == selected) bigH else baseH) else tall[i].value

    private fun rowTop(i: Int): Float {
        var y = headH + d * 8f - scroll.value
        for (k in 0 until i) y += tall[k].value + d * 6f
        return y
    }

    private val contentH: Float get() = (0 until n).sumOf { (tall[it].value + d * 6f).toDouble() }.toFloat() + d * 16f + headH
    private val maxScroll: Float get() = max(0f, contentH - h)

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val o = open.value
        for (i in 0 until n) {
            val ready = !opening || o > 0.04f + 0.4f * i / max(1, n - 1)
            slide[i].to(if (opening && ready) 1f else if (opening) slide[i].target else 0f, reduced)
            slide[i].step(dt)
            tall[i].to(rowH(i, target = true), reduced)
            tall[i].step(dt)
            push[i].to(if (i == pressed) 1f else 0f, reduced)
            push[i].step(dt)
            wide[i].to(if (items[i].id == selected) 1f else 0f, reduced)
            wide[i].step(dt)
            if (!slide[i].settled || !tall[i].settled || !push[i].settled || !wide[i].settled) moving = true
        }
        scroll.step(dt)
        kinetic.to(0f, reduced)
        kinetic.step(dt)
        if (!scroll.settled || !kinetic.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = false

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        if (slide.all { it.value < 0.01f } && open.target < 0.5f) return
        val accent = th.promptColor or (0xFF shl 24)
        val sel = idx(selected)
        val hard = d * 6f
        val border = d * 3.5f
        val o = MotionMath.clamp01(open.value)
        // raw paper wall with a coarse grid, wiped in from the top
        c.save()
        c.clipRect(0f, 0f, w, h * MotionMath.easeOutCubic(o))
        c.drawColor(PAPER)
        line.color = withAlpha(Color.BLACK, 0x14)
        line.strokeWidth = d
        var gx = d * 24f
        while (gx < w) { c.drawLine(gx, 0f, gx, h, line); gx += d * 24f }
        var gy = d * 24f - (scroll.value * 0.3f) % (d * 24f)
        while (gy < h) { c.drawLine(0f, gy, w, gy, line); gy += d * 24f }
        // giant outlined index of the selection, bottom right
        if (sel >= 0) {
            word.textSize = h * 0.42f
            word.style = Paint.Style.STROKE
            word.strokeWidth = d * 2f
            word.color = withAlpha(Color.BLACK, 0x30)
            val num = String.format("%02d", sel + 1)
            c.drawText(num, w - word.measureText(num) - d * 6f, h - d * 10f, word)
            word.style = Paint.Style.FILL
        }
        // header: MENU/ in heavy type over a thick rule
        val hy = headH - scroll.value
        if (hy > 0f) {
            word.textSize = d * 44f
            word.color = Color.BLACK
            val off = (1f - MotionMath.clamp01(slide.getOrNull(0)?.value ?: 1f)) * -w
            c.drawText("MENU/", d * 8f + off, hy - d * 12f, word)
            mono.textSize = d * 10f
            mono.color = Color.BLACK
            val meta = "${n} ITEMS — TAP. DRAG. GO."
            c.drawText(meta, w - mono.measureText(meta) - d * 12f + off * -1f, hy - d * 14f, mono)
            block.color = Color.BLACK
            c.drawRect(0f, hy - d * 6f, w * MotionMath.easeOutCubic(o), hy, block)
        }
        for (i in 0 until n) {
            val top = rowTop(i)
            val rh = tall[i].value
            if (top > h || top + rh < 0f) continue
            val s = slide[i].value
            if (s < 0.01f) continue
            val fromLeft = i % 2 == 0
            val off = (1f - s) * (w + hard * 2f) * (if (fromLeft) -1f else 1f)
            val pr = push[i].value * hard * 0.8f
            // asymmetric widths: rows hug alternate edges; the selection stretches full width
            val inset = (1f - wide[i].value) * d * (14f + 22f * ((i * 5) % 3))
            val l = d * 8f + off + pr + if (fromLeft) 0f else inset
            val r = w - d * 8f - hard + off + pr - if (fromLeft) inset else 0f
            val hot = i == sel
            val invert = !hot && i % 3 == 1
            // hard shadow
            block.color = Color.BLACK
            c.drawRect(l + hard - pr, top + hard - pr, r + hard - pr, top + rh + hard - pr, block)
            // block
            block.color = when {
                hot -> accent
                invert -> Color.BLACK
                else -> Color.WHITE
            }
            rc.set(l, top, r, top + rh)
            c.drawRect(rc, block)
            line.strokeWidth = border
            line.color = Color.BLACK
            c.drawRect(rc.left + border / 2f, rc.top + border / 2f, rc.right - border / 2f, rc.bottom - border / 2f, line)
            if (invert) {
                line.color = Color.WHITE
                line.strokeWidth = d
                c.drawRect(rc.left + border * 1.5f, rc.top + border * 1.5f, rc.right - border * 1.5f, rc.bottom - border * 1.5f, line)
            }
            val ink = if (invert) Color.WHITE else Color.BLACK
            // index number
            mono.textSize = d * 10f
            mono.color = ink
            c.drawText(String.format("%02d", i + 1), rc.left + d * 10f, rc.top + d * 16f, mono)
            if (items[i].toggle) {
                val st = if (items[i].on) "[ON]" else "[OFF]"
                c.drawText(st, rc.right - mono.measureText(st) - d * 10f, rc.top + d * 16f, mono)
            }
            // the huge word, fitted to the block; it lags behind its block and slides with scroll speed
            val label = items[i].label.uppercase()
            val room = rc.width() - d * 48f
            word.textSize = min(rh * 0.62f, d * 54f)
            val wantW = word.measureText(label)
            if (wantW > room) word.textSize = max(d * 18f, word.textSize * room / wantW)
            val lag = (1f - MotionMath.clamp01(s)) * d * 60f * (if (fromLeft) -1f else 1f)
            val kin = kinetic.value * (if (i % 2 == 0) 1f else -1f)
            word.color = ink
            val baseline = rc.bottom - rh * 0.16f
            c.drawText(fit(word, label, room + d * 30f), rc.left + d * 36f + lag + kin, baseline, word)
            // arrow block on the right
            Icons.draw(c, items[i].icon, rc.left + d * 18f, rc.top + rh * 0.6f, d * 18f, ink)
        }
        c.restore()
        // scroll position bar: a solid black tab on the right edge
        val ms = maxScroll
        if (ms > 0f) {
            val barH = max(d * 30f, h * h / contentH)
            val y = (h - barH) * (scroll.value / ms).coerceIn(0f, 1f)
            block.color = Color.BLACK
            c.drawRect(w - d * 5f, y, w, y + barH, block)
            block.color = accent
            c.drawRect(w - d * 4f, y + d, w - d, y + barH - d, block)
        }
    }

    companion object {
        const val PAPER = 0xFFEDEBE4.toInt()
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f) return -1
        for (i in 0 until n) {
            val top = rowTop(i)
            if (y >= top && y < top + tall[i].value + d * 6f) return i
        }
        return -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        val top = rowTop(i)
        if (top > h || top + tall[i].value < 0f) return false
        out.set(0f, max(0f, top), w, min(h, top + tall[i].value))
        return true
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (abs(dy) < abs(dx)) return false
        scroll.snap((scroll.value - dy).coerceIn(-d * 60f, maxScroll + d * 60f))
        // type slides sideways with the scroll speed
        kinetic.snap((kinetic.value + dy * 0.6f).coerceIn(-d * 50f, d * 50f))
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        scroll.to((scroll.value - vy * 0.22f).coerceIn(0f, maxScroll), reduced)
        kinetic.velocity = -vy * 0.02f
    }
}
