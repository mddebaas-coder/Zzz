package app.imageclicker

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * A search area in screen pixels (left, top, width, height): an image is only looked for inside it,
 * so a look-alike somewhere else on the screen can never be tapped.
 *
 * Which area applies: the step's own roi=, else the image's own area (`area coin`), else the area for
 * all images (`area all`), else the whole screen. Pure logic, unit-tested.
 */
data class Area(val x: Int, val y: Int, val w: Int, val h: Int) {
    val right: Int get() = x + w
    val bottom: Int get() = y + h

    override fun toString(): String = "$x,$y,$w,$h"

    companion object {
        /** "Gone" needs the score this far below thr, so a button scoring 0.89 at thr 0.90 still counts as there. */
        const val GONE_MARGIN = 0.05

        /** "x,y,w,h" -> Area, or null if it isn't four numbers with a positive size. */
        fun parse(s: String?): Area? {
            val p = s?.trim()?.split(",")?.map { it.trim().toIntOrNull() } ?: return null
            if (p.size != 4 || p.any { it == null }) return null
            return of(p.map { it!! })
        }

        fun of(l: List<Int>?): Area? {
            if (l == null || l.size != 4) return null
            val (x, y, w, h) = l
            if (x < 0 || y < 0 || w <= 0 || h <= 0) return null
            return Area(x, y, w, h)
        }

        /** The step's own roi wins, then the image's area, then the area for all images. null = whole screen. */
        fun pick(step: Area?, image: Area?, all: Area?): Area? = step ?: image ?: all

        /**
         * Makes the area usable for a [tw] x [th] image on a [sw] x [sh] screen: grows it around its centre
         * when it is too tight (a box dragged right around the button still finds it if it shifts a little),
         * and keeps it on the screen. A box bigger than the image is left as it is.
         */
        fun usable(a: Area, tw: Int, th: Int, sw: Int, sh: Int): Area {
            val padX = max(16, tw / 4)
            val padY = max(16, th / 4)
            var l = a.x
            var t = a.y
            var r = a.right
            var b = a.bottom
            val needW = tw + 2 * padX
            val needH = th + 2 * padY
            if (r - l < needW) {
                val cx = (l + r) / 2
                l = cx - needW / 2
                r = l + needW
            }
            if (b - t < needH) {
                val cy = (t + b) / 2
                t = cy - needH / 2
                b = t + needH
            }
            // keep it on the screen, sliding rather than shrinking when possible
            if (l < 0) { r -= l; l = 0 }
            if (t < 0) { b -= t; t = 0 }
            if (r > sw) { l -= r - sw; r = sw }
            if (b > sh) { t -= b - sh; b = sh }
            l = max(0, l)
            t = max(0, t)
            return Area(l, t, max(1, min(sw, r) - l), max(1, min(sh, b) - t))
        }

        /**
         * Two sightings are "the same place" when their centres are within max(8 px, 15 % of the image's
         * smaller side). A tap waits for two such sightings in a row: a one-off look-alike or something
         * still sliding across the screen never gets tapped.
         */
        fun samePlace(ax: Int, ay: Int, bx: Int, by: Int, tw: Int, th: Int): Boolean {
            val tol = max(8, (min(tw, th) * 0.15f).toInt())
            return abs(ax - bx) <= tol && abs(ay - by) <= tol
        }
    }
}
