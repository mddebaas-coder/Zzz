package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin

/**
 * RETRO TERMINAL: a green-screen menu that types itself out, character by character, with a
 * blinking block cursor. The selection is an inverse-video bar that moves in discrete line steps
 * and leaves a fading phosphor trail. Text glows; Android 13+ adds a curved CRT glass shader,
 * older phones get drawn scanlines and vignette. Closing deletes the text bottom-up.
 */
class TerminalCanvas : StyleCanvas() {
    private var typed = 0f
    private var bar = 0f
    private var barTarget = 0
    private var stepClock = 0f
    private var trail = FloatArray(0)
    private var lineH = 0f
    private var top = 0f
    private var lines: List<String> = emptyList()
    private var total = 0
    private var flash = -1
    private var flashT = 0f
    private var now = 0f
    private var lastPicked = 0

    private val bg = Paint()
    private val vignette = Paint()
    private val scan = Paint()
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        style = Paint.Style.STROKE
    }
    private val block = Paint()
    private val rc = RectF()

    private val n get() = items.size
    private val phosphor: Int get() = th.logColor or (0xFF shl 24)

    override val viewEffect: String get() = Agsl.CRT

    override fun onItems(old: List<MenuItem>) {
        lines = items.mapIndexed { i, it ->
            val box = if (it.toggle) (if (it.on) "[x] " else "[ ] ") else ""
            "${(i + 1).toString().padStart(if (items.size > 9) 2 else 1)}. $box${it.label.uppercase()}"
        }
        total = lines.sumOf { it.length + 1 } + HEADER.length
        if (trail.size != n) trail = FloatArray(n)
        if (w > 0f) onSize()
    }

    override fun onSize() {
        top = d * 34f
        // room for every line plus the prompt line under them
        lineH = max(d * 26f, (h - top - d * 34f) / max(1, n))
        bg.shader = LinearGradient(0f, 0f, 0f, h, mix(Color.BLACK, phosphor, 0.06f) or (0xFF shl 24), Color.BLACK, Shader.TileMode.CLAMP)
        vignette.shader = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.75f, intArrayOf(0, 0, withAlpha(Color.BLACK, 0xB0)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onTheme() {
        if (w > 0f) onSize()
    }

    override fun onSelect(old: String?, new: String?) {
        val i = idx(new)
        if (i >= 0) barTarget = i
    }

    override fun update(dt: Float, t: Float): Boolean {
        now = t
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val goal = if (opening) total.toFloat() else 0f
        if (reduced) typed = goal
        else if (typed != goal) {
            typed = if (opening) min(goal, typed + dt * 140f) else max(0f, typed - dt * 420f)
            moving = true
        }
        // the bar moves one line at a time (25 ms per line), lighting a phosphor trail
        val sel = idx(selected)
        if (pressed >= 0) barTarget = pressed else if (sel >= 0) barTarget = sel
        stepClock += dt
        if (bar.roundToInt() != barTarget) {
            if (reduced) bar = barTarget.toFloat()
            else if (stepClock > 0.025f) {
                stepClock = 0f
                val from = bar.roundToInt()
                if (from in trail.indices) trail[from] = 1f
                bar += sign(barTarget - bar)
            }
            moving = true
        }
        for (i in trail.indices) {
            if (trail[i] > 0.01f) {
                trail[i] *= exp(-dt * 5f)
                moving = true
            } else trail[i] = 0f
        }
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        if (typed <= 0f && open.target < 0.5f) return
        val o = open.value.coerceIn(0f, 1f)
        c.drawRect(0f, 0f, w, h, bg)
        text.textSize = min(d * 12.5f, lineH * 0.45f)
        glow.textSize = text.textSize
        glow.strokeWidth = d * 2.4f
        val left = d * 10f
        var budget = typed.toInt()

        // header
        val head = HEADER.take(budget.coerceAtLeast(0))
        budget -= HEADER.length
        drawGlowText(c, head, left, d * 20f, phosphor, 0xFF)
        if (budget > 0) {
            block.color = withAlpha(phosphor, 0x60)
            c.drawRect(left, d * 26f, left + (w - left * 2f) * min(1f, budget / 12f), d * 27f, block)
        }

        // trail + inverse-video bar
        for (i in 0 until n) {
            if (trail[i] > 0.02f) {
                block.color = withAlpha(phosphor, (90 * trail[i]).roundToInt())
                c.drawRect(left - d * 4f, top + i * lineH, w - d * 6f, top + (i + 1) * lineH - d * 2f, block)
            }
        }
        val bi = bar.roundToInt().coerceIn(0, n - 1)
        val barOn = typed >= total * 0.3f
        if (barOn) {
            val inv = if (flash == bi && now - flashT < 0.12f) withAlpha(Color.WHITE, 0xFF) else phosphor
            block.color = inv
            c.drawRect(left - d * 4f, top + bi * lineH, w - d * 6f, top + (bi + 1) * lineH - d * 2f, block)
        }

        // the lines, typed out
        for (i in 0 until n) {
            if (budget <= 0) break
            val full = fit(text, lines[i], w - left * 2f)
            val shown = full.take(budget)
            budget -= lines[i].length + 1
            val y = mid(text, top + i * lineH + (lineH - d * 2f) / 2f)
            val onBar = barOn && i == bi
            if (onBar) {
                text.color = Color.BLACK
                c.drawText(shown, left, y, text)
            } else {
                drawGlowText(c, shown, left, y, phosphor, if (items[i].toggle && !items[i].on) 0xA0 else 0xFF)
            }
            // block cursor at the end of the line being typed
            if (budget <= 0 && open.target > 0.5f) {
                val blink = reduced || (t * 2.2f % 1f) < 0.55f
                if (blink) {
                    val cx = left + text.measureText(shown) + d * 2f
                    block.color = if (onBar) Color.BLACK else phosphor
                    c.drawRect(cx, y - text.textSize * 0.8f, cx + text.textSize * 0.6f, y + d * 2f, block)
                }
            }
        }
        // idle cursor under the list once everything is typed
        if (budget > 0 && open.target > 0.5f && (reduced || (t * 2.2f % 1f) < 0.55f)) {
            val y = mid(text, top + n * lineH + d * 2f)
            if (y < h - d * 4f) {
                drawGlowText(c, ">", left, y, phosphor, 0xFF)
                block.color = phosphor
                val cx = left + text.measureText("> ")
                c.drawRect(cx, y - text.textSize * 0.8f, cx + text.textSize * 0.6f, y + d * 2f, block)
            }
        }

        // drawn CRT for phones without AGSL (the shader replaces this on Android 13+)
        if (!Agsl.on || reduced) {
            scan.color = withAlpha(Color.BLACK, 0x48)
            var y = 0f
            while (y < h) {
                c.drawRect(0f, y, w, y + d * 1f, scan)
                y += d * 2.5f
            }
            c.drawRect(0f, 0f, w, h, vignette)
            if (!reduced) {
                scan.color = withAlpha(phosphor, (6 + 4 * sin(t * 40f)).roundToInt().coerceAtLeast(0))
                c.drawRect(0f, 0f, w, h, scan)
            }
        }
        // power-on line while opening, power-off line while closing
        if (o < 0.98f && !reduced) {
            block.color = withAlpha(Color.WHITE, (200 * (1f - o)).roundToInt())
            val yy = h / 2f
            c.drawRect(w * (0.5f - 0.5f * o), yy - d, w * (0.5f + 0.5f * o), yy + d, block)
        }
    }

    private fun drawGlowText(c: Canvas, s: String, x: Float, y: Float, color: Int, alpha: Int) {
        if (s.isEmpty()) return
        if (!reduced) {
            glow.color = withAlpha(color, alpha / 5)
            c.drawText(s, x, y, glow)
        }
        text.color = withAlpha(color, alpha)
        c.drawText(s, x, y, text)
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || typed < total * 0.5f) return -1
        val i = ((y - top) / lineH).toInt()
        return if (y >= top && i in 0 until n) i else -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        out.set(0f, top + i * lineH, w, top + (i + 1) * lineH)
        return true
    }

    override fun activate(i: Int) {
        flash = i
        flashT = now
        lastPicked = i
        barTarget = i
        super.activate(i)
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        // dragging moves the bar like arrow keys
        if (abs(dy) < abs(dx)) return false
        val i = ((y - top) / lineH).toInt().coerceIn(0, n - 1)
        if (i != barTarget) {
            barTarget = i
            kit.haptic(Haptic.TICK)
        }
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        activate(barTarget)
    }

    companion object {
        const val HEADER = "MAIN MENU"
    }
}
