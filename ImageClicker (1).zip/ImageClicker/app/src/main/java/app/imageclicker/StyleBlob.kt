package app.imageclicker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * MORPHING BLOB: one living, wobbling shape that takes on the silhouette of the item in focus
 * (a gear for settings, a star for night, a capsule for run, a square for stop...). The other items
 * float as small droplets; tap one and the blob melts into its shape, then acts. Swipe across the
 * blob to browse without acting. Chunky rounded lowercase type.
 */
class BlobCanvas : StyleCanvas() {
    private val samples = 96
    private var from = FloatArray(samples) { 1f }
    private var to = FloatArray(samples) { 1f }
    private val cur = FloatArray(samples) { 1f }
    private val morph = Spring(1f, 120f, 0.62f)
    private val squishX = Spring(1f, 420f, 0.42f)
    private val squishY = Spring(1f, 420f, 0.42f)
    private val labelIn = Spring(1f, 260f, 0.75f)
    private val pop = ArrayList<Spring>()
    private var focus = 0
    private var pending = -1
    private var swipeAcc = 0f
    private var bx = 0f
    private var by = 0f
    private var br = 0f
    private val slotRect = RectF()
    private var cols = 5
    private var slot = 0f

    private val blob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val drop = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-black", Typeface.NORMAL) }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val path = Path()
    private val rc = RectF()

    private val n get() = items.size

    override fun onItems(old: List<MenuItem>) {
        while (pop.size < n) pop.add(Spring(0f, 240f, 0.55f))
        if (old.isEmpty() && n > 0) {
            shape(items[0].icon, to)
            to.copyInto(from)
            to.copyInto(cur)
        }
        if (w > 0f) onSize()
    }

    override fun onSize() {
        br = min(h * 0.36f, d * 58f)
        bx = br + d * 18f
        by = h / 2f
        val left = bx + br + d * 18f
        slotRect.set(left, h * 0.42f, w - d * 6f, h - d * 6f)
        val others = max(1, n - 1)
        cols = min(others, max(3, ((slotRect.width()) / (d * 44f)).toInt()))
        slot = slotRect.width() / cols
    }

    // ---- silhouettes as polar radius functions (1 = blob radius) ----

    private fun polygon(theta: Float, k: Int, rot: Float): Float {
        val seg = (2 * PI / k).toFloat()
        var a = (theta - rot) % seg
        if (a < 0) a += seg
        return (cos(PI / k) / cos(a - seg / 2f)).toFloat()
    }

    /** Radius of a superellipse (|x/a|^p + |y/b|^p = 1) at angle [t]: p = 2 ellipse, larger p = boxier. */
    private fun superEllipse(t: Float, a: Float, b: Float, p: Float): Float {
        val c = abs(cos(t)) / a
        val sn = abs(sin(t)) / b
        return (c.pow(p) + sn.pow(p)).pow(-1f / p)
    }

    private fun shape(icon: Icon, out: FloatArray) {
        for (s in 0 until samples) {
            val t = (s * 2 * PI / samples).toFloat()
            val r = when (icon) {
                Icon.LOOP -> superEllipse(t, 1f, 0.6f, 4f) // horizontal capsule
                Icon.STOP -> polygon(t, 4, (PI / 4).toFloat()) * 0.86f
                Icon.SLIDER -> polygon(t, 4, 0f) * 0.82f // diamond
                Icon.SNAP -> 0.8f + 0.2f * abs(cos(2 * t)).pow(6f) // squircle with corners
                Icon.HOLD -> 0.92f
                Icon.LIST -> superEllipse(t, 0.72f, 0.95f, 5f) // tall slab
                Icon.GEAR -> 0.8f + 0.16f * (if (cos(8 * t) > 0.2f) 1f else 0f) * 0.9f + 0.04f * cos(8 * t)
                Icon.THEME -> 0.78f + 0.2f * cos(5 * t) // flower
                Icon.MOON -> 0.62f + 0.38f * abs(cos(3 * t)).pow(3f) // six-pointed star
                Icon.EXPAND -> polygon(t, 3, (-PI / 2).toFloat()) * 0.62f // triangle, point up
                Icon.HIDE -> polygon(t, 3, (PI / 2).toFloat()) * 0.62f // triangle, point down
                else -> 0.9f
            }
            out[s] = r.coerceIn(0.3f, 1.25f)
        }
    }

    private fun focusOn(i: Int) {
        if (i == focus || i !in 0 until n) return
        cur.copyInto(from)
        shape(items[i].icon, to)
        focus = i
        morph.snap(0f)
        morph.to(1f, reduced)
        labelIn.snap(0f)
        labelIn.to(1f, reduced)
        kit.haptic(Haptic.TICK)
    }

    override fun onSelect(old: String?, new: String?) {
        val i = idx(new)
        if (i >= 0) focusOn(i)
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        val o = open.value
        morph.step(dt)
        squishX.to(if (pressed == focus && pressed >= 0) 1.12f else 1f, reduced)
        squishY.to(if (pressed == focus && pressed >= 0) 0.88f else 1f, reduced)
        squishX.step(dt)
        squishY.step(dt)
        labelIn.step(dt)
        var k = 0
        for (i in 0 until n) {
            if (i == focus) continue
            val ready = !opening || o > 0.25f + 0.5f * k / max(1, n - 2)
            pop[i].to(if (opening && ready) 1f else if (opening) pop[i].target else 0f, reduced)
            pop[i].step(dt)
            if (!pop[i].settled) moving = true
            k++
        }
        pop.getOrNull(focus)?.let {
            it.to(0f, reduced)
            it.step(dt)
        }
        // blend the outline (with a gooey bulge in the middle of a morph) + a gentle living wobble
        val m = morph.value.coerceIn(-0.2f, 1.2f)
        val bulge = 4f * m.coerceIn(0f, 1f) * (1f - m.coerceIn(0f, 1f))
        for (s in 0 until samples) {
            val a = (s * 2 * PI / samples).toFloat()
            val wob = if (reduced) 0f else 0.035f * MotionMath.wobble(t * 1.3f, s * 0.07f + a)
            cur[s] = MotionMath.lerp(from[s], to[s], m) * (1f + wob + 0.12f * bulge * sin(a * 3f + t * 4f))
        }
        // act once the shape has (almost) become the item; the wobble settles afterwards
        if (pending >= 0 && (morph.settled || morph.value > 0.9f)) {
            val p = pending
            pending = -1
            super.activate(p)
        }
        if (!morph.settled || !squishX.settled || !labelIn.settled) moving = true
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        val o = open.value.coerceIn(0f, 1.2f)
        if (o < 0.01f && open.target < 0.5f) return
        val accent = th.promptColor
        // the island the blob lives on (keeps text readable over any game)
        val ia = (o.coerceAtMost(1f) * 0xEA).roundToInt()
        val iw = w * MotionMath.easeOutCubic(o.coerceAtMost(1f))
        rc.set((w - iw) / 2f, 0f, (w + iw) / 2f, h)
        drop.color = withAlpha(th.menuBg, ia)
        c.drawRoundRect(rc, h / 2f, h / 2f, drop)
        shine.color = withAlpha(th.chipStroke, (ia * 0.6f).roundToInt())
        drop.color = 0
        val grow = MotionMath.easeOutBack(o.coerceAtMost(1f), 2f)
        // Android rejects a gradient with radius 0, which this is on the very first frame of opening
        val rr = max(br * grow, d * 0.5f)

        // the blob outline from the radius samples (smooth quadratic path through midpoints)
        path.reset()
        for (s in 0..samples) {
            val i = s % samples
            val a = (i * 2 * PI / samples).toFloat()
            val x = bx + cos(a) * cur[i] * rr * squishX.value
            val y = by + sin(a) * cur[i] * rr * squishY.value
            if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        glow.color = withAlpha(accent, 0x3A)
        c.save()
        c.translate(bx, by)
        c.scale(1.12f, 1.12f)
        c.translate(-bx, -by)
        c.drawPath(path, glow)
        c.restore()
        blob.shader = RadialGradient(
            bx - rr * 0.35f, by - rr * 0.4f, rr * 1.5f,
            intArrayOf(mix(accent, Color.WHITE, 0.4f), accent, mix(accent, Color.BLACK, 0.45f)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(path, blob)
        shine.color = withAlpha(Color.WHITE, 0x50)
        rc.set(bx - rr * 0.5f, by - rr * 0.62f, bx - rr * 0.05f, by - rr * 0.38f)
        c.drawOval(rc, shine)
        val item = items[focus.coerceIn(0, n - 1)]
        val iconScale = 0.55f + 0.1f * (1f - labelIn.value)
        Icons.draw(c, item.icon, bx, by, rr * iconScale, withAlpha(Color.WHITE, (255 * o.coerceAtMost(1f)).roundToInt()))

        // label: slides in from the blob each time the focus changes
        val li = labelIn.value
        val tx = bx + br + d * 18f - (1f - li) * d * 24f
        big.textSize = min(d * 24f, h * 0.17f)
        big.color = withAlpha(th.menuText, (255 * li.coerceIn(0f, 1f) * o.coerceAtMost(1f)).roundToInt())
        c.drawText(fit(big, item.label.lowercase(), w - tx - d * 8f), tx, h * 0.24f, big)
        small.textSize = d * 10.5f
        small.color = withAlpha(th.menuText, (170 * li.coerceIn(0f, 1f)).roundToInt())
        val sub = if (item.toggle) (if (item.on) "on · tap the blob to switch off" else "off · tap the blob to switch on") else "tap the blob · swipe to browse"
        c.drawText(fit(small, sub, w - tx - d * 8f), tx, h * 0.24f + d * 15f, small)

        // droplets
        var k = 0
        for (i in 0 until n) {
            if (i == focus) continue
            val p = pop[i].value
            val sx = slotCenterX(k)
            val sy = slotCenterY(k)
            k++
            if (p < 0.02f) continue
            // droplets fly out of the blob while opening
            val x = MotionMath.lerp(bx, sx, p.coerceIn(0f, 1f))
            val y = MotionMath.lerp(by, sy, p.coerceIn(0f, 1f)) + (if (reduced) 0f else sin(t * 2f + i) * d * 1.5f)
            val r = d * 15f * p.coerceAtMost(1.15f) * (if (i == pressed) 0.82f else 1f)
            drop.color = withAlpha(mix(accent, th.menuBg, 0.55f), 0xF0)
            c.drawCircle(x, y, r, drop)
            shine.color = withAlpha(Color.WHITE, 0x40)
            rc.set(x - r * 0.55f, y - r * 0.7f, x, y - r * 0.3f)
            c.drawOval(rc, shine)
            Icons.draw(c, items[i].icon, x, y, r * 1.05f, if (items[i].toggle && items[i].on) accent else th.chipText)
        }
    }

    private fun slotCenterX(k: Int): Float = slotRect.left + slot * (k % cols + 0.5f)
    private fun slotCenterY(k: Int): Float {
        val rows = (max(1, n - 1) + cols - 1) / cols
        val rowH = slotRect.height() / max(1, rows)
        return slotRect.top + rowH * (k / cols + 0.5f)
    }

    /** Item index of droplet slot [k] (droplets skip the focused item). */
    private fun itemOfSlot(k: Int): Int {
        var kk = 0
        for (i in 0 until n) {
            if (i == focus) continue
            if (kk == k) return i
            kk++
        }
        return -1
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || n == 0) return -1
        if (hypot(x - bx, y - by) < br * 1.05f) return focus
        var best = -1
        var bestD = d * 26f
        for (k in 0 until n - 1) {
            val dd = hypot(x - slotCenterX(k), y - slotCenterY(k))
            if (dd < bestD) {
                bestD = dd
                best = itemOfSlot(k)
            }
        }
        return best
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        if (i == focus) {
            out.set(bx - br, by - br, bx + br, by + br)
            return true
        }
        var k = 0
        for (j in 0 until n) {
            if (j == focus) continue
            if (j == i) break
            k++
        }
        out.set(slotCenterX(k) - d * 24f, slotCenterY(k) - d * 24f, slotCenterX(k) + d * 24f, slotCenterY(k) + d * 24f)
        return true
    }

    override fun onUp(i: Int, click: Boolean) {
        pressed = -1
        if (!click || i < 0) return
        if (i == focus) {
            squishX.kick(-3f)
            squishY.kick(3f)
            super.activate(i)
        } else {
            focusOn(i)
            pending = i
            if (reduced) {
                pending = -1
                super.activate(i)
            }
        }
    }

    override fun onDrag(dx: Float, dy: Float, x: Float, y: Float): Boolean {
        if (abs(dx) < abs(dy)) return false
        swipeAcc += dx
        val stepPx = d * 46f
        while (abs(swipeAcc) > stepPx) {
            val dir = if (swipeAcc > 0) -1 else 1
            swipeAcc -= -dir * stepPx
            focusOn(Math.floorMod(focus + dir, max(1, n)))
        }
        return true
    }

    override fun onFling(vx: Float, vy: Float) {
        swipeAcc = 0f
    }
}
