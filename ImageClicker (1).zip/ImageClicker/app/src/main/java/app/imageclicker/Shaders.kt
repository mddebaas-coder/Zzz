package app.imageclicker

import android.annotation.TargetApi
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build

/**
 * AGSL (Android 13+) shaders used by some styles. Every style also has a Canvas fallback,
 * so on older phones (or if a shader fails to compile) it still looks right.
 */
object Agsl {
    val on: Boolean get() = Build.VERSION.SDK_INT >= 33

    /** Compiles [src]; null when AGSL is unavailable or the shader does not compile. */
    fun make(src: String): Shader? = if (on) Api33.make(src) else null

    fun float(s: Shader?, name: String, vararg v: Float) {
        if (on && s != null) Api33.float(s, name, v)
    }

    fun color(s: Shader?, name: String, c: Int) {
        if (on && s != null) Api33.color(s, name, c)
    }

    // ---------------------------------------------------------------- sources

    /** Flowing aurora curtains (Aurora style pills + background). */
    const val AURORA = """
uniform float2 size;
uniform float time;
layout(color) uniform half4 c1;
layout(color) uniform half4 c2;
layout(color) uniform half4 c3;
half4 main(float2 p) {
    float2 uv = p / size;
    float t = time * 0.18;
    float w1 = sin(uv.x * 3.2 + t * 2.1 + sin(uv.y * 2.6 + t * 1.7) * 1.4) * 0.5 + 0.5;
    float w2 = sin(uv.x * 5.3 - t * 1.6 + cos(uv.y * 3.4 - t * 1.2) * 1.1) * 0.5 + 0.5;
    float band = smoothstep(0.15, 0.95, w1 * (1.0 - uv.y * 0.55));
    half4 col = mix(c1, c2, half(w1));
    col = mix(col, c3, half(w2 * 0.55));
    col.rgb *= half(0.55 + 0.45 * band);
    return col;
}
"""

    /**
     * Gooey metaballs for the Liquid Glass dock: six glass drops (g0..g5) and a two-ball liquid
     * indicator (l0, l1), each (x, y, r); r = 0 means unused. Where the fields meet they melt together.
     */
    const val GOO = """
uniform float3 g0; uniform float3 g1; uniform float3 g2; uniform float3 g3; uniform float3 g4; uniform float3 g5;
uniform float3 l0; uniform float3 l1;
layout(color) uniform half4 glass;
layout(color) uniform half4 accent;
layout(color) uniform half4 rim;
float ball(float2 p, float3 b) { float2 d = p - b.xy; float q = b.z * b.z / (dot(d, d) + 1.0); return q * q; }
half4 main(float2 p) {
    float gl = ball(p, g0) + ball(p, g1) + ball(p, g2) + ball(p, g3) + ball(p, g4) + ball(p, g5);
    float lq = ball(p, l0) + ball(p, l1);
    float f = gl + lq;
    float a = smoothstep(0.92, 1.08, f);
    if (a <= 0.0) { return half4(0.0); }
    float k = clamp(lq / max(f, 0.0001), 0.0, 1.0);
    half4 col = mix(glass, accent, half(smoothstep(0.3, 0.7, k)));
    float edge = smoothstep(0.92, 1.0, f) * (1.0 - smoothstep(1.0, 1.3, f));
    col.rgb = mix(col.rgb, rim.rgb, half(edge * 0.55));
    half al = col.a * half(a);
    return half4(col.rgb * al, al);
}
"""

    /** View effect: glitch slices + RGB split + scanlines (Neon Cyberpunk). Needs `content`. */
    const val GLITCH = """
uniform shader content;
uniform float2 size;
uniform float time;
uniform float amount;
half4 main(float2 p) {
    float row = floor(p.y / 7.0);
    float n = fract(sin(row * 12.9898 + floor(time * 14.0) * 78.233) * 43758.5453);
    float shift = n > 0.93 ? (n - 0.93) * 600.0 * amount : 0.0;
    float2 q = float2(p.x + shift, p.y);
    float s = 1.5 + 2.5 * amount;
    half4 c = content.eval(q);
    half r = content.eval(q + float2(s, 0.0)).r;
    half b = content.eval(q - float2(s, 0.0)).b;
    half scan = half(0.84 + 0.16 * (sin(p.y * 1.5708) * 0.5 + 0.5));
    return half4(r, c.g, b, max(c.a, max(r, b) * 0.6)) * scan;
}
"""

    /** View effect: curved CRT glass, scanlines, vignette, flicker (Retro Terminal). */
    const val CRT = """
uniform shader content;
uniform float2 size;
uniform float time;
half4 main(float2 p) {
    float2 uv = p / size * 2.0 - 1.0;
    float2 d = uv * (1.0 + 0.05 * dot(uv.yx, uv.yx));
    float2 q = (d * 0.5 + 0.5) * size;
    if (q.x < 0.0 || q.y < 0.0 || q.x > size.x || q.y > size.y) { return half4(0.0); }
    half4 c = content.eval(q);
    half scan = half(0.8 + 0.2 * sin(q.y * 3.14159));
    half vig = half(1.0 - 0.32 * dot(uv, uv));
    half flick = half(0.97 + 0.03 * sin(time * 50.0));
    return half4(c.rgb * scan * vig * flick, c.a);
}
"""
}

@TargetApi(33)
private object Api33 {
    fun make(src: String): Shader? = try {
        RuntimeShader(src)
    } catch (e: Exception) {
        null
    }

    fun float(s: Shader, name: String, v: FloatArray) {
        val r = s as? RuntimeShader ?: return
        try {
            when (v.size) {
                1 -> r.setFloatUniform(name, v[0])
                2 -> r.setFloatUniform(name, v[0], v[1])
                3 -> r.setFloatUniform(name, v[0], v[1], v[2])
                4 -> r.setFloatUniform(name, v[0], v[1], v[2], v[3])
                else -> r.setFloatUniform(name, v)
            }
        } catch (e: Exception) {
            // unknown uniform name: ignore, the fallback look is still drawn
        }
    }

    fun color(s: Shader, name: String, c: Int) {
        val r = s as? RuntimeShader ?: return
        try {
            r.setColorUniform(name, c)
        } catch (e: Exception) {
        }
    }
}
