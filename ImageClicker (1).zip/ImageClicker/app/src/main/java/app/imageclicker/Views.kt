package app.imageclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen frozen screenshot. Drag a box, press OK. [done] gets the box in bitmap pixels or null if cancelled.
 */
@SuppressLint("ViewConstructor")
class RegionSelectorView(
    ctx: Context,
    private val shot: Bitmap,
    private val done: (Rect?) -> Unit
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint().apply {
        color = 0xFF00E5FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        textAlign = Paint.Align.CENTER
    }
    private val okPaint = Paint().apply { color = 0xFF238636.toInt() }
    private val cancelPaint = Paint().apply { color = 0xFF6E7681.toInt() }

    private val a = PointF()
    private val b = PointF()
    private var has = false
    private var dragging = false
    private var downOn = 0 // 0 none, 1 ok, 2 cancel

    private val dst = Rect()
    private val okR = RectF()
    private val cancelR = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val bw = 130f * d
        val bh = 48f * d
        val top = h - bh - 36f * d
        cancelR.set(w / 2f - bw - 12f * d, top, w / 2f - 12f * d, top + bh)
        okR.set(w / 2f + 12f * d, top, w / 2f + bw + 12f * d, top + bh)
    }

    private fun sel(): RectF =
        RectF(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x), max(a.y, b.y))

    override fun onDraw(c: Canvas) {
        dst.set(0, 0, width, height)
        c.drawBitmap(shot, null, dst, null)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (has) {
            val r = sel()
            c.save()
            c.clipRect(r)
            c.drawBitmap(shot, null, dst, null)
            c.restore()
            c.drawRect(r, border)
        }
        c.drawRect(cancelR, cancelPaint)
        c.drawRect(okR, okPaint)
        val ty = cancelR.centerY() + text.textSize / 3f
        c.drawText("Cancel", cancelR.centerX(), ty, text)
        c.drawText("Save", okR.centerX(), ty, text)
        c.drawText("Drag a box around the button/icon to match", width / 2f, 64f * d, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downOn = when {
                    okR.contains(e.x, e.y) -> 1
                    cancelR.contains(e.x, e.y) -> 2
                    else -> 0
                }
                if (downOn == 0) {
                    a.set(e.x, e.y)
                    b.set(e.x, e.y)
                    has = true
                    dragging = true
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                b.set(e.x, e.y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                when {
                    downOn == 2 && cancelR.contains(e.x, e.y) -> done(null)
                    downOn == 1 && okR.contains(e.x, e.y) -> confirm()
                    else -> b.set(e.x, e.y).also { invalidate() }
                }
                downOn = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                downOn = 0
            }
        }
        return true
    }

    private fun confirm() {
        if (!has) return
        val r = sel()
        val sx = shot.width.toFloat() / width
        val sy = shot.height.toFloat() / height
        val out = Rect(
            max(0, floor(r.left * sx).toInt()),
            max(0, floor(r.top * sy).toInt()),
            min(shot.width, ceil(r.right * sx).toInt()),
            min(shot.height, ceil(r.bottom * sy).toInt())
        )
        if (out.width() < 8 || out.height() < 8) return // too small, keep selecting
        done(out)
    }
}

/**
 * Lightly dimmed live screen. Tap anywhere to pick that point; [done] gets screen pixels or null on Cancel.
 */
@SuppressLint("ViewConstructor")
class PointPickerView(
    ctx: Context,
    private val done: (Point?) -> Unit
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x44000000 }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f * d, 0f, 0f, Color.BLACK)
    }
    private val cancelPaint = Paint().apply { color = 0xFF6E7681.toInt() }
    private val cancelR = RectF()
    private var downOnCancel = false
    private var finished = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val bw = 140f * d
        val bh = 48f * d
        val top = h - bh - 36f * d
        cancelR.set(w / 2f - bw / 2f, top, w / 2f + bw / 2f, top + bh)
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        c.drawText("Tap the spot to hold down", width / 2f, 64f * d, text)
        c.drawText("Release later by tapping the red ■", width / 2f, 64f * d + text.textSize * 1.5f, text)
        c.drawRect(cancelR, cancelPaint)
        c.drawText("Cancel", cancelR.centerX(), cancelR.centerY() + text.textSize / 3f, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (finished) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> downOnCancel = cancelR.contains(e.x, e.y)
            MotionEvent.ACTION_UP -> {
                finished = true
                if (downOnCancel && cancelR.contains(e.x, e.y)) {
                    done(null)
                } else {
                    done(Point(e.rawX.toInt(), e.rawY.toInt()))
                }
            }
        }
        return true
    }
}

/** Transparent, touch-through overlay that outlines a rectangle (screen pixels). */
@SuppressLint("ViewConstructor")
class HighlightView(ctx: Context, private val r: Rect) : View(ctx) {
    private val p = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 4f * ctx.resources.displayMetrics.density
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(r, p)
    }
}

/**
 * Root of a full-screen overlay window (style menu, settings). Reports its size so the content can
 * be placed for the current orientation, and turns the Back key into [onBack].
 */
@SuppressLint("ViewConstructor")
class OverlayRoot(ctx: Context, private val onBack: () -> Unit, private val onSize: (Int, Int) -> Unit) : FrameLayout(ctx) {
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) post { onSize(w, h) }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
