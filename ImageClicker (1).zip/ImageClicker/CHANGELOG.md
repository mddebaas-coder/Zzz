# Changelog

## 1.8 (2026-11-03)
- New: the **tap folder**. All saved images as thumbnails; tap one and it is watched: tapped once every time it
  appears, never tapped again while it stays, nothing else on the screen is tapped, and it taps again when you come
  back to that screen. Runs until ■. **+ new image** snaps one.
- Long-press images to pick several: watch them together, save them as a named sequence, resnap or delete them.
- Saved sequences are listed with their images and one-tap *watch* / *run ∞* / *run 1×*, *load* and *delete*.
- New step `watch <img> [thr=] [again=ms] [after=ms]` and command `watch <img> [img2 ...]`. A watched image must be
  missing for two looks in a row before it counts as gone, so a blurry frame can't cause a double tap.
- The ☰ menu now has 11 items: *Tap folder* was added next to *Snap image*. New **tap** button in the menu header.
  Pixel Arcade lays the 11 buttons out in two rows, Retro Terminal numbers 1-11 and got a bit taller to fit them,
  Classic got taller. Watch runs count taps in the time log and the mini bar.
- Tests: tap-once-per-appearance logic, leaving and coming back, blurry-frame protection, `again`, the watch step
  syntax, and which steps can be combined. All 13 styles re-checked with 11 items.

## 1.7.1 (2026-11-03)
- Fixed: tapping ⚙ (settings) could close the app. The Morphing Blob preview built a gradient with radius 0 on
  the first frame of its opening animation, which Android rejects with a crash.
- A menu style that hits an error no longer closes the app: that style stops, shows "this style hit an error",
  writes the reason to the error log (`errors`), and the ☰ menu falls back to Classic.
- Crash report: if the app ever crashes, the reason is saved. The next time you open Image Clicker, the setup
  screen shows it with a *Copy crash report* button, and the terminal says so (`crash` prints it).
- The off-device style tests now reject the same bad drawing values Android does, and simulate the settings
  gallery's preview loop with irregular frame times.

## 1.7 (2026-11-03)

### Menu styles (new)
- 13 menu styles, each with its own placement, layout, typography, open/close animation, selection animation and
  press feedback: Liquid Glass (bottom dock), Neon Cyberpunk (left rail), Orbital (centre disc), Card Deck (bottom fan),
  Morphing Blob (top island), Particle Burst (centre honeycomb), Retro Terminal (top console), Pixel Arcade (bottom cabinet),
  Origami (right drawer), Clay (centre grid), Aurora (top curtain), Kinetic Brutalist (full screen), Classic (dropdown).
- Shared menu model: the same ten actions in every style (run/stop, thr sliders, snap, hold, log, settings, next theme,
  night toggle, mini toggle, hide).
- Spring physics for every animation, so a menu can be reversed mid-animation; haptic ticks and clicks; tap outside or Back closes it.
- AGSL shaders on Android 13+ (liquid glass, aurora, glitch, CRT) with drawn fallbacks on older phones.
- Accessibility: every item is a TalkBack button (toggles say on/off), keyboard Tab/arrows + Enter, reduced motion
  (follows Android's *Remove animations*, plus a *Calm motion* switch).
- Re-placed for rotation, tablets and landscape. The chosen style is saved.

### Settings page (new)
- ⚙ button / `settings`: live gallery of all styles (each runs in a mini phone screen at its real spot; previews pause
  when scrolled away), theme list, Night/Mini/label/Calm motion/Tap marks switches, default thr slider, and the extra
  actions (run once, sequences, sliders, logs, status, clear log, help, exit).
- Picking a style plays the old style's exit and then the new one's entrance.

### Commands
- `style [name|number|next|list]`, `menu`, `settings`.

### Fixes and changes found while testing the styles
- Orbital and Morphing Blob: an item now acts as soon as its swing/morph arrives (was up to 1 s, now ~0.25 s).
- Card Deck: accessibility bounds now point at the visible part of each overlapping card.
- Particle Burst: reworked from a square grid (too close to Pixel Arcade) into a honeycomb of hexagons around a core;
  it also now comes to rest after closing (it kept animating before).
- Pixel Arcade: reduced motion now applies when closing too.
- Origami: folding away is faster than unfolding (about 1.1 s instead of 1.8 s).
- Aurora: long labels no longer push rows off the curtain (pills capped at half width, rows shrink to fit).
- Liquid Glass: no longer rebuilds its glass when only a toggle changes.
- Classic: the switch drawing no longer corrupts the card layout for the rows after it.
- Night window logic moved into one tested helper (`NightWindow`), used by night mode.

### Tests
- Unit tests (JUnit, `gradle testDebugUnitTest`): springs (settling, overshoot, interruption, reduced motion,
  frame-rate independence), motion helpers, text fitting, night window, menu model, style registry (≥12 unique styles,
  saved-style fallback), every style's placement on 9 screen sizes, step parser.

## 1.6
- Error log and time log (`errors`, `times`), clock in the menu header.
- Threshold slider per step (`editor`), with the last match score per step.
- Menu minimizes to a mini bar when a run stops because an image wasn't found; mini mode (`mini on`).
- Night mode: run inf from 22:00 to 08:00, restarting after an image isn't found (`night`).
- Project label "martijn's project", always on screen, in the theme's font (`label left|right`).
- Seven animated themes (◐), hold / long press, `resnap`, `do`, infinite default timeout, `timeout=… skip`.
