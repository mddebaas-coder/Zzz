package app.imageclicker

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pure-Kotlin template matching (no OpenCV needed).
 *
 * Grayscale sum-of-absolute-differences, coarse-to-fine:
 *  1. downscale screen + template by k (1..4) and scan every position using a
 *     sparse set of template pixels, most distinctive pixels first, with early exit
 *  2. refine around the best coarse hit at full resolution
 *
 * score = 1 - meanAbsDiff/255  (1.0 = identical).
 */
object TemplateMatcher {

    class Match(val score: Double, val left: Int, val top: Int, val w: Int, val h: Int) {
        val cx: Int get() = left + w / 2
        val cy: Int get() = top + h / 2
    }

    private class Gray(val w: Int, val h: Int, val d: IntArray)

    private class Samples(val off: IntArray, val v: IntArray)

    private fun gray(b: Bitmap, x: Int, y: Int, w: Int, h: Int): Gray {
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, x, y, w, h)
        for (i in px.indices) {
            val p = px[i]
            px[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 151 + (p and 255) * 28) shr 8
        }
        return Gray(w, h, px)
    }

    private fun down(g: Gray, k: Int): Gray {
        if (k == 1) return g
        val nw = g.w / k
        val nh = g.h / k
        val out = IntArray(nw * nh)
        val kk = k * k
        for (y in 0 until nh) {
            for (x in 0 until nw) {
                var s = 0
                val base = (y * k) * g.w + x * k
                for (yy in 0 until k) {
                    val r = base + yy * g.w
                    for (xx in 0 until k) s += g.d[r + xx]
                }
                out[y * nw + x] = s / kk
            }
        }
        return Gray(nw, nh, out)
    }

    /** Sparse sample grid of the template. [stride] is the row width of the image it will be compared against. */
    private fun samples(t: Gray, stride: Int, maxN: Int): Samples {
        val step = max(1, ceil(sqrt(t.w.toDouble() * t.h / maxN)).toInt())
        val offs = ArrayList<Int>()
        val vals = ArrayList<Int>()
        var y = 0
        while (y < t.h) {
            var x = 0
            while (x < t.w) {
                offs.add(y * stride + x)
                vals.add(t.d[y * t.w + x])
                x += step
            }
            y += step
        }
        val mean = vals.average()
        val order = vals.indices.sortedByDescending { abs(vals[it] - mean) }
        return Samples(
            IntArray(order.size) { offs[order[it]] },
            IntArray(order.size) { vals[order[it]] }
        )
    }

    /** Best match of [tpl] inside [screen] (optionally only inside [roi]); null if it cannot fit. */
    fun find(screen: Bitmap, tpl: Bitmap, roi: Rect? = null): Match? {
        val r = if (roi == null) {
            Rect(0, 0, screen.width, screen.height)
        } else {
            Rect(max(0, roi.left), max(0, roi.top), min(screen.width, roi.right), min(screen.height, roi.bottom))
        }
        if (tpl.width < 4 || tpl.height < 4) return null
        if (r.width() < tpl.width || r.height() < tpl.height) return null

        val sg = gray(screen, r.left, r.top, r.width(), r.height())
        val tg = gray(tpl, 0, 0, tpl.width, tpl.height)
        val k = (min(tg.w, tg.h) / 16).coerceIn(1, 4)
        val sd = down(sg, k)
        val td = down(tg, k)

        // ---- coarse pass ----
        val cs = samples(td, sd.w, 400)
        val n = cs.off.size
        val s = sd.d
        var bestSum = Int.MAX_VALUE
        var bx = 0
        var by = 0
        for (y in 0..(sd.h - td.h)) {
            val rowBase = y * sd.w
            for (x in 0..(sd.w - td.w)) {
                val base = rowBase + x
                var sum = 0
                var i = 0
                while (i < n) {
                    val d = s[base + cs.off[i]] - cs.v[i]
                    sum += if (d < 0) -d else d
                    if (sum >= bestSum) break
                    i++
                }
                if (i == n) {
                    bestSum = sum
                    bx = x
                    by = y
                }
            }
        }

        // ---- refine at full resolution ----
        val fs = samples(tg, sg.w, 2500)
        val fn = fs.off.size
        val maxX = sg.w - tg.w
        val maxY = sg.h - tg.h
        val x0 = min(max(0, bx * k - k), maxX)
        val x1 = min(maxX, bx * k + k)
        val y0 = min(max(0, by * k - k), maxY)
        val y1 = min(maxY, by * k + k)
        val sf = sg.d
        var fBest = Int.MAX_VALUE
        var fx = x0
        var fy = y0
        for (y in y0..y1) {
            for (x in x0..x1) {
                val base = y * sg.w + x
                var sum = 0
                var i = 0
                while (i < fn) {
                    val d = sf[base + fs.off[i]] - fs.v[i]
                    sum += if (d < 0) -d else d
                    if (sum >= fBest) break
                    i++
                }
                if (i == fn) {
                    fBest = sum
                    fx = x
                    fy = y
                }
            }
        }
        if (fBest == Int.MAX_VALUE) return null
        val score = 1.0 - fBest.toDouble() / (fn * 255.0)
        return Match(score, r.left + fx, r.top + fy, tpl.width, tpl.height)
    }

    /** Standard deviation of grayscale values. Very low = flat template that will match anywhere. */
    fun contrast(b: Bitmap): Double {
        val g = gray(b, 0, 0, b.width, b.height)
        val mean = g.d.average()
        var s = 0.0
        for (v in g.d) s += (v - mean) * (v - mean)
        return sqrt(s / g.d.size)
    }
}
