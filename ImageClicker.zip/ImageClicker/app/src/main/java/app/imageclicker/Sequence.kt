package app.imageclicker

enum class Op { TAP, WAITIMG, GONEIMG, HOLD, TAPXY, HOLDXY, SWIPE, WAIT, BACK, HOME }

fun isImageOp(op: Op): Boolean = op == Op.TAP || op == Op.WAITIMG || op == Op.GONEIMG || op == Op.HOLD

fun defaultAfter(op: Op): Long = if (op == Op.WAITIMG || op == Op.GONEIMG) 0L else 300L

/**
 * One line of a sequence.
 *
 *   tap <tpl> [thr=0.9] [timeout=0 (forever)] [dx=0] [dy=0] [roi=x,y,w,h] [after=300] [skip]
 *   waitimg <tpl> [...]      wait until the image is visible
 *   goneimg <tpl> [...]      wait until the image is no longer visible
 *   hold <tpl> [ms=0] [...]  find image, keep finger down on it (ms=0 = until stopped)
 *   tapxy <x> <y> [after=300]
 *   holdxy <x> <y> [ms=0]    keep finger down on a point (ms=0 = until stopped)
 *   swipe <x1> <y1> <x2> <y2> [ms=300] [after=300]
 *   wait <ms>
 *   back | home
 */
data class Step(
    val op: Op,
    val tpl: String = "",
    val x: Int = 0,
    val y: Int = 0,
    val x2: Int = 0,
    val y2: Int = 0,
    val ms: Long = 0,
    val thr: Double? = null,
    val timeout: Long = 0, // 0 = wait forever
    val after: Long = 300,
    val dx: Int = 0,
    val dy: Int = 0,
    val roi: List<Int>? = null,
    val skip: Boolean = false
) {
    val isImage: Boolean get() = isImageOp(op)

    fun toLine(): String {
        val sb = StringBuilder(
            when (op) {
                Op.TAP -> "tap $tpl"
                Op.WAITIMG -> "waitimg $tpl"
                Op.GONEIMG -> "goneimg $tpl"
                Op.HOLD -> "hold $tpl"
                Op.TAPXY -> "tapxy $x $y"
                Op.HOLDXY -> "holdxy $x $y"
                Op.SWIPE -> "swipe $x $y $x2 $y2"
                Op.WAIT -> "wait $ms"
                Op.BACK -> "back"
                Op.HOME -> "home"
            }
        )
        fun opt(k: String, v: Any) {
            sb.append(' ').append(k).append('=').append(v)
        }
        if (isImage) {
            thr?.let { opt("thr", it) }
            if (timeout != 0L) opt("timeout", timeout)
            if (dx != 0) opt("dx", dx)
            if (dy != 0) opt("dy", dy)
            roi?.let { opt("roi", it.joinToString(",")) }
        }
        if (op == Op.SWIPE && ms != 300L) opt("ms", ms)
        if ((op == Op.HOLD || op == Op.HOLDXY) && ms != 0L) opt("ms", ms)
        if (op != Op.WAIT && after != defaultAfter(op)) opt("after", after)
        if (isImage && skip) sb.append(" skip")
        return sb.toString()
    }
}

object StepParser {

    private val imageOnly = setOf("thr", "timeout", "dx", "dy", "roi")
    private val known = imageOnly + setOf("after", "ms")

    fun parse(line: String): Step {
        val t = line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (t.isEmpty()) throw IllegalArgumentException("empty step")

        val opts = HashMap<String, String>()
        val pos = ArrayList<String>()
        var skip = false
        for (tok in t.drop(1)) {
            val i = tok.indexOf('=')
            when {
                i > 0 -> opts[tok.substring(0, i).lowercase()] = tok.substring(i + 1)
                tok.equals("skip", ignoreCase = true) -> skip = true
                else -> pos.add(tok)
            }
        }

        val op = when (t[0].lowercase()) {
            "tap" -> Op.TAP
            "waitimg" -> Op.WAITIMG
            "goneimg" -> Op.GONEIMG
            "hold" -> Op.HOLD
            "tapxy" -> Op.TAPXY
            "holdxy" -> Op.HOLDXY
            "swipe" -> Op.SWIPE
            "wait" -> Op.WAIT
            "back" -> Op.BACK
            "home" -> Op.HOME
            else -> throw IllegalArgumentException(
                "unknown step '${t[0]}' (tap, waitimg, goneimg, hold, tapxy, holdxy, swipe, wait, back, home)"
            )
        }

        fun int(s: String, what: String): Int =
            s.toIntOrNull() ?: throw IllegalArgumentException("$what must be a whole number, got '$s'")

        fun long(s: String, what: String): Long =
            s.toLongOrNull() ?: throw IllegalArgumentException("$what must be a whole number, got '$s'")

        for (k in opts.keys) {
            if (k !in known) throw IllegalArgumentException("unknown option '$k'")
        }

        var step = Step(op = op, after = defaultAfter(op))
        val isImage = isImageOp(op)
        if (!isImage) {
            val bad = opts.keys.firstOrNull { it in imageOnly }
            if (bad != null) throw IllegalArgumentException("option '$bad' only works on image steps")
            if (skip) throw IllegalArgumentException("'skip' only works on image steps")
        }

        when (op) {
            Op.TAP, Op.WAITIMG, Op.GONEIMG, Op.HOLD -> {
                if (pos.size != 1) throw IllegalArgumentException("usage: ${t[0].lowercase()} <template> [options]")
                step = step.copy(tpl = pos[0], skip = skip)
            }
            Op.TAPXY, Op.HOLDXY -> {
                if (pos.size != 2) throw IllegalArgumentException("usage: ${t[0].lowercase()} <x> <y>")
                step = step.copy(x = int(pos[0], "x"), y = int(pos[1], "y"))
            }
            Op.SWIPE -> {
                if (pos.size != 4) throw IllegalArgumentException("usage: swipe <x1> <y1> <x2> <y2> [ms=300]")
                step = step.copy(
                    x = int(pos[0], "x1"), y = int(pos[1], "y1"),
                    x2 = int(pos[2], "x2"), y2 = int(pos[3], "y2"), ms = 300
                )
            }
            Op.WAIT -> {
                if (pos.size != 1) throw IllegalArgumentException("usage: wait <ms>")
                step = step.copy(ms = long(pos[0], "ms"))
            }
            Op.BACK, Op.HOME -> {
                if (pos.isNotEmpty()) throw IllegalArgumentException("${t[0].lowercase()} takes no arguments")
            }
        }

        opts["thr"]?.let {
            val v = it.toDoubleOrNull()
            if (v == null || v < 0.0 || v > 1.0) throw IllegalArgumentException("thr must be between 0 and 1")
            step = step.copy(thr = v)
        }
        opts["timeout"]?.let { step = step.copy(timeout = long(it, "timeout")) }
        opts["after"]?.let { step = step.copy(after = long(it, "after")) }
        opts["dx"]?.let { step = step.copy(dx = int(it, "dx")) }
        opts["dy"]?.let { step = step.copy(dy = int(it, "dy")) }
        opts["ms"]?.let {
            if (op != Op.SWIPE && op != Op.HOLD && op != Op.HOLDXY) {
                throw IllegalArgumentException("option 'ms' only works on swipe, hold and holdxy")
            }
            step = step.copy(ms = long(it, "ms"))
        }
        opts["roi"]?.let {
            val p = it.split(",")
            if (p.size != 4 || p.any { s -> s.toIntOrNull() == null }) {
                throw IllegalArgumentException("roi must be roi=x,y,w,h")
            }
            step = step.copy(roi = p.map { s -> s.toInt() })
        }
        return step
    }

    /** Parse a whole script. Blank lines and lines starting with # are ignored. */
    fun parseScript(text: String): Pair<List<Step>, List<String>> {
        val steps = ArrayList<Step>()
        val errors = ArrayList<String>()
        text.lines().forEachIndexed { i, raw ->
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith("#")) return@forEachIndexed
            try {
                steps.add(parse(l))
            } catch (e: IllegalArgumentException) {
                errors.add("line ${i + 1}: ${e.message}")
            }
        }
        return steps to errors
    }
}
