package app.imageclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// =====================================================================================================
//  Themes for the overlay terminal. One button cycles through them; the choice is saved in settings.
//  Each theme = colours/fonts for the widgets (Theme) + an animated background (Scene).
// =====================================================================================================

enum class Fx { TERMINAL, NEON, AURORA, INFERNO, GROOVY, RASTA, MORPHOGEN }

class Theme(
    val fx: Fx,
    val name: String,
    val title: String,
    val titleFont: Typeface,
    val titleColor: Int,
    val titleSpacing: Float,
    val logFont: Typeface,
    val logColor: Int,
    val glowColor: Int,
    val glowDp: Float,
    val inputColor: Int,
    val hintColor: Int,
    val prompt: String,
    val promptColor: Int,
    val cursorColor: Int,
    val cursorWidthDp: Int,
    val chipBg: Int,
    val chipStroke: Int,
    val chipText: Int,
    val chipRadiusDp: Float,
    val chipFont: Typeface,
    val cornerDp: Float,
    val bubbleA: Int,
    val bubbleB: Int,
    val bubbleRing: Int,
    val bubbleText: Int,
    val bubbleLabel: String,
    /** Dropdown menu + project label background / text. */
    val menuBg: Int = hex(0xF0101014),
    val menuText: Int = hex(0xFFFFFFFF),
    /** Header buttons show drawn icons instead of words. */
    val iconChips: Boolean = false,
    /** Buttons get irregular pebble shapes. */
    val organicChips: Boolean = false
)

internal fun hex(v: Long): Int = v.toInt()

internal fun withAlpha(color: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (color and 0xFFFFFF)

internal fun mix(a: Int, b: Int, f: Float): Int {
    val t = f.coerceIn(0f, 1f)
    fun ch(s: Int): Int {
        val x = (a shr s) and 255
        val y = (b shr s) and 255
        return (x + (y - x) * t).roundToInt()
    }
    return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

private fun smoothstep(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun frac(x: Float): Float = x - floor(x)

object Themes {
    private fun tf(family: String, style: Int = Typeface.NORMAL): Typeface = Typeface.create(family, style)

    val all: List<Theme> by lazy {
        listOf(
            // ---------------------------------------------------------------- 1. classic green CRT
            Theme(
                Fx.TERMINAL, "Terminal", "clicker ~\$",
                tf("monospace", Typeface.BOLD), hex(0xFF3FD46A), 0.02f,
                tf("monospace"), hex(0xFF39FF6A), hex(0xAA39FF6A), 4f,
                hex(0xFFC8FFD6), hex(0xFF2E7A43), "$ ", hex(0xFF39FF6A), hex(0xCC39FF6A), 8,
                hex(0xFF0C2312), hex(0xFF1F6B33), hex(0xFF8CFFAE), 2f, tf("monospace", Typeface.BOLD),
                6f,
                hex(0xFF0F3D1C), hex(0xFF27A84D), hex(0xFF39FF6A), hex(0xFFD8FFE4), ">_",
                menuBg = hex(0xF20A1A0E), menuText = hex(0xFF8CFFAE)
            ),
            // ---------------------------------------------------------------- 2. synthwave sunset grid
            Theme(
                Fx.NEON, "Neon", "NEON//CLICKER",
                tf("sans-serif-black", Typeface.ITALIC), hex(0xFFFF4FD8), 0.14f,
                tf("monospace"), hex(0xFF9AF8FF), hex(0xDD00E5FF), 6f,
                hex(0xFFFFFFFF), hex(0xFF9A6BC9), "❯ ", hex(0xFFFF2CDF), hex(0xFFFF2CDF), 2,
                hex(0x801A0533), hex(0xFFFF2CDF), hex(0xFFFFD6F5), 4f, tf("sans-serif-condensed", Typeface.BOLD),
                14f,
                hex(0xFFFF2CDF), hex(0xFF00E5FF), hex(0xFFFF2CDF), hex(0xFFFFFFFF), ">_",
                menuBg = hex(0xF2140426), menuText = hex(0xFFFFD6F5)
            ),
            // ---------------------------------------------------------------- 3. frosted glass + aurora
            Theme(
                Fx.AURORA, "Aurora", "Image Clicker",
                tf("sans-serif-light"), hex(0xFFF0F5FF), 0.06f,
                tf("monospace"), hex(0xFFE8F0FF), hex(0x6600F5D4), 3f,
                hex(0xFFFFFFFF), hex(0xFF8F98C0), "› ", hex(0xFF00F5D4), hex(0xFFB98CFF), 2,
                hex(0x26FFFFFF), hex(0x55FFFFFF), hex(0xFFF5F8FF), 14f, tf("sans-serif-medium"),
                22f,
                hex(0xFF00F5D4), hex(0xFF9B5DE5), hex(0xFFF15BB5), hex(0xFFFFFFFF), ">_",
                menuBg = hex(0xF0161B33), menuText = hex(0xFFF5F8FF)
            ),
            // ---------------------------------------------------------------- 4. fire and embers
            Theme(
                Fx.INFERNO, "Inferno", "INFERNO",
                tf("sans-serif-condensed", Typeface.BOLD), hex(0xFFFF8A3D), 0.2f,
                tf("monospace"), hex(0xFFFFC98A), hex(0xDDFF5A00), 5f,
                hex(0xFFFFEAD2), hex(0xFF8A4A2A), "» ", hex(0xFFFF5A1F), hex(0xFFFFB000), 2,
                hex(0xCC2A0E05), hex(0xFFFF5A1F), hex(0xFFFFD2A6), 8f, tf("sans-serif-condensed", Typeface.BOLD),
                10f,
                hex(0xFFFFB000), hex(0xFFFF2A00), hex(0xFFFF5A00), hex(0xFF2A0800), ">_",
                menuBg = hex(0xF21C0804), menuText = hex(0xFFFFD2A6)
            ),
            // ---------------------------------------------------------------- 5. 60s/70s lava lamp
            Theme(
                Fx.GROOVY, "Groovy", "☮ groovy ✿",
                tf("casual", Typeface.BOLD), hex(0xFFFFD36B), 0.02f,
                tf("serif-monospace", Typeface.BOLD), hex(0xFFFFEFD2), hex(0xCC5A1030), 4f,
                hex(0xFFFFF6E6), hex(0xFFC98FB8), "✿ ", hex(0xFFFF9A2E), hex(0xFFFFC93C), 3,
                hex(0xFFE1A730), hex(0xFF8B3A12), hex(0xFF3B1F0E), 18f, tf("casual", Typeface.BOLD),
                26f,
                hex(0xFFFF7A1A), hex(0xFFFF3D7F), hex(0xFFFFC93C), hex(0xFF3B1F0E), "☮",
                menuBg = hex(0xF5E1A730), menuText = hex(0xFF3B1F0E)
            ),
            // ---------------------------------------------------------------- 6. Jamaica / rasta 420
            Theme(
                Fx.RASTA, "Rasta 420", "ONE LOVE · 420",
                tf("sans-serif-black"), hex(0xFFFFD100), 0.1f,
                tf("monospace", Typeface.BOLD), hex(0xFFFFE680), hex(0xCC009B3A), 4f,
                hex(0xFFFFFFFF), hex(0xFF6E8F5A), "▶ ", hex(0xFF22D35E), hex(0xFFE3242B), 3,
                hex(0xFF0E2A16), hex(0xFFFFD100), hex(0xFFFFE680), 6f, tf("sans-serif-condensed", Typeface.BOLD),
                12f,
                hex(0xFF009B3A), hex(0xFFFFD100), hex(0xFFE3242B), hex(0xFF0A0A0A), "420",
                menuBg = hex(0xF20E2A16), menuText = hex(0xFFFFE680)
            ),
            // ---------------------------------------------------------------- 7. living Turing pattern
            Theme(
                Fx.MORPHOGEN, "Morphogen", "morphogen",
                tf("serif", Typeface.ITALIC), hex(0xFFEDE6D6), 0.08f,
                tf("monospace"), hex(0xFFF2EDE2), hex(0xF006070D), 3.5f,
                hex(0xFFFFFFFF), hex(0xFF7C7A8C), "~ ", hex(0xFF5FE3D6), hex(0xFFEDE6D6), 2,
                hex(0x8006070D), hex(0xCCEDE6D6), hex(0xFFF2EDE2), 10f, tf("serif", Typeface.ITALIC),
                18f,
                hex(0xFF10142B), hex(0xFF19A7A0), hex(0xFFEDE6D6), hex(0xFFF2EDE2), "∞",
                menuBg = hex(0xF00A0C18), menuText = hex(0xFFF2EDE2), iconChips = true, organicChips = true
            )
        )
    }

    fun get(i: Int): Theme = all[Math.floorMod(i, all.size)]
}

// =====================================================================================================
//  Leaf / flower shapes
// =====================================================================================================

/** Seven-fingered cannabis leaf with serrated leaflets, base at (0,0), pointing up, about [size] tall. */
internal fun cannabisLeaf(size: Float): Path {
    val p = Path()
    val ang = floatArrayOf(0f, -27f, 27f, -56f, 56f, -90f, 90f)
    val len = floatArrayOf(1f, 0.84f, 0.84f, 0.62f, 0.62f, 0.34f, 0.34f)
    for (i in ang.indices) leaflet(p, ang[i], len[i] * size, len[i] * size * 0.1f, true)
    leaflet(p, 180f, size * 0.32f, size * 0.022f, false) // stem
    return p
}

private fun leaflet(p: Path, deg: Float, len: Float, halfW: Float, teeth: Boolean) {
    val a = Math.toRadians(deg.toDouble())
    val dx = sin(a).toFloat()
    val dy = (-cos(a)).toFloat()
    val nx = -dy
    val ny = dx
    val n = 18
    p.moveTo(0f, 0f)
    for (k in 1 until n) {
        val s = k / n.toFloat()
        val prof = sin(PI * s.toDouble().pow(0.8)).toFloat()
        val tooth = if (!teeth || k % 2 == 0) 1f else 0.6f
        val hw = halfW * prof * tooth
        p.lineTo(dx * s * len + nx * hw, dy * s * len + ny * hw)
    }
    p.lineTo(dx * len, dy * len)
    for (k in n - 1 downTo 1) {
        val s = k / n.toFloat()
        val prof = sin(PI * s.toDouble().pow(0.8)).toFloat()
        val tooth = if (!teeth || k % 2 == 0) 1f else 0.6f
        val hw = halfW * prof * tooth
        p.lineTo(dx * s * len - nx * hw, dy * s * len - ny * hw)
    }
    p.close()
}

/** Things that float upward across a scene (leaves, flowers, smoke). */
private class Drifter(seed: Int, n: Int, minSize: Float, maxSize: Float, minSpeed: Float, maxSpeed: Float) {
    val x = FloatArray(n)
    val size = FloatArray(n)
    val speed = FloatArray(n)
    val off = FloatArray(n)
    val rot = FloatArray(n)
    val kind = IntArray(n)

    init {
        val r = Random(seed)
        for (i in 0 until n) {
            x[i] = 0.06f + r.nextFloat() * 0.88f
            size[i] = minSize + r.nextFloat() * (maxSize - minSize)
            speed[i] = minSpeed + r.nextFloat() * (maxSpeed - minSpeed)
            off[i] = r.nextFloat()
            rot[i] = r.nextFloat() * 360f
            kind[i] = r.nextInt(1000)
        }
    }
}

// =====================================================================================================
//  Scenes: animated backgrounds. draw() clips to the rounded panel and adds a glowing border.
// =====================================================================================================

abstract class Scene(protected val d: Float, cornerDp: Float) {
    /** Space around the panel for the outer glow. */
    val pad: Float = 5f * d
    protected val r: Float = cornerDp * d
    protected var w = 0f
    protected var h = 0f
    protected val body = RectF()
    protected val shape = Path()
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    fun resize(width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        body.set(pad, pad, w - pad, h - pad)
        shape.reset()
        shape.addRoundRect(body, r, r, Path.Direction.CW)
        if (ready()) onResize()
    }

    private fun ready() = w > 2 * pad + 4 && h > 2 * pad + 4

    protected open fun onResize() {}

    fun draw(cv: Canvas, t: Float) {
        if (!ready()) return
        cv.save()
        cv.clipPath(shape)
        background(cv, t)
        cv.restore()
        border(cv, t)
    }

    protected abstract fun background(cv: Canvas, t: Float)
    protected abstract fun border(cv: Canvas, t: Float)

    /** The user tapped something at (x, y) in panel pixels. Scenes may react. */
    open fun poke(x: Float, y: Float) {}

    /** Soft outer glow: three wide, faint strokes. With [shader] the glow takes the shader's colours. */
    protected fun glow(cv: Canvas, color: Int, alpha: Int, shader: Shader? = null) {
        glowPaint.shader = shader
        val fr = floatArrayOf(0.12f, 0.24f, 0.46f)
        for (i in 0 until 3) {
            glowPaint.strokeWidth = (3 - i) * 2.6f * d
            glowPaint.color = withAlpha(color, (alpha * fr[i]).roundToInt())
            cv.drawPath(shape, glowPaint)
        }
    }
}

object Scenes {
    fun make(t: Theme, d: Float): Scene = when (t.fx) {
        Fx.TERMINAL -> TerminalScene(d)
        Fx.NEON -> NeonScene(d)
        Fx.AURORA -> AuroraScene(d)
        Fx.INFERNO -> InfernoScene(d)
        Fx.GROOVY -> GroovyScene(d)
        Fx.RASTA -> RastaScene(d)
        Fx.MORPHOGEN -> MorphogenScene(d)
    }
}

// ----------------------------------------------------------------------------------------------- Terminal
/** Phosphor CRT: scanlines, rolling refresh band, flicker, vignette, HUD corner brackets. */
private class TerminalScene(d: Float) : Scene(d, 6f) {
    private val green = hex(0xFF39FF6A)
    private val base = Paint()
    private val vignette = Paint()
    private val scan = Paint()
    private val band = Paint()
    private val flicker = Paint()
    private val dots = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val corner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.SQUARE
    }
    private val m = Matrix()
    private var bandH = 0f
    private var bandShader: Shader? = null

    override fun onResize() {
        base.shader = LinearGradient(0f, 0f, 0f, h, hex(0xF60B170E), hex(0xF6030604), Shader.TileMode.CLAMP)
        vignette.shader = RadialGradient(
            w / 2, h / 2, max(w, h) * 0.75f,
            intArrayOf(0, 0, hex(0xA0000000)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        val rows = max(3, (3 * d).roundToInt())
        val bmp = Bitmap.createBitmap(1, rows, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(0)
        bmp.setPixel(0, 0, hex(0x46000000))
        bmp.setPixel(0, 1, hex(0x1E000000))
        scan.shader = BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        bandH = 110f * d
        val bs = LinearGradient(
            0f, 0f, 0f, bandH,
            intArrayOf(0, withAlpha(green, 0x0C), withAlpha(green, 0x2A), 0),
            floatArrayOf(0f, 0.6f, 0.86f, 1f), Shader.TileMode.CLAMP
        )
        bandShader = bs
        band.shader = bs
    }

    override fun background(cv: Canvas, t: Float) {
        cv.drawRect(0f, 0f, w, h, base)
        // faint phosphor dot matrix
        val step = 14f * d
        dots.color = withAlpha(green, 0x10)
        var y = pad + step / 2
        while (y < h) {
            var x = pad + step / 2
            while (x < w) {
                cv.drawCircle(x, y, 0.7f * d, dots)
                x += step
            }
            y += step
        }
        // rolling refresh band
        val by = frac(t / 6f) * (h + bandH) - bandH
        m.setTranslate(0f, by)
        bandShader?.setLocalMatrix(m)
        cv.drawRect(0f, by, w, by + bandH, band)
        cv.drawRect(0f, 0f, w, h, scan)
        val fl = (6f + 5f * sin(t * 37f) * sin(t * 5.3f)).roundToInt()
        flicker.color = withAlpha(green, fl.coerceAtLeast(0))
        cv.drawRect(0f, 0f, w, h, flicker)
        cv.drawRect(0f, 0f, w, h, vignette)
    }

    override fun border(cv: Canvas, t: Float) {
        val pulse = 0.7f + 0.3f * sin(t * 2.2f)
        glow(cv, green, (170 * pulse).roundToInt())
        edge.strokeWidth = 1.2f * d
        edge.color = withAlpha(green, 0xD0)
        cv.drawPath(shape, edge)
        // HUD corner brackets
        corner.strokeWidth = 2f * d
        corner.color = withAlpha(green, (200 + 55 * pulse).roundToInt().coerceAtMost(255))
        val len = 12f * d
        val i = 3.5f * d
        val l = body.left + i
        val tp = body.top + i
        val rt = body.right - i
        val bt = body.bottom - i
        cv.drawLine(l, tp + len, l, tp, corner); cv.drawLine(l, tp, l + len, tp, corner)
        cv.drawLine(rt - len, tp, rt, tp, corner); cv.drawLine(rt, tp, rt, tp + len, corner)
        cv.drawLine(l, bt - len, l, bt, corner); cv.drawLine(l, bt, l + len, bt, corner)
        cv.drawLine(rt - len, bt, rt, bt, corner); cv.drawLine(rt, bt, rt, bt - len, corner)
    }
}

// ----------------------------------------------------------------------------------------------- Neon
/** Synthwave: starry sky, striped sun, scrolling perspective grid, rotating neon border. */
private class NeonScene(d: Float) : Scene(d, 14f) {
    private val pink = hex(0xFFFF2CDF)
    private val cyan = hex(0xFF00E5FF)
    private val purple = hex(0xFF8C1EFF)
    private val sky = Paint()
    private val floor = Paint()
    private val haze = Paint()
    private val sun = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sunGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val star = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scrim = Paint().apply { color = hex(0x38000000) }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private var sweep: Shader? = null
    private var hy = 0f
    private var sr = 0f
    private val starData = Array(34) { FloatArray(5) }

    init {
        val rnd = Random(1984)
        for (s in starData) {
            s[0] = rnd.nextFloat()
            s[1] = rnd.nextFloat()
            s[2] = 0.5f + rnd.nextFloat() * 1.1f
            s[3] = 1f + rnd.nextFloat() * 3f
            s[4] = rnd.nextFloat() * 6.28f
        }
    }

    override fun onResize() {
        hy = h * 0.62f
        sr = min(w * 0.2f, hy * 0.62f)
        sky.shader = LinearGradient(
            0f, 0f, 0f, hy,
            intArrayOf(hex(0xFF07011A), hex(0xFF250742), hex(0xFF661478)), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        floor.shader = LinearGradient(0f, hy, 0f, h, hex(0xFF1C0533), hex(0xFF05010C), Shader.TileMode.CLAMP)
        haze.shader = LinearGradient(0f, hy, 0f, hy + (h - hy) * 0.5f, hex(0xDD3B0A5A), 0, Shader.TileMode.CLAMP)
        sun.shader = LinearGradient(
            0f, hy - sr, 0f, hy,
            intArrayOf(hex(0xFFFFE66D), hex(0xFFFF8A5B), hex(0xFFFF2CDF)), floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        sunGlow.shader = RadialGradient(
            w / 2, hy, sr * 2.5f,
            intArrayOf(hex(0x88FF2CDF), hex(0x22FF2CDF), 0), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        val sw = SweepGradient(w / 2, h / 2, intArrayOf(pink, cyan, purple, pink), null)
        sweep = sw
        edge.shader = sw
    }

    override fun background(cv: Canvas, t: Float) {
        cv.drawRect(0f, 0f, w, hy, sky)
        for (s in starData) {
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * s[3] + s[4]))
            star.color = withAlpha(Color.WHITE, (tw * 220).roundToInt())
            cv.drawCircle(s[0] * w, s[1] * hy * 0.78f, s[2] * d, star)
        }
        cv.drawCircle(w / 2, hy, sr * 2.5f, sunGlow)
        cv.save()
        cv.clipRect(0f, 0f, w, hy)
        cv.drawCircle(w / 2, hy, sr, sun)
        // classic sun cut-outs, sliding down
        val top = hy - sr * 0.64f
        val span = hy - top
        val f = frac(t * 0.22f)
        for (i in 0 until 7) {
            val p = (i + f) / 7f
            val yy = top + p * span
            val th = (0.5f + p * 4.6f) * d
            cv.drawRect(w / 2 - sr - 2f, yy, w / 2 + sr + 2f, yy + th, sky)
        }
        cv.restore()
        cv.drawRect(0f, hy, w, h, floor)
        // perspective grid rushing toward you
        grid.strokeWidth = 1.1f * d
        val n = 11
        val g = frac(t * 0.55f)
        for (i in 0 until n) {
            val p = (i + g) / n
            val yy = hy + (h - hy) * p * p
            grid.color = withAlpha(pink, (30 + 210 * p).roundToInt())
            cv.drawLine(0f, yy, w, yy, grid)
        }
        grid.color = withAlpha(pink, 165)
        for (k in -12..12) {
            val xb = w / 2 + k * w * 0.13f
            val xt = w / 2 + k * w * 0.017f
            cv.drawLine(xt, hy, xb, h + 2f * d, grid)
        }
        cv.drawRect(0f, hy, w, h, haze)
        // horizon line
        grid.color = withAlpha(cyan, 70)
        grid.strokeWidth = 5f * d
        cv.drawLine(0f, hy, w, hy, grid)
        grid.color = cyan
        grid.strokeWidth = 1.3f * d
        cv.drawLine(0f, hy, w, hy, grid)
        cv.drawRect(0f, 0f, w, h, scrim)
    }

    override fun border(cv: Canvas, t: Float) {
        m.setRotate((t * 70f) % 360f, w / 2, h / 2)
        sweep?.setLocalMatrix(m)
        glow(cv, pink, 255, sweep)
        edge.strokeWidth = 1.8f * d
        edge.color = Color.WHITE
        cv.drawPath(shape, edge)
    }
}

// ----------------------------------------------------------------------------------------------- Aurora
/** Frosted glass: drifting aurora light blobs (screen-blended), grain, sheen sweep, gradient rim. */
private class AuroraScene(d: Float) : Scene(d, 22f) {
    private class Blob(val color: Int, val fx: Float, val fy: Float, val ph: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
        var shader: Shader? = null
    }

    private val base = Paint().apply { color = hex(0xF20B1022) }
    private val blobs = listOf(
        Blob(hex(0xFF00F5D4), 0.23f, 0.17f, 0f),
        Blob(hex(0xFF9B5DE5), 0.19f, 0.27f, 2.1f),
        Blob(hex(0xFFF15BB5), 0.29f, 0.13f, 4.2f),
        Blob(hex(0xFF3A86FF), 0.13f, 0.21f, 1.3f)
    )
    private val frost = Paint()
    private val sheenTop = Paint()
    private val sweepPaint = Paint()
    private var sweepShader: Shader? = null
    private var sweepW = 0f
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()

    override fun onResize() {
        val rad = max(w, h) * 0.62f
        for (b in blobs) {
            val s = RadialGradient(
                0f, 0f, rad,
                intArrayOf(withAlpha(b.color, 0xA0), withAlpha(b.color, 0x38), withAlpha(b.color, 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            b.shader = s
            b.paint.shader = s
        }
        val n = 96
        val px = IntArray(n * n)
        val rnd = Random(7)
        for (i in px.indices) px[i] = withAlpha(Color.WHITE, rnd.nextInt(0, 17))
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, n, 0, 0, n, n)
        frost.shader = BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        sheenTop.shader = LinearGradient(0f, 0f, 0f, h * 0.5f, hex(0x24FFFFFF), 0, Shader.TileMode.CLAMP)
        sweepW = w * 0.28f
        val ss = LinearGradient(0f, 0f, sweepW, 0f, intArrayOf(0, hex(0x2AFFFFFF), 0), null, Shader.TileMode.CLAMP)
        sweepShader = ss
        sweepPaint.shader = ss
        edge.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(hex(0xDD00F5D4), hex(0x77FFFFFF), hex(0xDDF15BB5)), null, Shader.TileMode.CLAMP
        )
    }

    override fun background(cv: Canvas, t: Float) {
        cv.drawRect(0f, 0f, w, h, base)
        for (b in blobs) {
            val cx = w * (0.5f + 0.42f * sin(t * b.fx + b.ph))
            val cy = h * (0.5f + 0.48f * cos(t * b.fy + b.ph * 1.3f))
            val s = 0.8f + 0.2f * sin(t * 0.4f + b.ph)
            m.setScale(s, s)
            m.postTranslate(cx, cy)
            b.shader?.setLocalMatrix(m)
            cv.drawRect(0f, 0f, w, h, b.paint)
        }
        cv.drawRect(0f, 0f, w, h, frost)
        cv.drawRect(0f, 0f, w, h, sheenTop)
        val p = frac(t / 7f) * 7f / 2.2f // light sweeps across for 2.2 s every 7 s
        if (p < 1f) {
            val x = -sweepW * 1.6f + p * (w + sweepW * 3.2f)
            m.setRotate(18f)
            m.postTranslate(x, 0f)
            sweepShader?.setLocalMatrix(m)
            cv.drawRect(0f, 0f, w, h, sweepPaint)
        }
    }

    override fun border(cv: Canvas, t: Float) {
        val pulse = 0.6f + 0.4f * sin(t * 1.1f)
        glow(cv, hex(0xFF7FE7FF), (120 * pulse).roundToInt())
        edge.strokeWidth = 1.2f * d
        edge.color = Color.WHITE
        cv.drawPath(shape, edge)
    }
}

// ----------------------------------------------------------------------------------------------- Inferno
/** Heat glow, three layers of licking flames, rising embers, molten shimmering border. */
private class InfernoScene(d: Float) : Scene(d, 10f) {
    private val base = Paint()
    private val heat = Paint()
    private val flame = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val flameH = floatArrayOf(0.26f, 0.18f, 0.11f)
    private val flameCol = intArrayOf(hex(0xFFB01200), hex(0xFFFF4A00), hex(0xFFFFB000))
    private val flamePath = Path()
    private val ember = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var edgeShader: Shader? = null
    private val m = Matrix()
    private val n = 60
    private val ex = FloatArray(n)
    private val spd = FloatArray(n)
    private val swA = FloatArray(n)
    private val swF = FloatArray(n)
    private val sz = FloatArray(n)
    private val off = FloatArray(n)
    private val hue = FloatArray(n)

    init {
        val rnd = Random(66)
        for (i in 0 until n) {
            ex[i] = rnd.nextFloat()
            spd[i] = 0.05f + rnd.nextFloat() * 0.17f
            swA[i] = (3f + rnd.nextFloat() * 12f) * d
            swF[i] = 0.6f + rnd.nextFloat() * 1.6f
            sz[i] = (0.7f + rnd.nextFloat() * 1.7f) * d
            off[i] = rnd.nextFloat()
            hue[i] = rnd.nextFloat()
        }
    }

    override fun onResize() {
        base.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(hex(0xF6100302), hex(0xF61A0503), hex(0xF63A0C02)), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        heat.shader = RadialGradient(
            w / 2, h * 1.08f, max(w, h) * 0.85f,
            intArrayOf(hex(0xCCFF4500), hex(0x55FF2A00), 0), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        for (i in 0 until 3) {
            val fh = h * flameH[i]
            flame[i].shader = LinearGradient(
                0f, h - fh * 1.1f, 0f, h,
                intArrayOf(withAlpha(flameCol[i], 0), withAlpha(flameCol[i], 0x70), withAlpha(flameCol[i], 0xB0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
        }
        val es = LinearGradient(
            0f, 0f, w * 0.5f, 0f,
            intArrayOf(hex(0xFFFF2A00), hex(0xFFFFC400), hex(0xFFFF2A00)), null, Shader.TileMode.MIRROR
        )
        edgeShader = es
        edge.shader = es
    }

    override fun background(cv: Canvas, t: Float) {
        cv.drawRect(0f, 0f, w, h, base)
        heat.alpha = (175 + 55 * sin(t * 1.6f) + 25 * sin(t * 11.3f) * sin(t * 3.1f)).roundToInt().coerceIn(0, 255)
        cv.drawRect(0f, 0f, w, h, heat)
        val step = 5f * d
        for (layer in 0 until 3) {
            val fh = h * flameH[layer]
            flamePath.reset()
            flamePath.moveTo(0f, h)
            var x = 0f
            while (x <= w + step) {
                val y = h - fh * (
                    0.55f +
                        0.28f * sin(x / (26f * d) + t * (1.9f + layer * 0.6f) + layer * 1.7f) +
                        0.17f * sin(x / (9f * d) - t * (3.7f + layer) + layer)
                    )
                flamePath.lineTo(x, y)
                x += step
            }
            flamePath.lineTo(w, h)
            flamePath.close()
            cv.drawPath(flamePath, flame[layer])
        }
        for (i in 0 until n) {
            val life = frac(t * spd[i] + off[i])
            val y = h + 6f * d - life * (h + 12f * d)
            val x = ex[i] * w + sin(t * swF[i] + off[i] * 20f) * swA[i]
            val fl = 0.75f + 0.25f * sin(t * (9f + i % 7) + i)
            val a = (1f - life).pow(0.9f) * fl
            val col = mix(hex(0xFFFFE08A), hex(0xFFFF3D00), hue[i])
            ember.color = withAlpha(col, (a * 55).roundToInt())
            cv.drawCircle(x, y, sz[i] * 3.2f, ember)
            ember.color = withAlpha(col, (a * 255).roundToInt())
            cv.drawCircle(x, y, sz[i], ember)
        }
    }

    override fun border(cv: Canvas, t: Float) {
        m.setTranslate(t * 70f * d, 0f)
        edgeShader?.setLocalMatrix(m)
        glow(cv, hex(0xFFFF5A00), (200 + 45 * sin(t * 2.7f)).roundToInt(), edgeShader)
        edge.strokeWidth = 1.5f * d
        edge.color = Color.WHITE
        cv.drawPath(shape, edge)
    }
}

// ----------------------------------------------------------------------------------------------- Groovy
/**
 * 60s/70s: a real lava lamp (metaballs rendered per pixel at low resolution, then smoothly upscaled),
 * glass reflection, floating weed leaves and daisies, slow psychedelic rays, retro striped frame.
 */
private class GroovyScene(d: Float) : Scene(d, 26f) {
    private val lw = 96
    private var lh = 96
    private var bmp: Bitmap? = null
    private var px = IntArray(0)
    private var rowBg = IntArray(0)
    private var rowLava = IntArray(0)
    private var rowHot = IntArray(0)
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    // wax blobs: x, radius, speed, phase
    private val bx = floatArrayOf(0.28f, 0.64f, 0.46f, 0.78f, 0.2f, 0.56f, 0.86f)
    private val br = floatArrayOf(0.13f, 0.16f, 0.1f, 0.12f, 0.09f, 0.14f, 0.08f)
    private val bs = floatArrayOf(0.21f, 0.15f, 0.27f, 0.18f, 0.24f, 0.12f, 0.3f)
    private val bp = floatArrayOf(0f, 2.2f, 4.1f, 1.1f, 5.3f, 3.3f, 0.6f)
    private val cx = FloatArray(bx.size)
    private val cy = FloatArray(bx.size)
    private val rr = FloatArray(bx.size)

    private val rays = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rayPath = Path()
    private val drift = Drifter(70, 9, 18f, 34f, 0.025f, 0.06f)
    private val leaves = Array(9) { cannabisLeaf(drift.size[it] * d) }
    private val leafCols = intArrayOf(hex(0xFF7A9A2E), hex(0xFF9BBF3A), hex(0xFF5E7F22))
    private val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vein = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val petal = Paint(Paint.ANTI_ALIAS_FLAG)
    private val heart = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val sheen = Paint()
    private val vignette = Paint()
    private val stripe = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val scrim = Paint().apply { color = hex(0x661A0618) }

    override fun onResize() {
        lh = (lw * h / w).roundToInt().coerceIn(48, 180)
        bmp = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888)
        px = IntArray(lw * lh)
        val last = (lh - 1).toFloat()
        rowBg = IntArray(lh) { y -> mix(hex(0xFF2A0B3D), hex(0xFF5C1830), y / last) }
        rowLava = IntArray(lh) { y ->
            val f = y / last
            if (f < 0.5f) mix(hex(0xFFC92A62), hex(0xFFD9581A), f / 0.5f)
            else mix(hex(0xFFD9581A), hex(0xFFE89A2E), (f - 0.5f) / 0.5f)
        }
        rowHot = IntArray(lh) { y -> mix(rowLava[y], hex(0xFFFFE2A0), 0.45f) }
        dst.set(0f, 0f, w, h)
        sheen.shader = LinearGradient(
            w * 0.05f, 0f, w * 0.22f, 0f,
            intArrayOf(0, hex(0x30FFFFFF), 0), null, Shader.TileMode.CLAMP
        )
        vignette.shader = RadialGradient(
            w / 2, h / 2, max(w, h) * 0.75f,
            intArrayOf(0, hex(0x7A1A0010)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun renderLava(t: Float) {
        val b = bmp ?: return
        for (i in bx.indices) {
            cx[i] = (bx[i] + 0.07f * sin(t * bs[i] * 1.7f + bp[i] * 2f)) * lw
            cy[i] = (0.5f + 0.56f * sin(t * bs[i] + bp[i])) * lh
            val rad = br[i] * lw * (1f + 0.12f * sin(t * 0.9f + bp[i]))
            rr[i] = rad * rad
        }
        var k = 0
        for (y in 0 until lh) {
            val fy = y.toFloat()
            val yn = fy / lh
            val pool = smoothstep(0.82f, 1f, yn) * 1.7f + smoothstep(0.1f, 0f, yn) * 0.9f
            val bg = rowBg[y]
            val lava = rowLava[y]
            val hot = rowHot[y]
            for (x in 0 until lw) {
                var f = pool
                for (i in bx.indices) {
                    val dx = x - cx[i]
                    val dy = fy - cy[i]
                    f += rr[i] / (dx * dx + dy * dy + 1f)
                }
                val v = smoothstep(0.84f, 1.16f, f) // soft edge = anti-aliased after upscaling
                px[k++] = if (v <= 0f) {
                    val rim = exp(-(f - 0.8f) * (f - 0.8f) / 0.018f) * 0.4f // warm halo around the wax
                    if (rim > 0.02f) mix(bg, lava, rim) else bg
                } else {
                    val wax = mix(lava, hot, smoothstep(1.5f, 3.4f, f))
                    if (v >= 1f) wax else mix(bg, wax, v)
                }
            }
        }
        b.setPixels(px, 0, lw, 0, 0, lw, lh)
    }

    private fun daisy(cv: Canvas, x: Float, y: Float, rad: Float, rot: Float, a: Int) {
        cv.save()
        cv.translate(x, y)
        cv.rotate(rot)
        petal.color = withAlpha(hex(0xFFFFF4E0), a)
        for (i in 0 until 10) {
            oval.set(-rad * 0.2f, -rad, rad * 0.2f, -rad * 0.16f)
            cv.drawOval(oval, petal)
            cv.rotate(36f)
        }
        heart.color = withAlpha(hex(0xFFFFB627), a)
        cv.drawCircle(0f, 0f, rad * 0.27f, heart)
        cv.restore()
    }

    override fun background(cv: Canvas, t: Float) {
        renderLava(t)
        bmp?.let { cv.drawBitmap(it, null, dst, bmpPaint) }
        cv.drawRect(0f, 0f, w, h, scrim) // keeps the log readable over the wax

        // slow psychedelic sunburst from the bottom
        cv.save()
        cv.translate(w / 2, h * 1.05f)
        cv.rotate((t * 6f) % 360f)
        rays.color = hex(0x10FFE3A8)
        val big = max(w, h) * 1.6f
        for (i in 0 until 12) {
            rayPath.reset()
            rayPath.moveTo(0f, 0f)
            rayPath.lineTo(big * cos(0f), big * sin(0f))
            val a2 = (PI / 12).toFloat()
            rayPath.lineTo(big * cos(a2), big * sin(a2))
            rayPath.close()
            cv.drawPath(rayPath, rays)
            cv.rotate(30f)
        }
        cv.restore()

        // floating leaves and flowers
        for (i in 0 until drift.x.size) {
            val life = frac(t * drift.speed[i] + drift.off[i])
            val sz = drift.size[i] * d
            val y = h + sz * 1.4f - life * (h + sz * 2.8f)
            val x = drift.x[i] * w + sin(t * 0.5f + i * 1.7f) * 14f * d
            val rot = drift.rot[i] + sin(t * 0.7f + i) * 24f
            val a = (sin(PI.toFloat() * life) * 255).roundToInt()
            if (drift.kind[i] % 3 == 0) {
                daisy(cv, x, y, sz * 0.55f, rot + t * 12f, (a * 0.75f).roundToInt())
            } else {
                cv.save()
                cv.translate(x, y + sz * 0.45f)
                cv.rotate(rot)
                leafPaint.color = withAlpha(leafCols[i % leafCols.size], (a * 0.62f).roundToInt())
                cv.drawPath(leaves[i], leafPaint)
                vein.strokeWidth = 0.8f * d
                vein.color = withAlpha(hex(0xFFE9F5B0), (a * 0.35f).roundToInt())
                cv.drawLine(0f, sz * 0.3f, 0f, -sz * 0.9f, vein)
                cv.restore()
            }
        }
        cv.drawRect(0f, 0f, w, h, sheen)
        cv.drawRect(0f, 0f, w, h, vignette)
    }

    override fun border(cv: Canvas, t: Float) {
        // retro 70s racing stripes
        stripe.strokeWidth = 7f * d
        stripe.color = hex(0xFF5B2A12)
        cv.drawPath(shape, stripe)
        stripe.strokeWidth = 4.4f * d
        stripe.color = hex(0xFFD9541E)
        cv.drawPath(shape, stripe)
        stripe.strokeWidth = 1.8f * d
        stripe.color = mix(hex(0xFFE1A730), hex(0xFFFFE08A), 0.5f + 0.5f * sin(t * 1.5f))
        cv.drawPath(shape, stripe)
    }
}

// ----------------------------------------------------------------------------------------------- Rasta 420
/**
 * Jamaica: flag watermark, big leaf pulsing to a 76 bpm one-drop beat, smoke rising, floating leaves,
 * equalizer, waving red/gold/green ribbons, barber-pole tricolour frame.
 */
private class RastaScene(d: Float) : Scene(d, 12f) {
    private val red = hex(0xFFE3242B)
    private val gold = hex(0xFFFFD100)
    private val green = hex(0xFF009B3A)
    private val base = Paint().apply { color = hex(0xF60A0A0A) }
    private val flagGreen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(hex(0xFF009B3A), 0x2A) }
    private val saltire = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = withAlpha(hex(0xFFFFD100), 0x26)
    }
    private val triTop = Path()
    private val triBot = Path()
    private var bigLeaf = Path()
    private var bigLeafSize = 0f
    private val bigLeafPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val smoke = Paint(Paint.ANTI_ALIAS_FLAG)
    private var smokeShader: Shader? = null
    private val smokeR get() = 30f * d
    private val puffs = Drifter(42, 14, 0f, 1f, 0.05f, 0.11f)
    private val drift = Drifter(420, 6, 14f, 24f, 0.03f, 0.07f)
    private val leaves = Array(6) { cannabisLeaf(drift.size[it] * d) }
    private val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val eq = Paint()
    private val ribbon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ribbonPath = Path()
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var barber: Shader? = null
    private val m = Matrix()
    private var eqBottom = 0f
    private val eqMax get() = 22f * d

    override fun onResize() {
        triTop.reset()
        triTop.moveTo(0f, 0f); triTop.lineTo(w, 0f); triTop.lineTo(w / 2, h / 2); triTop.close()
        triBot.reset()
        triBot.moveTo(0f, h); triBot.lineTo(w, h); triBot.lineTo(w / 2, h / 2); triBot.close()
        saltire.strokeWidth = min(w, h) * 0.13f
        bigLeafSize = min(w, h) * 0.42f
        bigLeaf = cannabisLeaf(bigLeafSize)
        eqBottom = h - pad - 44f * d
        eq.shader = LinearGradient(
            0f, eqBottom, 0f, eqBottom - eqMax,
            intArrayOf(green, gold, red), null, Shader.TileMode.CLAMP
        )
        val ss = RadialGradient(
            0f, 0f, smokeR,
            intArrayOf(hex(0xFFE6E6E6), hex(0x66E6E6E6), hex(0x00E6E6E6)), floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        smokeShader = ss
        smoke.shader = ss
        val b = LinearGradient(
            0f, 0f, 30f * d, 30f * d,
            intArrayOf(red, red, gold, gold, green, green),
            floatArrayOf(0f, 0.333f, 0.333f, 0.667f, 0.667f, 1f), Shader.TileMode.REPEAT
        )
        barber = b
        edge.shader = b
    }

    override fun background(cv: Canvas, t: Float) {
        cv.drawRect(0f, 0f, w, h, base)
        cv.drawPath(triTop, flagGreen)
        cv.drawPath(triBot, flagGreen)
        cv.drawLine(0f, 0f, w, h, saltire)
        cv.drawLine(w, 0f, 0f, h, saltire)

        val beat = t * 76f / 60f
        val kick = exp(-frac(beat) * 6f)

        // big leaf breathing on the beat
        cv.save()
        cv.translate(w / 2, h * 0.5f + bigLeafSize * 0.38f)
        val s = 1f + 0.05f * kick
        cv.scale(s, s)
        cv.rotate(sin(t * 0.4f) * 4f)
        bigLeafPaint.color = withAlpha(green, 0x34 + (0x1C * kick).roundToInt())
        cv.drawPath(bigLeaf, bigLeafPaint)
        cv.restore()

        // smoke drifting up
        for (i in 0 until puffs.x.size) {
            val life = frac(t * puffs.speed[i] + puffs.off[i])
            val x = puffs.x[i] * w + sin(t * 0.8f + i) * 18f * d * life
            val y = h - 16f * d - life * h * 0.95f
            val rad = (8f + 34f * life) * d
            m.setScale(rad / smokeR, rad / smokeR)
            m.postTranslate(x, y)
            smokeShader?.setLocalMatrix(m)
            smoke.alpha = (sin(PI.toFloat() * life) * 0x30).roundToInt()
            cv.drawCircle(x, y, rad, smoke)
        }

        // floating leaves
        for (i in 0 until drift.x.size) {
            val life = frac(t * drift.speed[i] + drift.off[i])
            val sz = drift.size[i] * d
            val y = h + sz * 1.4f - life * (h + sz * 2.8f)
            val x = drift.x[i] * w + sin(t * 0.6f + i * 2.1f) * 12f * d
            cv.save()
            cv.translate(x, y + sz * 0.45f)
            cv.rotate(drift.rot[i] + sin(t * 0.8f + i) * 26f)
            val col = when (i % 3) { 0 -> green; 1 -> gold; else -> red }
            leafPaint.color = withAlpha(col, (sin(PI.toFloat() * life) * 0x8C).roundToInt())
            cv.drawPath(leaves[i], leafPaint)
            cv.restore()
        }

        // equalizer bouncing to the riddim
        val bars = 12
        val bw = 3.6f * d
        val gap = 2.4f * d
        val x0 = w - pad - 12f * d - bars * (bw + gap)
        eq.alpha = 0xB4
        for (i in 0 until bars) {
            val lvl = (0.2f + 0.8f * abs(sin(t * (1.7f + i * 0.31f) + i * 1.3f)) * (0.5f + 0.5f * kick)).coerceIn(0f, 1f)
            val x = x0 + i * (bw + gap)
            cv.drawRect(x, eqBottom - eqMax * lvl, x + bw, eqBottom, eq)
        }

        // waving ribbons along the bottom
        val cols = intArrayOf(red, gold, green)
        val thick = 4.6f * d
        val step = 5f * d
        for (k in 0 until 3) {
            val y0 = h - pad - 2f * d - (3 - k) * thick
            ribbonPath.reset()
            var x = 0f
            ribbonPath.moveTo(0f, y0)
            while (x <= w + step) {
                ribbonPath.lineTo(x, y0 + 2.4f * d * sin(x / (22f * d) - t * 2.4f + k * 0.5f))
                x += step
            }
            x -= step
            while (x >= -step) {
                ribbonPath.lineTo(x, y0 + thick + 2.4f * d * sin(x / (22f * d) - t * 2.4f + (k + 1) * 0.5f))
                x -= step
            }
            ribbonPath.close()
            ribbon.color = withAlpha(cols[k], 0xC8)
            cv.drawPath(ribbonPath, ribbon)
        }
    }

    override fun border(cv: Canvas, t: Float) {
        m.setTranslate(t * 22f * d, 0f)
        barber?.setLocalMatrix(m)
        glow(cv, gold, 140)
        edge.strokeWidth = 3.2f * d
        edge.color = Color.WHITE
        cv.drawPath(shape, edge)
    }
}

// ----------------------------------------------------------------------------------------------- Morphogen
/**
 * A living Turing pattern: Gray-Scott reaction-diffusion simulated live (two "chemicals" that feed on and
 * kill each other). The feed/kill rates drift slowly through five regimes, so the surface morphs between
 * dividing cells, fingerprints, coral, labyrinths and foam and never repeats. Taps seed new growth.
 * Colour: ink and bone with an iridescent rim whose hue drifts like oil on water.
 */
private class MorphogenScene(d: Float) : Scene(d, 18f) {
    private val gw = 108
    private var gh = 108
    private var u = FloatArray(0)
    private var v = FloatArray(0)
    private var u2 = FloatArray(0)
    private var v2 = FloatArray(0)
    private var px = IntArray(0)
    private var bmp: Bitmap? = null
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val lut = IntArray(256)
    private var lutT = -10f
    private var rim = hex(0xFF19A7A0)
    private val rnd = Random(1952) // the year of Turing's morphogenesis paper
    private var checkT = 0f
    private var curF = 0f
    private var curK = 0f
    private val grain = Paint()
    private val scrim = Paint().apply { color = hex(0x6006070D) }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bone = hex(0xFFD9D1BE)
    private val regimes = arrayOf(
        floatArrayOf(0.0367f, 0.0649f), // mitosis: cells that divide
        floatArrayOf(0.037f, 0.06f), // fingerprints
        floatArrayOf(0.0545f, 0.062f), // coral growth
        floatArrayOf(0.029f, 0.057f), // labyrinth
        floatArrayOf(0.039f, 0.058f) // foam / holes
    )
    private val rims = intArrayOf(
        hex(0xFF5B3FD1), hex(0xFF19A7A0), hex(0xFFD14F8C), hex(0xFF2E7BE0), hex(0xFFE0A23A)
    )

    override fun onResize() {
        gh = (gw * h / w).roundToInt().coerceIn(48, 200)
        val n = gw * gh
        u = FloatArray(n) { 1f }
        v = FloatArray(n)
        u2 = FloatArray(n)
        v2 = FloatArray(n)
        px = IntArray(n)
        bmp = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
        dst.set(0f, 0f, w, h)
        repeat(16) { seed(rnd.nextFloat() * gw, rnd.nextFloat() * gh, 3 + rnd.nextInt(3)) }
        repeat(700) { step(regimes[0][0], regimes[0][1]) } // start with a grown pattern, not a blank page
        val gn = 96
        val g = IntArray(gn * gn)
        val gr = Random(3)
        for (i in g.indices) g[i] = withAlpha(if (gr.nextBoolean()) Color.WHITE else Color.BLACK, gr.nextInt(0, 14))
        val gb = Bitmap.createBitmap(gn, gn, Bitmap.Config.ARGB_8888)
        gb.setPixels(g, 0, gn, 0, 0, gn, gn)
        grain.shader = BitmapShader(gb, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    private fun seed(gx: Float, gy: Float, r: Int) {
        val cx = gx.roundToInt()
        val cy = gy.roundToInt()
        for (dy in -r..r) for (dx in -r..r) {
            if (dx * dx + dy * dy > r * r) continue
            val x = Math.floorMod(cx + dx, gw)
            val y = Math.floorMod(cy + dy, gh)
            val i = y * gw + x
            u[i] = 0.5f
            v[i] = 0.25f + rnd.nextFloat() * 0.1f
        }
    }

    override fun poke(x: Float, y: Float) {
        if (u.isEmpty() || w <= 0f || h <= 0f) return
        seed(x / w * gw, y / h * gh, 4)
    }

    /** One Gray-Scott step (Du = 1, Dv = 0.5, 9-point Laplacian, wrap-around edges). */
    private fun step(f: Float, k: Float) {
        val ww = gw
        val hh = gh
        val uu = u
        val vv = v
        val un = u2
        val vn = v2
        for (y in 0 until hh) {
            val ym = (if (y == 0) hh - 1 else y - 1) * ww
            val y0 = y * ww
            val yp = (if (y == hh - 1) 0 else y + 1) * ww
            for (x in 0 until ww) {
                val xm = if (x == 0) ww - 1 else x - 1
                val xp = if (x == ww - 1) 0 else x + 1
                val i = y0 + x
                val uc = uu[i]
                val vc = vv[i]
                val lu = 0.2f * (uu[y0 + xm] + uu[y0 + xp] + uu[ym + x] + uu[yp + x]) +
                    0.05f * (uu[ym + xm] + uu[ym + xp] + uu[yp + xm] + uu[yp + xp]) - uc
                val lv = 0.2f * (vv[y0 + xm] + vv[y0 + xp] + vv[ym + x] + vv[yp + x]) +
                    0.05f * (vv[ym + xm] + vv[ym + xp] + vv[yp + xm] + vv[yp + xp]) - vc
                val uvv = uc * vc * vc
                un[i] = uc + (lu - uvv + f * (1f - uc))
                vn[i] = vc + (0.5f * lv + uvv - (k + f) * vc)
            }
        }
        u = un
        v = vn
        u2 = uu
        v2 = vv
    }

    private fun drift(t: Float) {
        val p = t / 48f
        val i = floor(p).toInt()
        val m = smoothstep(0.6f, 1f, p - i)
        val a = regimes[Math.floorMod(i, regimes.size)]
        val b = regimes[Math.floorMod(i + 1, regimes.size)]
        curF = a[0] + (b[0] - a[0]) * m
        curK = a[1] + (b[1] - a[1]) * m
    }

    private fun buildLut(t: Float) {
        val ph = t / 9f
        val i = floor(ph).toInt()
        val fr = ph - i
        val n = rims.size
        val rimA = mix(rims[Math.floorMod(i, n)], rims[Math.floorMod(i + 1, n)], fr)
        val rimB = mix(rims[Math.floorMod(i + 2, n)], rims[Math.floorMod(i + 3, n)], fr)
        rim = rimB
        val at = floatArrayOf(0f, 0.07f, 0.14f, 0.2f, 0.26f, 0.42f)
        val cs = intArrayOf(hex(0xFF06070D), hex(0xFF0E1230), rimA, rimB, bone, hex(0xFFFFFCF2))
        for (j in 0 until 256) {
            val x = j / 255f * 0.42f
            var s = 0
            while (s < at.size - 2 && x > at[s + 1]) s++
            lut[j] = mix(cs[s], cs[s + 1], (x - at[s]) / (at[s + 1] - at[s]))
        }
    }

    override fun background(cv: Canvas, t: Float) {
        val b = bmp ?: return
        drift(t)
        repeat(STEPS) { step(curF, curK) }
        if (t - checkT > 2.5f || t < checkT) { // keep it alive: reseed if a regime change wiped it out
            checkT = t
            var sum = 0f
            var i = 0
            var cnt = 0
            while (i < v.size) {
                sum += v[i]; cnt++; i += 37
            }
            if (cnt > 0 && sum / cnt < 0.012f) repeat(8) { seed(rnd.nextFloat() * gw, rnd.nextFloat() * gh, 4) }
        }
        if (abs(t - lutT) > 0.2f) {
            buildLut(t)
            lutT = t
        }
        val vv = v
        for (i in px.indices) px[i] = lut[(vv[i] * 607f).toInt().coerceIn(0, 255)]
        b.setPixels(px, 0, gw, 0, 0, gw, gh)
        cv.drawBitmap(b, null, dst, bmpPaint)
        cv.drawRect(0f, 0f, w, h, scrim)
        cv.drawRect(0f, 0f, w, h, grain)
    }

    override fun border(cv: Canvas, t: Float) {
        glow(cv, rim, 120)
        edge.strokeWidth = 1f * d
        edge.color = withAlpha(bone, 0xC8)
        cv.drawPath(shape, edge)
        // specimen-slide ruler ticks down both sides
        var y = body.top + r
        var n = 0
        while (y < body.bottom - r) {
            val major = n % 5 == 0
            val len = (if (major) 6f else 3f) * d
            tick.strokeWidth = (if (major) 1.2f else 0.8f) * d
            tick.color = withAlpha(bone, if (major) 0xB0 else 0x70)
            cv.drawLine(body.left + 2.5f * d, y, body.left + 2.5f * d + len, y, tick)
            cv.drawLine(body.right - 2.5f * d, y, body.right - 2.5f * d - len, y, tick)
            y += 8f * d
            n++
        }
    }

    companion object {
        const val STEPS = 6
    }
}

// =====================================================================================================
//  Views
// =====================================================================================================

/** Animated theme background behind the terminal panel. Animates only while it is on screen. */
@SuppressLint("ViewConstructor")
class ThemeBackdrop(ctx: Context) : View(ctx) {
    private val density = resources.displayMetrics.density
    private val start = SystemClock.uptimeMillis()
    private var scene: Scene = Scenes.make(Themes.get(0), density)

    var theme: Theme = Themes.get(0)
        set(v) {
            field = v
            scene = Scenes.make(v, density)
            if (width > 0 && height > 0) scene.resize(width, height)
            invalidate()
        }

    /** Extra padding the content needs so it stays inside the glowing frame. */
    val padPx: Int get() = ceil(scene.pad).toInt()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        scene.resize(w, h)
    }

    /** Lets the scene react to a tap at (x, y) in this view's pixels. */
    fun poke(x: Float, y: Float) {
        scene.poke(x, y)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val t = ((SystemClock.uptimeMillis() - start) % 3_600_000L) / 1000f
        scene.draw(canvas, t)
        if (isAttachedToWindow && visibility == VISIBLE) postInvalidateDelayed(FRAME_MS)
    }

    companion object {
        const val FRAME_MS = 33L
    }
}

/** The floating button. Breathing glow + slowly turning gradient; red stop button while running. */
@SuppressLint("ViewConstructor")
class BubbleView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val start = SystemClock.uptimeMillis()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val m = Matrix()
    private val oval = RectF()
    private var shader: Shader? = null
    private var stopShader: Shader? = null

    var theme: Theme = Themes.get(0)
        set(v) {
            field = v
            rebuild()
            invalidate()
        }

    var running = false
        set(v) {
            field = v
            invalidate()
        }

    private fun radius(): Float = min(width, height) / 2f - 7f * d

    private fun rebuild() {
        val r = radius()
        if (r <= 0f) return
        shader = LinearGradient(-r, -r, r, r, theme.bubbleA, theme.bubbleB, Shader.TileMode.CLAMP)
        stopShader = LinearGradient(-r, -r, r, r, hex(0xFFFF6B5F), hex(0xFFB3001B), Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        rebuild()
    }

    override fun onDraw(canvas: Canvas) {
        val r = radius()
        if (r <= 0f) return
        val t = ((SystemClock.uptimeMillis() - start) % 3_600_000L) / 1000f
        canvas.save()
        canvas.translate(width / 2f, height / 2f)
        if (running) {
            ring.strokeWidth = 2f * d
            ring.color = hex(0x99FF3B30)
            canvas.drawCircle(0f, 0f, r + 2.5f * d, ring)
            core.shader = stopShader
            canvas.drawCircle(0f, 0f, r, core)
        } else {
            val breath = 0.5f + 0.5f * sin(t * 2.6f)
            for (i in 3 downTo 1) {
                ring.strokeWidth = i * 1.8f * d
                ring.color = withAlpha(theme.bubbleRing, (0x55 * (0.35f + 0.65f * breath) / i).roundToInt())
                canvas.drawCircle(0f, 0f, r + 2f * d + breath * 1.5f * d, ring)
            }
            m.setRotate((t * 50f) % 360f)
            shader?.setLocalMatrix(m)
            core.shader = shader
            canvas.drawCircle(0f, 0f, r, core)
        }
        gloss.color = 0x33FFFFFF
        oval.set(-r * 0.62f, -r * 0.86f, r * 0.42f, -r * 0.16f)
        canvas.drawOval(oval, gloss)
        val txt = if (running) "■" else theme.bubbleLabel
        label.color = if (running) Color.WHITE else theme.bubbleText
        label.typeface = theme.titleFont
        label.textSize = r * (if (txt.length >= 3) 0.62f else 0.9f)
        canvas.drawText(txt, 0f, label.textSize * 0.35f, label)
        canvas.restore()
        if (!running && isAttachedToWindow) postInvalidateDelayed(50L)
    }
}
