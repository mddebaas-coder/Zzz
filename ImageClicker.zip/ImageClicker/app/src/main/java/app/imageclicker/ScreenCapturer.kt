package app.imageclicker

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Keeps one MediaProjection + VirtualDisplay open.
 *
 * A listener drains the ImageReader and always keeps the NEWEST frame (so we never read a stale queued frame).
 * Frames are only converted to a Bitmap when [grab] is called and the screen actually changed;
 * a static screen produces no new frames, so the last Bitmap is reused.
 */
class ScreenCapturer(private val ctx: Context, resultCode: Int, data: Intent) {

    private val thread = HandlerThread("capture").apply { start() }
    private val handler = Handler(thread.looper)
    private val projection: MediaProjection =
        (ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
            .getMediaProjection(resultCode, data)

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var dpi = 320

    private val frameLock = Any()
    private var held: Image? = null
    private var heldId = 0L
    private var convertedId = -1L
    private var last: Bitmap? = null

    private val mutex = Mutex()
    @Volatile private var released = false

    @Volatile var width = 0
        private set
    @Volatile var height = 0
        private set

    /** Called when the system or user ends screen capture. */
    var onStopped: (() -> Unit)? = null

    fun start() {
        // Required on Android 14+: register a callback before creating the virtual display.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                val already = released
                release()
                if (!already) onStopped?.invoke()
            }
        }, handler)

        val (w, h) = realSize()
        width = w
        height = h
        val r = newReader(w, h)
        reader = r
        display = projection.createVirtualDisplay(
            "imageclicker", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try {
                rd.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                synchronized(frameLock) {
                    held?.close()
                    held = img
                    heldId++
                }
            }
        }, handler)
        return r
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.getRealMetrics(dm)
        dpi = dm.densityDpi
        return dm.widthPixels to dm.heightPixels
    }

    /** Follows screen rotation. */
    private fun ensureSize() {
        val (w, h) = realSize()
        if (w == width && h == height) return
        val nr = newReader(w, h)
        display?.let {
            it.resize(w, h, dpi)
            it.surface = nr.surface
        }
        synchronized(frameLock) {
            held?.close()
            held = null
            heldId = 0
            convertedId = -1
        }
        reader?.close()
        reader = nr
        width = w
        height = h
        last = null
    }

    /** Converts the held frame to a Bitmap if it is newer than the last conversion. Call with [frameLock] held. */
    private fun convertIfNew(): Bitmap? {
        val img = held ?: return null
        if (heldId == convertedId) return null
        return try {
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val padded = Bitmap.createBitmap(rowStride / pixelStride, img.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(plane.buffer)
            convertedId = heldId
            if (padded.width == img.width) {
                padded
            } else {
                Bitmap.createBitmap(padded, 0, 0, img.width, img.height).also { padded.recycle() }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Latest screen contents, or null if capture is not delivering frames. */
    suspend fun grab(timeoutMs: Long = 1500): Bitmap? = mutex.withLock {
        if (released) return@withLock null
        ensureSize()
        val end = SystemClock.elapsedRealtime() + timeoutMs
        var result: Bitmap? = null
        while (result == null) {
            val fresh = synchronized(frameLock) { convertIfNew() }
            if (fresh != null) {
                last = fresh
                result = fresh
            } else if (last != null) {
                result = last
            } else if (SystemClock.elapsedRealtime() > end) {
                break
            } else {
                delay(30)
            }
        }
        result
    }

    fun release() {
        if (released) return
        released = true
        try { display?.release() } catch (_: Exception) {}
        synchronized(frameLock) {
            try { held?.close() } catch (_: Exception) {}
            held = null
        }
        try { reader?.close() } catch (_: Exception) {}
        try { projection.stop() } catch (_: Exception) {}
        thread.quitSafely()
    }
}
