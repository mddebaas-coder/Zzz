package app.imageclicker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * PIXEL ARCADE: an 8-bit cabinet. Everything sits on a coarse pixel grid and moves in steps at
 * 12 fps: buttons drop in like falling blocks and land with a one-step bounce, a blinking ▶ cursor
 * hops to the selected button, pressed buttons sink one pixel. Icons are rendered at low
 * resolution and scaled up without smoothing; labels use a hand-made 5x7 pixel font.
 */
class ArcadeCanvas : StyleCanvas() {
    private val fps = 12f
    private var clock = 0f
    private var frame = 0
    private var px = 3f
    private var cols = 5
    private var cellW = 0f
    private var cellH = 0f
    private var gridTop = 0f
    private var drop = IntArray(0) // per button: pixel rows still to fall (0 = landed)
    private var dropStarted = BooleanArray(0)
    private var land = IntArray(0)
    private var openFrame = 0
    private var cursor = 0f
    private var cursorTarget = 0
    private var hop = 0
    private val icons = HashMap<Icon, Bitmap>()
    private var iconRes = 12
    private var wasOpen = false
    private var stars = Array(30) { IntArray(3) }
    private var lastPicked = 0

    private val p = Paint()
    private val crisp = Paint() // no FILTER flag: nearest-neighbour scaling for chunky pixels
    private val rc = RectF()

    private val n get() = items.size

    private val palette = intArrayOf(
        0xFFFF004D.toInt(), 0xFFFFA300.toInt(), 0xFFFFEC27.toInt(), 0xFF00E436.toInt(), 0xFF29ADFF.toInt(),
        0xFF83769C.toInt(), 0xFFFF77A8.toInt(), 0xFFFFCCAA.toInt(), 0xFF00876D.toInt(), 0xFFAB5236.toInt()
    )
    private val ink = 0xFF1D2B53.toInt()
    private val night = 0xFF0B0F24.toInt()

    init {
        val r = Random(8)
        stars = Array(30) { intArrayOf(r.nextInt(1000), r.nextInt(1000), r.nextInt(3)) }
    }

    override fun onItems(old: List<MenuItem>) {
        if (drop.size != n) {
            drop = IntArray(n)
            dropStarted = BooleanArray(n)
            land = IntArray(n)
        }
        if (old.map { it.icon } != items.map { it.icon }) icons.clear()
        if (w > 0f) onSize()
    }

    override fun onSize() {
        px = max(2f, floor(d * 2.5f))
        cols = if (n > 8) 5 else max(1, n)
        val rows = (n + cols - 1) / cols
        gridTop = snapPx(d * 40f)
        cellW = snapPx((w - px * 8) / cols)
        cellH = snapPx((h - gridTop - px * 4) / max(1, rows))
        iconRes = 12
    }

    private fun snapPx(v: Float): Float = floor(v / px) * px

    private fun iconBitmap(icon: Icon): Bitmap = icons.getOrPut(icon) {
        val b = Bitmap.createBitmap(iconRes, iconRes, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        Icons.draw(cv, icon, iconRes / 2f, iconRes / 2f, iconRes * 1.15f, Color.WHITE)
        // hard threshold so it reads as pixel art (no soft edges)
        val buf = IntArray(iconRes * iconRes)
        b.getPixels(buf, 0, iconRes, 0, 0, iconRes, iconRes)
        for (i in buf.indices) buf[i] = if ((buf[i] ushr 24) > 90) Color.WHITE else 0
        b.setPixels(buf, 0, iconRes, 0, 0, iconRes, iconRes)
        b
    }

    override fun onSelect(old: String?, new: String?) {
        val i = idx(new)
        if (i >= 0) cursorTarget = i
    }

    override fun update(dt: Float, t: Float): Boolean {
        var moving = super.update(dt, t)
        val opening = open.target > 0.5f
        if (opening && !wasOpen) {
            openFrame = frame
            for (i in 0 until n) {
                // start just above the cabinet: fall the height of the button's row plus a little
                drop[i] = if (reduced) 0 else ((gridTop + cellH * (i / cols + 1)) / px).toInt()
                dropStarted[i] = reduced
                land[i] = 0
            }
        }
        wasOpen = opening
        if (reduced) {
            // no falling or hopping: everything is simply where it ends up
            for (i in 0 until n) {
                drop[i] = if (opening) 0 else 80
                dropStarted[i] = true
                land[i] = 0
            }
            cursor = cursorTarget.toFloat()
            hop = 0
        }
        clock += dt
        // everything advances in whole 1/12 s steps
        while (clock >= 1f / fps) {
            clock -= 1f / fps
            frame++
            for (i in 0 until n) {
                if (opening) {
                    // two blocks enter per step, each falls 9 grid rows per step, then bounces once
                    if (!dropStarted[i] && frame - openFrame >= i / 2) dropStarted[i] = true
                    if (dropStarted[i] && drop[i] > 0) {
                        drop[i] = max(0, drop[i] - 9)
                        if (drop[i] == 0) land[i] = 2
                    } else if (land[i] > 0) land[i]--
                } else if (drop[i] < 80) {
                    drop[i] += 6
                }
            }
            val sel = if (pressed >= 0) pressed else cursorTarget
            if (cursor.roundToInt() != sel) {
                cursor += if (sel > cursor) 1f else -1f
                hop = 2
            } else if (hop > 0) hop--
        }
        if ((drop.any { it > 0 } || land.any { it > 0 }) && opening) moving = true
        if (!opening && drop.any { it < 80 }) moving = true
        if (cursor.roundToInt() != cursorTarget || hop > 0) moving = true
        return moving
    }

    override val ambient: Boolean get() = open.value > 0.05f

    override fun draw(c: Canvas, t: Float) {
        if (w <= 0f || n == 0) return
        if (open.value < 0.01f && open.target < 0.5f && drop.all { it >= 80 }) return
        val o = open.value.coerceIn(0f, 1f)
        val blinkOn = reduced || (frame / 6) % 2 == 0

        // cabinet body
        p.color = night
        c.drawRect(0f, 0f, w, h, p)
        // star field drifting one pixel step at a time
        for (s in stars) {
            val sx = snapPx(((s[0] / 1000f) * w + frame * (s[2] + 1) * px * 0.5f) % w)
            val sy = snapPx((s[1] / 1000f) * gridTop)
            p.color = if (s[2] == 2) Color.WHITE else 0xFF5F574F.toInt()
            c.drawRect(sx, sy, sx + px, sy + px, p)
        }
        // chequered pixel border in the accent colour
        val acc = th.promptColor or (0xFF shl 24)
        var x = 0f
        var k = 0
        while (x < w) {
            p.color = if ((k + frame / 3) % 2 == 0) acc else ink
            c.drawRect(x, 0f, x + px * 2, px, p)
            c.drawRect(x, h - px, x + px * 2, h, p)
            x += px * 2
            k++
        }
        // marquee
        val title = if (open.target > 0.5f && o > 0.6f) "SELECT" else "INSERT COIN"
        val tpx = max(px * 0.75f, floor(d * 2f))
        val tw = PixelFont.width(title, tpx)
        if (title == "SELECT" || blinkOn) {
            p.color = ink
            PixelFont.draw(c, title, snapPx((w - tw) / 2f) + tpx, snapPx(d * 12f) + tpx, tpx, p)
            p.color = 0xFFFFEC27.toInt()
            PixelFont.draw(c, title, snapPx((w - tw) / 2f), snapPx(d * 12f), tpx, p)
        }

        // buttons
        val sel = idx(selected)
        for (i in 0 until n) {
            if (!dropStarted.getOrElse(i) { true } && open.target > 0.5f) continue
            val col = i % cols
            val row = i / cols
            val bx = snapPx(px * 4 + col * cellW)
            val by = snapPx(gridTop + row * cellH) - drop.getOrElse(i) { 0 } * px - (if (land.getOrElse(i) { 0 } == 1) px * 2 else 0f)
            if (by > h) continue
            drawButton(c, i, bx, by, i == pressed, i == sel)
        }

        // hopping cursor
        val ci = cursor.roundToInt().coerceIn(0, n - 1)
        if (o > 0.6f && blinkOn) {
            val col = ci % cols
            val row = ci / cols
            val cx = snapPx(px * 4 + col * cellW + cellW / 2f)
            val cy = snapPx(gridTop + row * cellH) - px * 2 - (if (hop > 0) px * 2 else 0f)
            p.color = 0xFFFFEC27.toInt()
            // a small pixel arrow pointing down
            for (r in 0 until 3) c.drawRect(cx - px * (2 - r), cy + r * px, cx + px * (3 - r), cy + (r + 1) * px, p)
        }
    }

    private fun drawButton(c: Canvas, i: Int, bx: Float, by: Float, down: Boolean, selected: Boolean) {
        val item = items[i]
        val bw = cellW - px * 2
        val bh = min(cellH - px * 9, bw)
        val sink = if (down) px else 0f
        val face = palette[i % palette.size]
        // shadow (stays put) + face (sinks one pixel when pressed): stepped, chunky corners
        p.color = Color.BLACK
        chunky(c, bx + px, by + px * 2, bw, bh)
        p.color = if (selected) Color.WHITE else ink
        chunky(c, bx - px, by - px + sink, bw + px * 2, bh + px * 2)
        p.color = face
        chunky(c, bx, by + sink, bw, bh)
        // highlight bevel
        p.color = withAlpha(Color.WHITE, 0x80)
        c.drawRect(bx + px * 2, by + sink + px, bx + bw - px * 2, by + sink + px * 2, p)
        // icon at low resolution, scaled up with hard pixels
        val ib = iconBitmap(item.icon)
        val scale = floor(min(bw, bh) * 0.62f / iconRes).coerceAtLeast(1f)
        val iw = iconRes * scale
        rc.set(snapPx(bx + (bw - iw) / 2f), snapPx(by + sink + (bh - iw) / 2f), 0f, 0f)
        rc.right = rc.left + iw
        rc.bottom = rc.top + iw
        // tint: draw the white mask in the ink colour by drawing twice offset (outline) then white
        crisp.alpha = 255
        c.drawBitmap(ib, null, rc, crisp)
        if (item.toggle && !item.on) {
            p.color = withAlpha(ink, 0xA0)
            c.drawRect(rc.left, rc.top, rc.right, rc.bottom, p)
        }
        // label in the pixel font
        val lp = max(1f, floor(d * 1.2f))
        val txt = item.short.uppercase().take(((bw + lp) / (lp * 6)).toInt().coerceAtLeast(1))
        val tw = PixelFont.width(txt, lp)
        p.color = if (selected) 0xFFFFEC27.toInt() else 0xFFC2C3C7.toInt()
        PixelFont.draw(c, txt, snapPx(bx + (bw - tw) / 2f), snapPx(by + bh + px * 3), lp, p)
    }

    /** Rectangle with notched (stepped) corners, the classic 8-bit button shape. */
    private fun chunky(c: Canvas, x: Float, y: Float, w: Float, h: Float) {
        c.drawRect(x + px, y, x + w - px, y + h, p)
        c.drawRect(x, y + px, x + w, y + h - px, p)
    }

    override fun hit(x: Float, y: Float): Int {
        if (open.value < 0.5f || y < gridTop - px * 4) return -1
        val col = ((x - px * 4) / cellW).toInt()
        val row = ((y - gridTop) / cellH).toInt()
        if (col !in 0 until cols || row < 0) return -1
        val i = row * cols + col
        return if (i in 0 until n) i else -1
    }

    override fun itemBounds(i: Int, out: RectF): Boolean {
        if (i !in 0 until n) return false
        val bx = px * 4 + (i % cols) * cellW
        val by = gridTop + (i / cols) * cellH
        out.set(bx, by, bx + cellW, by + cellH)
        return true
    }

    override fun activate(i: Int) {
        lastPicked = i
        cursorTarget = i
        super.activate(i)
    }
}
