package app.imageclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen frozen screenshot. Drag a box, press OK. [done] gets the box in bitmap pixels or null if cancelled.
 */
@SuppressLint("ViewConstructor")
class RegionSelectorView(
    ctx: Context,
    private val shot: Bitmap,
    private val done: (Rect?) -> Unit
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint().apply {
        color = 0xFF00E5FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        textAlign = Paint.Align.CENTER
    }
    private val okPaint = Paint().apply { color = 0xFF238636.toInt() }
    private val cancelPaint = Paint().apply { color = 0xFF6E7681.toInt() }

    private val a = PointF()
    private val b = PointF()
    private var has = false
    private var dragging = false
    private var downOn = 0 // 0 none, 1 ok, 2 cancel

    private val dst = Rect()
    private val okR = RectF()
    private val cancelR = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val bw = 130f * d
        val bh = 48f * d
        val top = h - bh - 36f * d
        cancelR.set(w / 2f - bw - 12f * d, top, w / 2f - 12f * d, top + bh)
        okR.set(w / 2f + 12f * d, top, w / 2f + bw + 12f * d, top + bh)
    }

    private fun sel(): RectF =
        RectF(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x), max(a.y, b.y))

    override fun onDraw(c: Canvas) {
        dst.set(0, 0, width, height)
        c.drawBitmap(shot, null, dst, null)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (has) {
            val r = sel()
            c.save()
            c.clipRect(r)
            c.drawBitmap(shot, null, dst, null)
            c.restore()
            c.drawRect(r, border)
        }
        c.drawRect(cancelR, cancelPaint)
        c.drawRect(okR, okPaint)
        val ty = cancelR.centerY() + text.textSize / 3f
        c.drawText("Cancel", cancelR.centerX(), ty, text)
        c.drawText("Save", okR.centerX(), ty, text)
        c.drawText("Drag a box around the button/icon to match", width / 2f, 64f * d, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downOn = when {
                    okR.contains(e.x, e.y) -> 1
                    cancelR.contains(e.x, e.y) -> 2
                    else -> 0
                }
                if (downOn == 0) {
                    a.set(e.x, e.y)
                    b.set(e.x, e.y)
                    has = true
                    dragging = true
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                b.set(e.x, e.y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                when {
                    downOn == 2 && cancelR.contains(e.x, e.y) -> done(null)
                    downOn == 1 && okR.contains(e.x, e.y) -> confirm()
                    else -> b.set(e.x, e.y).also { invalidate() }
                }
                downOn = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                downOn = 0
            }
        }
        return true
    }

    private fun confirm() {
        if (!has) return
        val r = sel()
        val sx = shot.width.toFloat() / width
        val sy = shot.height.toFloat() / height
        val out = Rect(
            max(0, floor(r.left * sx).toInt()),
            max(0, floor(r.top * sy).toInt()),
            min(shot.width, ceil(r.right * sx).toInt()),
            min(shot.height, ceil(r.bottom * sy).toInt())
        )
        if (out.width() < 8 || out.height() < 8) return // too small, keep selecting
        done(out)
    }
}

/** Transparent, touch-through overlay that outlines a rectangle (screen pixels). */
@SuppressLint("ViewConstructor")
class HighlightView(ctx: Context, private val r: Rect) : View(ctx) {
    private val p = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 4f * ctx.resources.displayMetrics.density
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(r, p)
    }
}
