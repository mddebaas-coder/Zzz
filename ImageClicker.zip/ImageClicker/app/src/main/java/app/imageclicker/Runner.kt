package app.imageclicker

import android.graphics.Rect
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Why the last run ended. */
enum class RunEnd { FINISHED, STOPPED, NOT_FOUND, FAILED }

/** Lines starting with this are errors: shown in red and saved to the error log. */
const val ERR = "✗ "

/** Executes a list of [Step]s, optionally looping. */
class Runner(
    private val scope: CoroutineScope,
    private val capturer: () -> ScreenCapturer?,
    private val store: Store,
    private val settings: ClickerSettings,
    private val out: (String) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val mark: (Rect) -> Unit
) {
    private var job: Job? = null

    val running: Boolean get() = job?.isActive == true

    // ---- facts about the current / last run (read by the overlay) ----
    @Volatile var lastEnd = RunEnd.FINISHED
        private set
    @Volatile var lastFail = ""
        private set
    /** 0-based index of the step that stopped the run, or -1. */
    @Volatile var failIndex = -1
        private set
    @Volatile var loopsDone = 0
        private set
    /** Wall-clock start of the current / last run (ms). */
    @Volatile var startedAt = 0L
        private set
    @Volatile var stepCount = 0
        private set
    /** Loops asked for by the current / last run (-1 = forever). */
    @Volatile var loopsWanted = 0
        private set
    /** Best match score of the most recent attempt of each image step (0-based index). */
    val bestScores = ConcurrentHashMap<Int, Double>()

    private var notFound = false

    /** [loops] < 0 means forever. */
    fun start(steps: List<Step>, loops: Int) {
        if (running) {
            out("already running (tap ■ to stop)")
            return
        }
        if (steps.isEmpty()) {
            out("no steps yet. try: add tap <template>")
            return
        }
        if (ClickerAccessibilityService.instance == null) {
            out("${ERR}accessibility service is off. enable 'Image Clicker' in Accessibility settings")
            return
        }
        lastEnd = RunEnd.FINISHED
        lastFail = ""
        failIndex = -1
        loopsDone = 0
        notFound = false
        stepCount = steps.size
        loopsWanted = loops
        startedAt = System.currentTimeMillis()
        bestScores.clear()
        onState(true)
        job = scope.launch(Dispatchers.Default) {
            try {
                execute(steps, loops)
            } catch (e: CancellationException) {
                lastEnd = RunEnd.STOPPED
                out("stopped")
            } catch (e: Exception) {
                lastEnd = RunEnd.FAILED
                lastFail = "error: ${e.message}"
                out(ERR + lastFail)
            } finally {
                onState(false)
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    /** Logs [msg] as an error, remembers it as the reason, returns false. */
    private fun fail(msg: String): Boolean {
        lastFail = msg
        out(ERR + msg)
        return false
    }

    private suspend fun execute(steps: List<Step>, loops: Int) {
        var loop = 0
        while (loops < 0 || loop < loops) {
            loop++
            val t0 = SystemClock.elapsedRealtime()
            for ((i, st) in steps.withIndex()) {
                currentCoroutineContext().ensureActive()
                if (!runStep(loop, loops, i, steps.size, st)) {
                    failIndex = i
                    lastEnd = if (notFound) RunEnd.NOT_FOUND else RunEnd.FAILED
                    out("${ERR}aborted at step ${i + 1} after ${loopsDone} full loop(s)")
                    return
                }
            }
            loopsDone = loop
            out("loop $loop done in ${secs(SystemClock.elapsedRealtime() - t0)}")
            if (loops < 0 || loop < loops) delay(settings.loopDelayMs)
        }
        out("finished")
    }

    private fun tag(loop: Int, loops: Int, n: Int, total: Int): String {
        val l = if (loops < 0) "$loop" else "$loop/$loops"
        return "[$l] #$n/$total"
    }

    private suspend fun runStep(loop: Int, loops: Int, idx: Int, total: Int, st: Step): Boolean {
        val tag = tag(loop, loops, idx + 1, total)
        val svc = ClickerAccessibilityService.instance ?: return fail("accessibility service disconnected")
        when (st.op) {
            Op.WAIT -> {
                out("$tag wait ${st.ms}ms")
                delay(st.ms)
            }
            Op.BACK -> {
                out("$tag back")
                svc.back()
                delay(st.after)
            }
            Op.HOME -> {
                out("$tag home")
                svc.home()
                delay(st.after)
            }
            Op.TAPXY -> {
                out("$tag tap (${st.x},${st.y})")
                if (!svc.tap(st.x.toFloat(), st.y.toFloat())) out("${ERR}#${idx + 1} gesture was cancelled")
                if (settings.marks) mark(Rect(st.x - 20, st.y - 20, st.x + 20, st.y + 20))
                delay(st.after)
            }
            Op.HOLDXY -> {
                if (!doHold(svc, tag, idx, "(${st.x},${st.y})", st.x, st.y, st.ms)) return false
                delay(st.after)
            }
            Op.SWIPE -> {
                out("$tag swipe (${st.x},${st.y})->(${st.x2},${st.y2}) ${st.ms}ms")
                val ok = svc.swipe(st.x.toFloat(), st.y.toFloat(), st.x2.toFloat(), st.y2.toFloat(), st.ms)
                if (!ok) out("${ERR}#${idx + 1} gesture was cancelled")
                delay(st.after)
            }
            Op.TAP, Op.WAITIMG, Op.GONEIMG, Op.HOLD -> return imageStep(tag, idx, st)
        }
        return true
    }

    private suspend fun imageStep(tag: String, idx: Int, st: Step): Boolean {
        val tpl = store.tpl(st.tpl) ?: return fail("#${idx + 1} missing image '${st.tpl}' (snap it first)")
        val cap = capturer() ?: return fail("screen capture is not running")
        val thr = st.thr ?: settings.thr
        val roi = st.roi?.let { Rect(it[0], it[1], it[0] + it[2], it[1] + it[3]) }
        // timeout=0 (the default) means keep looking forever
        val forever = st.timeout <= 0
        val begun = SystemClock.elapsedRealtime()
        val deadline = if (forever) Long.MAX_VALUE else begun + st.timeout
        var announced = false
        var best = 0.0

        while (true) {
            currentCoroutineContext().ensureActive()
            val frame = cap.grab()
            if (frame != null) {
                val m = TemplateMatcher.find(frame, tpl, roi)
                if (m != null) {
                    if (m.score > best) {
                        best = m.score
                        bestScores[idx] = best
                    }
                    when (st.op) {
                        Op.GONEIMG -> {
                            if (m.score < thr) {
                                out("$tag ${st.tpl} gone (${fmt(m.score)})")
                                delay(st.after)
                                return true
                            }
                        }
                        Op.WAITIMG -> {
                            if (m.score >= thr) {
                                out("$tag ${st.tpl} visible (${fmt(m.score)})")
                                delay(st.after)
                                return true
                            }
                        }
                        else -> {
                            if (m.score >= thr) {
                                val tx = m.cx + st.dx
                                val ty = m.cy + st.dy
                                if (settings.marks) mark(Rect(m.left, m.top, m.left + m.w, m.top + m.h))
                                val svc = ClickerAccessibilityService.instance
                                    ?: return fail("accessibility service disconnected")
                                if (st.op == Op.HOLD) {
                                    val what = "${st.tpl} ${fmt(m.score)} @ ($tx,$ty)"
                                    if (!doHold(svc, tag, idx, what, tx, ty, st.ms)) return false
                                } else {
                                    out("$tag tap ${st.tpl} ${fmt(m.score)} @ ($tx,$ty)")
                                    if (!svc.tap(tx.toFloat(), ty.toFloat())) out("${ERR}#${idx + 1} gesture was cancelled")
                                }
                                delay(st.after)
                                return true
                            }
                        }
                    }
                } else if (st.op == Op.GONEIMG) {
                    return true
                }
            }
            val now = SystemClock.elapsedRealtime()
            if (!forever && now >= deadline) break
            if (!announced && now - begun > 5000) {
                announced = true
                out("$tag still looking for ${st.tpl} (best so far ${fmt(best)}, thr ${fmt(thr)})")
            }
            delay(settings.pollMs)
        }

        bestScores[idx] = best
        return if (st.skip) {
            out("$tag ${st.tpl} not found in ${st.timeout}ms (best ${fmt(best)}), skipped")
            true
        } else {
            notFound = true
            fail("#${idx + 1} ${st.tpl} not found in ${st.timeout}ms (best ${fmt(best)} < thr ${fmt(thr)})")
        }
    }

    /** Long press. ms <= 0 = until the run is stopped (tap ■). */
    private suspend fun doHold(
        svc: ClickerAccessibilityService, tag: String, idx: Int, what: String, x: Int, y: Int, ms: Long
    ): Boolean {
        if (ms <= 0) {
            out("$tag holding $what ... tap ■ to release")
        } else {
            out("$tag holding $what for ${ms}ms")
        }
        if (settings.marks) mark(Rect(x - 20, y - 20, x + 20, y + 20))
        val ok = svc.hold(x.toFloat(), y.toFloat(), ms)
        if (!ok) return fail("#${idx + 1} hold ended early (the screen was touched, or Android blocked it)")
        out("$tag released")
        return true
    }

    private fun fmt(d: Double): String = String.format(Locale.US, "%.2f", d)

    companion object {
        fun secs(ms: Long): String = String.format(Locale.US, "%.1fs", ms / 1000.0)

        /** 45s, 12m 03s, 1h 02m */
        fun dur(ms: Long): String {
            val s = (ms / 1000).coerceAtLeast(0)
            return when {
                s < 60 -> "${s}s"
                s < 3600 -> String.format(Locale.US, "%dm %02ds", s / 60, s % 60)
                else -> String.format(Locale.US, "%dh %02dm", s / 3600, (s % 3600) / 60)
            }
        }
    }
}
