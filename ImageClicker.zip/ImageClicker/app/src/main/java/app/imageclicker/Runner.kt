package app.imageclicker

import android.graphics.Rect
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.util.Locale

/** Executes a list of [Step]s, optionally looping. */
class Runner(
    private val scope: CoroutineScope,
    private val capturer: () -> ScreenCapturer?,
    private val store: Store,
    private val settings: ClickerSettings,
    private val out: (String) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val mark: (Rect) -> Unit
) {
    private var job: Job? = null

    val running: Boolean get() = job?.isActive == true

    /** [loops] < 0 means forever. */
    fun start(steps: List<Step>, loops: Int) {
        if (running) {
            out("already running (type: stop)")
            return
        }
        if (steps.isEmpty()) {
            out("no steps yet. try: add tap <template>")
            return
        }
        if (ClickerAccessibilityService.instance == null) {
            out("accessibility service is off. enable 'Image Clicker' in Accessibility settings")
            return
        }
        job = scope.launch(Dispatchers.Default) {
            onState(true)
            try {
                execute(steps, loops)
            } catch (e: CancellationException) {
                out("stopped")
            } catch (e: Exception) {
                out("error: ${e.message}")
            } finally {
                onState(false)
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    private suspend fun execute(steps: List<Step>, loops: Int) {
        var loop = 0
        while (loops < 0 || loop < loops) {
            loop++
            for ((i, st) in steps.withIndex()) {
                currentCoroutineContext().ensureActive()
                if (!runStep(loop, loops, i + 1, steps.size, st)) {
                    out("aborted at step ${i + 1}")
                    return
                }
            }
            out("loop $loop done")
            if (loops < 0 || loop < loops) delay(settings.loopDelayMs)
        }
        out("finished")
    }

    private fun tag(loop: Int, loops: Int, n: Int, total: Int): String {
        val l = if (loops < 0) "$loop" else "$loop/$loops"
        return "[$l] #$n/$total"
    }

    private suspend fun runStep(loop: Int, loops: Int, n: Int, total: Int, st: Step): Boolean {
        val tag = tag(loop, loops, n, total)
        val svc = ClickerAccessibilityService.instance
        if (svc == null) {
            out("accessibility service disconnected")
            return false
        }
        when (st.op) {
            Op.WAIT -> {
                out("$tag wait ${st.ms}ms")
                delay(st.ms)
            }
            Op.BACK -> {
                out("$tag back")
                svc.back()
                delay(st.after)
            }
            Op.HOME -> {
                out("$tag home")
                svc.home()
                delay(st.after)
            }
            Op.TAPXY -> {
                out("$tag tap (${st.x},${st.y})")
                if (!svc.tap(st.x.toFloat(), st.y.toFloat())) out("   gesture was cancelled")
                if (settings.marks) mark(Rect(st.x - 20, st.y - 20, st.x + 20, st.y + 20))
                delay(st.after)
            }
            Op.SWIPE -> {
                out("$tag swipe (${st.x},${st.y})->(${st.x2},${st.y2}) ${st.ms}ms")
                val ok = svc.swipe(st.x.toFloat(), st.y.toFloat(), st.x2.toFloat(), st.y2.toFloat(), st.ms)
                if (!ok) out("   gesture was cancelled")
                delay(st.after)
            }
            Op.TAP, Op.WAITIMG, Op.GONEIMG -> return imageStep(tag, st)
        }
        return true
    }

    private suspend fun imageStep(tag: String, st: Step): Boolean {
        val tpl = store.tpl(st.tpl)
        if (tpl == null) {
            out("$tag missing template '${st.tpl}'")
            return false
        }
        val cap = capturer()
        if (cap == null) {
            out("$tag screen capture is not running")
            return false
        }
        val thr = st.thr ?: settings.thr
        val roi = st.roi?.let { Rect(it[0], it[1], it[0] + it[2], it[1] + it[3]) }
        val deadline = SystemClock.elapsedRealtime() + st.timeout
        var best = 0.0

        while (true) {
            currentCoroutineContext().ensureActive()
            val frame = cap.grab()
            if (frame != null) {
                val m = TemplateMatcher.find(frame, tpl, roi)
                if (m != null) {
                    if (m.score > best) best = m.score
                    when (st.op) {
                        Op.GONEIMG -> {
                            if (m.score < thr) {
                                out("$tag ${st.tpl} gone (${fmt(m.score)})")
                                delay(st.after)
                                return true
                            }
                        }
                        Op.WAITIMG -> {
                            if (m.score >= thr) {
                                out("$tag ${st.tpl} visible (${fmt(m.score)})")
                                delay(st.after)
                                return true
                            }
                        }
                        else -> {
                            if (m.score >= thr) {
                                val tx = m.cx + st.dx
                                val ty = m.cy + st.dy
                                out("$tag tap ${st.tpl} ${fmt(m.score)} @ ($tx,$ty)")
                                if (settings.marks) mark(Rect(m.left, m.top, m.left + m.w, m.top + m.h))
                                val svc = ClickerAccessibilityService.instance
                                if (svc == null) {
                                    out("accessibility service disconnected")
                                    return false
                                }
                                if (!svc.tap(tx.toFloat(), ty.toFloat())) out("   gesture was cancelled")
                                delay(st.after)
                                return true
                            }
                        }
                    }
                } else if (st.op == Op.GONEIMG) {
                    return true
                }
            }
            if (SystemClock.elapsedRealtime() >= deadline) break
            delay(settings.pollMs)
        }

        return if (st.skip) {
            out("$tag ${st.tpl} not found in ${st.timeout}ms (best ${fmt(best)}), skipped")
            true
        } else {
            out("$tag ${st.tpl} not found in ${st.timeout}ms (best ${fmt(best)} < thr ${fmt(thr)})")
            false
        }
    }

    private fun fmt(d: Double): String = String.format(Locale.US, "%.2f", d)
}
