package app.imageclicker

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/** Line icons drawn in code, so every theme can colour them. */
enum class Icon { THEME, HOLD, MENU, PLAY, LOOP, STOP, SNAP, LIST, FOLDER, INFO, CLEAR, HIDE, HELP, EXIT, SEND, UP }

object Icons {
    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val oval = RectF()

    /** Draws [icon] centred on (cx, cy) inside an s x s box. Main thread only (shared paints). */
    fun draw(cv: Canvas, icon: Icon, cx: Float, cy: Float, s: Float, color: Int) {
        st.color = color
        fill.color = color
        st.strokeWidth = s * 0.085f
        cv.save()
        cv.translate(cx, cy)
        when (icon) {
            Icon.THEME -> {
                cv.drawCircle(0f, 0f, 0.36f * s, st)
                oval.set(-0.36f * s, -0.36f * s, 0.36f * s, 0.36f * s)
                cv.drawArc(oval, 90f, 180f, true, fill)
            }
            Icon.HOLD -> {
                cv.drawCircle(0f, 0f, 0.11f * s, fill)
                cv.drawCircle(0f, 0f, 0.26f * s, st)
                st.color = withAlpha(color, (color ushr 24) / 2)
                cv.drawCircle(0f, 0f, 0.41f * s, st)
            }
            Icon.MENU -> for (i in -1..1) cv.drawLine(-0.32f * s, i * 0.22f * s, 0.32f * s, i * 0.22f * s, st)
            Icon.PLAY -> {
                path.reset()
                path.moveTo(-0.17f * s, -0.28f * s)
                path.lineTo(0.29f * s, 0f)
                path.lineTo(-0.17f * s, 0.28f * s)
                path.close()
                cv.drawPath(path, fill)
                cv.drawPath(path, st)
            }
            Icon.LOOP -> {
                path.reset()
                val a = 0.44f * s
                for (k in 0..48) {
                    val t = k / 48f * 6.2832f
                    val den = 1f + sin(t) * sin(t)
                    val x = a * cos(t) / den
                    val y = a * sin(t) * cos(t) / den
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                cv.drawPath(path, st)
            }
            Icon.STOP -> {
                oval.set(-0.24f * s, -0.24f * s, 0.24f * s, 0.24f * s)
                cv.drawRoundRect(oval, 0.06f * s, 0.06f * s, fill)
            }
            Icon.SNAP -> {
                val e = 0.34f * s
                val l = 0.15f * s
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    cv.drawLine(sx * e, sy * e, sx * (e - l), sy * e, st)
                    cv.drawLine(sx * e, sy * e, sx * e, sy * (e - l), st)
                }
                cv.drawCircle(0f, 0f, 0.08f * s, fill)
            }
            Icon.LIST -> for (i in -1..1) {
                cv.drawCircle(-0.27f * s, i * 0.22f * s, 0.05f * s, fill)
                cv.drawLine(-0.12f * s, i * 0.22f * s, 0.32f * s, i * 0.22f * s, st)
            }
            Icon.FOLDER -> {
                path.reset()
                path.moveTo(-0.34f * s, 0.26f * s)
                path.lineTo(-0.34f * s, -0.24f * s)
                path.lineTo(-0.1f * s, -0.24f * s)
                path.lineTo(0f, -0.14f * s)
                path.lineTo(0.34f * s, -0.14f * s)
                path.lineTo(0.34f * s, 0.26f * s)
                path.close()
                cv.drawPath(path, st)
            }
            Icon.INFO -> {
                cv.drawCircle(0f, 0f, 0.38f * s, st)
                cv.drawCircle(0f, -0.17f * s, 0.05f * s, fill)
                cv.drawLine(0f, -0.03f * s, 0f, 0.2f * s, st)
            }
            Icon.CLEAR -> {
                cv.drawLine(-0.3f * s, -0.22f * s, 0.3f * s, -0.22f * s, st)
                cv.drawLine(-0.08f * s, -0.32f * s, 0.08f * s, -0.32f * s, st)
                path.reset()
                path.moveTo(-0.21f * s, -0.22f * s)
                path.lineTo(-0.17f * s, 0.34f * s)
                path.lineTo(0.17f * s, 0.34f * s)
                path.lineTo(0.21f * s, -0.22f * s)
                cv.drawPath(path, st)
                cv.drawLine(-0.06f * s, -0.08f * s, -0.06f * s, 0.2f * s, st)
                cv.drawLine(0.06f * s, -0.08f * s, 0.06f * s, 0.2f * s, st)
            }
            Icon.HIDE -> {
                path.reset()
                path.moveTo(-0.26f * s, -0.12f * s)
                path.lineTo(0f, 0.12f * s)
                path.lineTo(0.26f * s, -0.12f * s)
                cv.drawPath(path, st)
                cv.drawLine(-0.28f * s, 0.3f * s, 0.28f * s, 0.3f * s, st)
            }
            Icon.HELP -> {
                cv.drawCircle(0f, 0f, 0.38f * s, st)
                text.color = color
                text.isFakeBoldText = true
                text.textSize = 0.52f * s
                cv.drawText("?", 0f, 0.18f * s, text)
            }
            Icon.EXIT -> {
                oval.set(-0.3f * s, -0.3f * s, 0.3f * s, 0.3f * s)
                cv.drawArc(oval, -55f, 290f, false, st)
                cv.drawLine(0f, -0.4f * s, 0f, -0.04f * s, st)
            }
            Icon.SEND -> {
                cv.drawLine(-0.3f * s, 0f, 0.28f * s, 0f, st)
                path.reset()
                path.moveTo(0.06f * s, -0.22f * s)
                path.lineTo(0.3f * s, 0f)
                path.lineTo(0.06f * s, 0.22f * s)
                cv.drawPath(path, st)
            }
            Icon.UP -> {
                path.reset()
                path.moveTo(-0.24f * s, 0.12f * s)
                path.lineTo(0f, -0.13f * s)
                path.lineTo(0.24f * s, 0.12f * s)
                cv.drawPath(path, st)
            }
        }
        cv.restore()
    }
}
