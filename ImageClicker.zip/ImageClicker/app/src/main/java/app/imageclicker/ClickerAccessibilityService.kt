package app.imageclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Only used to inject taps/swipes and back/home. It never reads screen content. */
class ClickerAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    suspend fun tap(x: Float, y: Float, durationMs: Long = 60): Boolean = swipe(x, y, x, y, durationMs)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            main.post {
                val path = Path().apply {
                    moveTo(x1, y1)
                    if (x1 != x2 || y1 != y2) lineTo(x2, y2)
                }
                val stroke = GestureDescription.StrokeDescription(path, 0, maxOf(1L, durationMs))
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(g: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                }, null)
                if (!accepted && cont.isActive) cont.resume(false)
            }
        }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
