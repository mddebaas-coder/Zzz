package app.imageclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Only used to inject taps/swipes/holds and back/home. It never reads screen content. */
class ClickerAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerAccessibilityService? = null

        /** Length of one piece of a long hold. Pieces are chained so the finger never lifts. */
        private const val HOLD_PIECE_MS = 1000L
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    suspend fun tap(x: Float, y: Float, durationMs: Long = 60): Boolean = swipe(x, y, x, y, durationMs)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            main.post {
                val path = Path().apply {
                    moveTo(x1, y1)
                    if (x1 != x2 || y1 != y2) lineTo(x2, y2)
                }
                val stroke = GestureDescription.StrokeDescription(path, 0, maxOf(1L, durationMs))
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(g: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                }, null)
                if (!accepted && cont.isActive) cont.resume(false)
            }
        }

    /** Dispatches one stroke; the result completes true when it finished, false if cancelled/rejected. */
    private fun send(stroke: GestureDescription.StrokeDescription): CompletableDeferred<Boolean> {
        val done = CompletableDeferred<Boolean>()
        main.post {
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val accepted = try {
                dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        done.complete(true)
                    }

                    override fun onCancelled(g: GestureDescription?) {
                        done.complete(false)
                    }
                }, null)
            } catch (e: Exception) {
                false
            }
            if (!accepted) done.complete(false)
        }
        return done
    }

    /**
     * Keeps a finger pressed at (x, y).
     *
     * [durationMs] <= 0 holds until the calling coroutine is cancelled (the run is stopped).
     * The finger is always lifted afterwards, also when cancelled.
     * Returns false if Android cancelled the hold (for example because the user touched the screen).
     *
     * Android limits one gesture to about a minute, so the hold is made of 1 s pieces chained with
     * continueStroke(willContinue = true). Each piece moves 1 px back and forth because a continued
     * stroke has to start where the previous one ended; 1 px is far below the touch slop, so apps
     * still see a single stationary long press.
     */
    suspend fun hold(x: Float, y: Float, durationMs: Long): Boolean {
        val forever = durationMs <= 0
        val start = SystemClock.elapsedRealtime()
        var forward = true
        fun piecePath(fwd: Boolean) = Path().apply {
            if (fwd) {
                moveTo(x, y); lineTo(x + 1f, y)
            } else {
                moveTo(x + 1f, y); lineTo(x, y)
            }
        }

        var open: GestureDescription.StrokeDescription? = null // last piece sent that keeps the finger down
        var pending: CompletableDeferred<Boolean>? = null
        try {
            while (true) {
                currentCoroutineContext().ensureActive()
                val remaining = if (forever) Long.MAX_VALUE else durationMs - (SystemClock.elapsedRealtime() - start)
                val last = !forever && remaining <= HOLD_PIECE_MS
                val len = if (forever) HOLD_PIECE_MS else remaining.coerceIn(1L, HOLD_PIECE_MS)
                val path = piecePath(forward)
                val prev = open
                val piece = prev?.continueStroke(path, 0, len, !last)
                    ?: GestureDescription.StrokeDescription(path, 0, len, !last)
                forward = !forward // the next piece starts where this one ends

                val d = send(piece)
                pending = d
                open = if (last) null else piece
                val ok = d.await()
                pending = null
                if (!ok) {
                    open = null // Android cancelled it, so the finger is already up
                    return false
                }
                if (last) return true
            }
        } finally {
            withContext(NonCancellable) {
                // Let an in-flight piece finish, then lift the finger with a 1 ms closing piece.
                val p = pending
                if (p != null) {
                    val r = withTimeoutOrNull(HOLD_PIECE_MS + 1000) { p.await() }
                    if (r != true) open = null
                }
                val o = open
                if (o != null) {
                    val lift = send(o.continueStroke(piecePath(forward), 0, 1, false))
                    withTimeoutOrNull(1000) { lift.await() }
                }
            }
        }
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
