package app.imageclicker

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.min

/**
 * Foreground service that owns: screen capture, the floating bubble, the terminal panel,
 * the sequence runner. UI is built in code so the project needs no layout resources.
 */
class OverlayService : Service(), Host {

    companion object {
        const val ACTION_START = "app.imageclicker.START"
        const val ACTION_STOP_RUN = "app.imageclicker.STOP_RUN"
        const val ACTION_EXIT = "app.imageclicker.EXIT"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "imageclicker"
        private const val NOTIF_ID = 1

        @Volatile
        var alive = false
            private set
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var wm: WindowManager
    private lateinit var imm: InputMethodManager

    override val store: Store by lazy { Store(applicationContext) }
    override val settings: ClickerSettings by lazy { ClickerSettings(applicationContext) }
    override val runner: Runner by lazy {
        Runner(scope, { cap }, store, settings, { s -> out(s) }, { r -> onRunState(r) }, { r -> mark(r) })
    }

    @Volatile private var cap: ScreenCapturer? = null
    private var term: Terminal? = null

    // views
    private lateinit var bubble: TextView
    private lateinit var bubbleBg: GradientDrawable
    private lateinit var panel: LinearLayout
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    private var bubbleAdded = false
    private var panelAdded = false
    private var uiVisible = true
    private var panelWanted = true
    private var running = false
    private var finished = false

    private val logLines = ArrayDeque<String>()
    private val history = ArrayList<String>()
    private var histPos = 0

    // ------------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP_RUN -> if (alive) runner.stop()
            ACTION_EXIT -> shutdown()
            else -> if (!alive) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (alive) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        // Must be foreground (type mediaProjection) before the projection token is used.
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return
        }
        try {
            val c = ScreenCapturer(this, code, data)
            c.onStopped = { main.post { out("screen capture was stopped by the system"); shutdown() } }
            c.start()
            cap = c
        } catch (e: Exception) {
            finished = true
            android.widget.Toast.makeText(
                this, "Image Clicker: screen capture failed to start (${e.message})", android.widget.Toast.LENGTH_LONG
            ).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        alive = true
        buildUi()
        val t = Terminal(this, scope)
        term = t
        t.banner()
        syncWindows()
    }

    private fun shutdown() {
        if (finished) return
        finished = true
        alive = false
        try { runner.stop() } catch (_: Exception) {}
        main.post {
            try { removeWindows() } catch (_: Exception) {}
        }
        cap?.let { c -> c.onStopped = null; c.release() }
        cap = null
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!finished) {
            finished = true
            alive = false
            cap?.let { c -> c.onStopped = null; c.release() }
            cap = null
            scope.cancel()
            try { removeWindows() } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!alive) return
        layoutPanelSize()
        if (panelAdded) try { wm.updateViewLayout(panel, panelLp) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Image Clicker", NotificationManager.IMPORTANCE_LOW))
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Image Clicker")
            .setContentText("Overlay terminal is active")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop run", pi(ACTION_STOP_RUN, 1))
            .addAction(android.R.drawable.ic_delete, "Exit", pi(ACTION_EXIT, 2))
            .build()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun layoutPanelSize() {
        val dm = resources.displayMetrics
        panelLp.width = min(dm.widthPixels - dp(16), dp(460))
        panelLp.height = min((dm.heightPixels * 0.55).toInt(), dp(340))
    }

    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        // ---- bubble ----
        bubbleBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xCC238636.toInt())
            setStroke(dp(1), 0x66FFFFFF)
        }
        bubble = TextView(this).apply {
            text = ">_"
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            background = bubbleBg
        }
        bubbleLp = WindowManager.LayoutParams(
            dp(44), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(4)
            y = dp(220)
        }
        makeDraggable(bubble, bubbleLp, bubble) {
            if (running) {
                runner.stop()
            } else {
                panelWanted = !panelWanted
                syncWindows()
            }
        }

        // ---- panel ----
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xEE0D1117.toInt())
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0xFF30363D.toInt())
            }
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "image-clicker  (drag me)"
            setTextColor(0xFF8B949E.toInt())
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(chip("clr") { clearLog() })
        header.addView(chip("hide") { panelWanted = false; syncWindows() })
        header.addView(chip("exit") { shutdown() })
        panel.addView(header)

        logView = TextView(this).apply {
            setTextColor(0xFF7EE787.toInt())
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextIsSelectable(false)
        }
        scroll = ScrollView(this).apply { addView(logView) }
        panel.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val prompt = TextView(this).apply {
            text = "$ "
            setTextColor(0xFF7EE787.toInt())
            typeface = Typeface.MONOSPACE
        }
        input = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF6E7681.toInt())
            hint = "help"
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            setOnEditorActionListener { _, actionId, event ->
                val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
                if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                    submit()
                    true
                } else {
                    false
                }
            }
        }
        row.addView(prompt)
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(chip("^") { recall() })
        row.addView(chip("go") { submit() })
        panel.addView(row)

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(40)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }
        layoutPanelSize()
        makeDraggable(header, panelLp, panel, null)

        // replay anything logged before the views existed
        logView.text = logLines.joinToString("\n")
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        typeface = Typeface.MONOSPACE
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setPadding(dp(9), dp(5), dp(9), dp(5))
        background = GradientDrawable().apply {
            setColor(0xFF21262D.toInt())
            cornerRadius = dp(6).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(4) }
        setOnClickListener { onClick() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, lp: WindowManager.LayoutParams, target: View, onClick: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun submit() {
        val t = input.text.toString()
        input.setText("")
        if (t.isBlank()) return
        history.add(t)
        histPos = history.size
        term?.exec(t)
    }

    private fun recall() {
        if (history.isEmpty()) return
        histPos = if (histPos <= 0) history.size - 1 else histPos - 1
        input.setText(history[histPos])
        input.setSelection(input.text.length)
    }

    /** Adds/removes the overlay windows so they match the current state. Main thread only. */
    private fun syncWindows() {
        if (!alive || finished) return
        val wantBubble = uiVisible
        val wantPanel = uiVisible && panelWanted && !running
        if (wantBubble && !bubbleAdded) {
            wm.addView(bubble, bubbleLp); bubbleAdded = true
        } else if (!wantBubble && bubbleAdded) {
            wm.removeView(bubble); bubbleAdded = false
        }
        if (wantPanel && !panelAdded) {
            wm.addView(panel, panelLp); panelAdded = true
        } else if (!wantPanel && panelAdded) {
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            wm.removeView(panel); panelAdded = false
        }
    }

    private fun removeWindows() {
        if (!::wm.isInitialized) return
        if (panelAdded) { try { wm.removeView(panel) } catch (_: Exception) {}; panelAdded = false }
        if (bubbleAdded) { try { wm.removeView(bubble) } catch (_: Exception) {}; bubbleAdded = false }
    }

    private fun onRunState(r: Boolean) {
        main.post {
            running = r
            if (::bubble.isInitialized) {
                bubble.text = if (r) "■" else ">_"
                bubbleBg.setColor(if (r) 0xCCDA3633.toInt() else 0xCC238636.toInt())
            }
            if (!r) panelWanted = true
            syncWindows()
        }
    }

    // ------------------------------------------------------------------ Host

    override fun out(s: String) {
        main.post {
            logLines.addLast(s)
            while (logLines.size > 300) logLines.removeFirst()
            if (::logView.isInitialized) {
                logView.text = logLines.joinToString("\n")
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    override fun clearLog() {
        main.post {
            logLines.clear()
            if (::logView.isInitialized) logView.text = ""
        }
    }

    override fun capturer(): ScreenCapturer? = cap

    override fun hidePanel() {
        main.post { panelWanted = false; syncWindows() }
    }

    override fun exit() {
        main.post { shutdown() }
    }

    override suspend fun <T> withUiHidden(block: suspend () -> T): T {
        withContext(Dispatchers.Main) { uiVisible = false; syncWindows() }
        delay(450) // let the screen repaint without our windows
        try {
            return block()
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { uiVisible = true; syncWindows() }
        }
    }

    override suspend fun selectRegion(shot: Bitmap): Rect? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Rect?> { cont ->
            lateinit var view: RegionSelectorView
            view = RegionSelectorView(this@OverlayService, shot) { rect ->
                try { wm.removeView(view) } catch (_: Exception) {}
                if (cont.isActive) cont.resume(rect)
            }
            val lp = WindowManager.LayoutParams(
                shot.width, shot.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wm.addView(view, lp)
            cont.invokeOnCancellation {
                main.post { try { wm.removeView(view) } catch (_: Exception) {} }
            }
        }
    }

    override fun mark(r: Rect) {
        main.post {
            if (!alive || finished) return@post
            val c = cap ?: return@post
            val v = HighlightView(this, r)
            val lp = WindowManager.LayoutParams(
                c.width, c.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            try {
                wm.addView(v, lp)
                main.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {} }, 1200)
            } catch (_: Exception) {
            }
        }
    }
}
