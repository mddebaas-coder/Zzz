package app.imageclicker

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewAnimationUtils
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Foreground service that owns: screen capture, the floating bubble, the terminal panel,
 * the sequence runner. UI is built in code so the project needs no layout resources.
 */
class OverlayService : Service(), Host {

    companion object {
        const val ACTION_START = "app.imageclicker.START"
        const val ACTION_STOP_RUN = "app.imageclicker.STOP_RUN"
        const val ACTION_EXIT = "app.imageclicker.EXIT"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val PROJECT_LABEL = "martijn's project v1.6"
        private const val CHANNEL = "imageclicker"
        private const val NOTIF_ID = 1

        @Volatile
        var alive = false
            private set
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var wm: WindowManager
    private lateinit var imm: InputMethodManager

    override val store: Store by lazy { Store(applicationContext) }
    override val settings: ClickerSettings by lazy { ClickerSettings(applicationContext) }
    override val runner: Runner by lazy {
        Runner(scope, { cap }, store, settings, { s -> out(s) }, { r -> onRunState(r) }, { r -> mark(r) })
    }

    @Volatile private var cap: ScreenCapturer? = null
    private var term: Terminal? = null

    // views
    private lateinit var bubble: BubbleView
    private lateinit var panel: FrameLayout
    private lateinit var backdrop: ThemeBackdrop
    private lateinit var content: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var promptView: TextView
    private lateinit var themeChip: TextView
    private lateinit var label: TextView
    private lateinit var labelLp: WindowManager.LayoutParams
    private var labelAdded = false
    private lateinit var menuCatcher: View
    private lateinit var menuScroll: ScrollView
    private lateinit var menuList: LinearLayout
    private val menuItems = ArrayList<TextView>()
    private var menuOpen = false
    private val chips = ArrayList<TextView>()
    private var curTheme: Theme = Themes.get(0)
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    private var bubbleAdded = false
    private var panelAdded = false
    private var uiVisible = true
    private var panelWanted = true
    private var running = false
    private var finished = false

    private val logLines = ArrayDeque<String>()
    private val history = ArrayList<String>()
    private var histPos = 0

    // ------------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP_RUN -> if (alive) runner.stop()
            ACTION_EXIT -> shutdown()
            else -> if (!alive) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (alive) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        // Must be foreground (type mediaProjection) before the projection token is used.
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return
        }
        try {
            val c = ScreenCapturer(this, code, data)
            c.onStopped = { main.post { out("screen capture was stopped by the system"); shutdown() } }
            c.start()
            cap = c
        } catch (e: Exception) {
            finished = true
            android.widget.Toast.makeText(
                this, "Image Clicker: screen capture failed to start (${e.message})", android.widget.Toast.LENGTH_LONG
            ).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        alive = true
        buildUi()
        val t = Terminal(this, scope)
        term = t
        t.banner()
        syncWindows()
    }

    private fun shutdown() {
        if (finished) return
        finished = true
        alive = false
        try { runner.stop() } catch (_: Exception) {}
        main.post {
            try { removeWindows() } catch (_: Exception) {}
        }
        cap?.let { c -> c.onStopped = null; c.release() }
        cap = null
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!finished) {
            finished = true
            alive = false
            cap?.let { c -> c.onStopped = null; c.release() }
            cap = null
            scope.cancel()
            try { removeWindows() } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!alive) return
        layoutPanelSize()
        if (panelAdded) try { wm.updateViewLayout(panel, panelLp) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Image Clicker", NotificationManager.IMPORTANCE_LOW))
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Image Clicker")
            .setContentText("Overlay terminal is active")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop run", pi(ACTION_STOP_RUN, 1))
            .addAction(android.R.drawable.ic_delete, "Exit", pi(ACTION_EXIT, 2))
            .build()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun layoutPanelSize() {
        val dm = resources.displayMetrics
        panelLp.width = min(dm.widthPixels - dp(16), dp(460))
        panelLp.height = min((dm.heightPixels * 0.55).toInt(), dp(340))
    }

    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        curTheme = Themes.get(settings.theme)

        // ---- bubble ----
        bubble = BubbleView(this)
        bubbleLp = WindowManager.LayoutParams(
            dp(52), dp(52), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(220)
        }
        makeDraggable(bubble, bubbleLp, bubble) {
            if (running) {
                runner.stop()
            } else {
                panelWanted = !panelWanted
                syncWindows()
            }
        }

        // ---- panel = animated theme backdrop with the terminal on top ----
        panel = FrameLayout(this)
        backdrop = ThemeBackdrop(this)
        panel.addView(
            backdrop,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(
            content,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            pivotX = 0f
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        themeChip = chip("◐", Icon.THEME) { cycleTheme() }
        header.addView(themeChip)
        header.addView(chip("hold", Icon.HOLD) { term?.hold("") })
        header.addView(chip("☰", Icon.MENU) { toggleMenu() })
        content.addView(header)

        logView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextIsSelectable(false)
            setLineSpacing(dp(1).toFloat(), 1f)
            setPadding(0, dp(4), 0, dp(4))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(logView)
        }
        content.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        promptView = TextView(this).apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f) }
        input = EditText(this).apply {
            hint = "help"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            setOnEditorActionListener { _, actionId, event ->
                val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
                if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                    submit()
                    true
                } else {
                    false
                }
            }
        }
        row.addView(promptView)
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(chip("^", Icon.UP) { recall() })
        row.addView(chip("go", Icon.SEND) { submit() })
        content.addView(row)

        // ---- dropdown menu (☰): tap anywhere else to close ----
        menuCatcher = View(this).apply {
            visibility = View.GONE
            setOnClickListener { closeMenu() }
        }
        panel.addView(
            menuCatcher,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        menuList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        menuScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            addView(menuList)
        }
        panel.addView(
            menuScroll,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END
            )
        )
        addMenuItem(Icon.LOOP, "Run forever") { term?.exec("run inf") }
        addMenuItem(Icon.PLAY, "Run once") { term?.exec("run") }
        addMenuItem(Icon.STOP, "Stop") { term?.exec("stop") }
        addMenuItem(Icon.SNAP, "Snap image…") { startTyping("snap ") }
        addMenuItem(Icon.LIST, "Steps") { term?.exec("steps") }
        addMenuItem(Icon.FOLDER, "Saved sequences") { term?.exec("seqs") }
        addMenuItem(Icon.INFO, "Status") { term?.exec("status") }
        addMenuItem(Icon.CLEAR, "Clear log") { clearLog() }
        addMenuItem(Icon.HIDE, "Hide menu") { panelWanted = false; syncWindows() }
        addMenuItem(Icon.HELP, "Help") { term?.exec("help") }
        addMenuItem(Icon.EXIT, "Exit") { shutdown() }

        // ---- project label, always on screen while the app runs (never touchable) ----
        label = TextView(this).apply {
            text = PROJECT_LABEL
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setSingleLine(true)
            setPadding(dp(9), dp(3), dp(9), dp(3))
        }
        labelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (settings.labelLeft) Gravity.START else Gravity.END)
            x = dp(8)
            y = statusBarHeight() + dp(4)
        }

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(4)
            y = dp(40)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }
        layoutPanelSize()
        makeDraggable(header, panelLp, panel, null)
        applyTheme(curTheme, null)

        // replay anything logged before the views existed
        logView.text = logLines.joinToString("\n")
    }

    private class ChipSpec(val label: String, val icon: Icon)

    private class MenuSpec(val icon: Icon)

    private fun chip(label: String, icon: Icon, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        tag = ChipSpec(label, icon)
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setPadding(dp(8), dp(5), dp(8), dp(5))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(4) }
        setOnClickListener { v ->
            pokeAt(v)
            onClick()
        }
        chips.add(this)
    }

    private fun addMenuItem(icon: Icon, text: String, action: () -> Unit) {
        val item = TextView(this).apply {
            this.text = text
            tag = MenuSpec(icon)
            gravity = Gravity.CENTER_VERTICAL
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine(true)
            setPadding(dp(10), dp(7), dp(16), dp(7))
            compoundDrawablePadding = dp(10)
            minWidth = dp(172)
            setOnClickListener { v ->
                pokeAt(v)
                closeMenu()
                action()
            }
        }
        menuItems.add(item)
        menuList.addView(item, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun toggleMenu() {
        if (menuOpen) closeMenu() else openMenu()
    }

    private fun openMenu() {
        menuOpen = true
        menuCatcher.visibility = View.VISIBLE
        menuScroll.visibility = View.VISIBLE
        menuScroll.scrollTo(0, 0)
        if (menuScroll.width > 0) menuScroll.pivotX = menuScroll.width.toFloat()
        menuScroll.pivotY = 0f
        menuScroll.alpha = 0f
        menuScroll.scaleX = 0.85f
        menuScroll.scaleY = 0.6f
        menuScroll.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0L)
            .setDuration(230L).setInterpolator(DecelerateInterpolator(1.8f)).start()
        menuItems.forEachIndexed { i, item ->
            item.alpha = 0f
            item.translationX = dp(16).toFloat()
            item.animate().alpha(1f).translationX(0f)
                .setStartDelay(40L + i * 24L).setDuration(210L).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closeMenu(animate: Boolean = true) {
        if (!menuOpen) return
        menuOpen = false
        menuCatcher.visibility = View.GONE
        if (!animate) {
            menuScroll.animate().cancel()
            menuScroll.visibility = View.GONE
            return
        }
        menuScroll.animate().alpha(0f).scaleY(0.7f).setStartDelay(0L).setDuration(140L)
            .withEndAction { if (!menuOpen) menuScroll.visibility = View.GONE }.start()
    }

    /** Puts [prefix] in the input and opens the keyboard, e.g. "snap " so you only type the name. */
    private fun startTyping(prefix: String) {
        input.setText(prefix)
        input.setSelection(prefix.length)
        input.requestFocus()
        imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Tells the animated background where something was tapped (Morphogen grows there). */
    private fun pokeAt(v: View) {
        if (!::backdrop.isInitialized || !panel.isAttachedToWindow) return
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        panel.getLocationInWindow(b)
        backdrop.poke((a[0] - b[0] + v.width / 2).toFloat(), (a[1] - b[1] + v.height / 2).toFloat())
    }

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    /** Irregular corner radii, stable per [seed], for organic pebble-shaped buttons. */
    private fun pebble(seed: String): FloatArray {
        val r = java.util.Random(seed.hashCode().toLong())
        return FloatArray(8) { dp(5 + r.nextInt(12)).toFloat() }
    }

    // ------------------------------------------------------------------ themes

    private fun styleChip(c: TextView, th: Theme) {
        val spec = c.tag as? ChipSpec
        c.typeface = th.chipFont
        c.setTextColor(th.chipText)
        val organic = th.organicChips && spec != null
        c.background = GradientDrawable().apply {
            setColor(th.chipBg)
            if (organic) cornerRadii = pebble(spec!!.label) else cornerRadius = th.chipRadiusDp * resources.displayMetrics.density
            setStroke(dp(1), th.chipStroke)
        }
        c.rotation = if (organic) (Math.floorMod(spec!!.label.hashCode(), 5) - 2) * 1.3f else 0f
        if (th.iconChips && spec != null) {
            c.text = ""
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(IconDrawable(spec.icon, th.chipText, dp(18)), null, null, null)
            c.setPadding(dp(9), dp(5), dp(9), dp(5))
        } else {
            if (spec != null) c.text = spec.label
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null)
            c.setPadding(dp(8), dp(5), dp(8), dp(5))
        }
    }

    private fun styleMenu(th: Theme) {
        val density = resources.displayMetrics.density
        menuScroll.background = GradientDrawable().apply {
            setColor(th.menuBg)
            setStroke(dp(1), th.chipStroke)
            if (th.organicChips) cornerRadii = pebble("menu") else cornerRadius = min(th.cornerDp, 16f) * density
        }
        menuScroll.elevation = dp(10).toFloat()
        for (item in menuItems) {
            val spec = item.tag as MenuSpec
            item.typeface = th.chipFont
            item.setTextColor(th.menuText)
            item.setCompoundDrawablesRelativeWithIntrinsicBounds(IconDrawable(spec.icon, th.menuText, dp(18)), null, null, null)
            item.background = RippleDrawable(ColorStateList.valueOf(withAlpha(th.chipStroke, 0x55)), null, ColorDrawable(Color.WHITE))
        }
        val p = backdrop.padPx
        (menuScroll.layoutParams as FrameLayout.LayoutParams).apply {
            topMargin = p + dp(36)
            marginEnd = p + dp(6)
            bottomMargin = p + dp(6)
        }
        menuScroll.requestLayout()
    }

    private fun styleLabel(th: Theme) {
        label.typeface = th.titleFont
        label.setTextColor(th.menuText)
        label.letterSpacing = min(th.titleSpacing, 0.1f)
        label.setShadowLayer(th.glowDp * resources.displayMetrics.density, 0f, 0f, th.glowColor)
        label.background = GradientDrawable().apply {
            setColor(th.menuBg)
            setStroke(dp(1), th.chipStroke)
            if (th.organicChips) cornerRadii = pebble("label") else cornerRadius = th.chipRadiusDp * resources.displayMetrics.density + dp(2)
        }
    }

    /** Restyles every widget for [th]. With [revealFrom] the new look spreads out from that view. */
    private fun applyTheme(th: Theme, revealFrom: View?) {
        curTheme = th
        backdrop.theme = th
        bubble.theme = th
        val p = backdrop.padPx
        content.setPadding(p + dp(8), p + dp(5), p + dp(8), p + dp(4))
        val glow = th.glowDp * resources.displayMetrics.density
        titleView.text = th.title
        titleView.typeface = th.titleFont
        titleView.setTextColor(th.titleColor)
        titleView.letterSpacing = th.titleSpacing
        titleView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        logView.typeface = th.logFont
        logView.setTextColor(th.logColor)
        logView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        promptView.text = th.prompt
        promptView.typeface = th.logFont
        promptView.setTextColor(th.promptColor)
        promptView.setShadowLayer(glow, 0f, 0f, th.glowColor)
        input.typeface = th.logFont
        input.setTextColor(th.inputColor)
        input.setHintTextColor(th.hintColor)
        if (Build.VERSION.SDK_INT >= 29) {
            input.textCursorDrawable = GradientDrawable().apply {
                setColor(th.cursorColor)
                setSize(dp(th.cursorWidthDp), dp(18))
            }
        }
        for (c in chips) styleChip(c, th)
        styleMenu(th)
        styleLabel(th)
        if (revealFrom != null && panelAdded && panel.isAttachedToWindow) reveal(revealFrom)
    }

    private fun cycleTheme() {
        setThemeIndex(settings.theme + 1, themeChip)
    }

    private fun setThemeIndex(i: Int, from: View?) {
        val idx = Math.floorMod(i, Themes.all.size)
        settings.theme = idx
        applyTheme(Themes.get(idx), from)
        out("theme: ${curTheme.name}  (${idx + 1}/${Themes.all.size})")
    }

    /** Circular wipe from the theme button + the title popping in. */
    private fun reveal(from: View) {
        try {
            val a = IntArray(2)
            val b = IntArray(2)
            from.getLocationInWindow(a)
            panel.getLocationInWindow(b)
            val cx = a[0] - b[0] + from.width / 2
            val cy = a[1] - b[1] + from.height / 2
            val r = hypot(panel.width.toDouble(), panel.height.toDouble()).toFloat()
            ViewAnimationUtils.createCircularReveal(panel, cx, cy, 0f, r).apply {
                duration = 560L
                interpolator = DecelerateInterpolator(1.6f)
            }.start()
            titleView.alpha = 0f
            titleView.scaleX = 0.7f
            titleView.scaleY = 0.7f
            titleView.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(140L).setDuration(460L).setInterpolator(OvershootInterpolator(2.2f)).start()
        } catch (_: Exception) {
        }
    }

    override fun setLabelSide(left: Boolean) {
        main.post {
            settings.labelLeft = left
            if (!::label.isInitialized) return@post
            labelLp.gravity = Gravity.TOP or (if (left) Gravity.START else Gravity.END)
            if (labelAdded) try { wm.updateViewLayout(label, labelLp) } catch (_: Exception) {}
            out("label moved to the ${if (left) "left" else "right"}")
        }
    }

    override fun switchTheme(name: String?) {
        main.post {
            if (!::backdrop.isInitialized) return@post
            if (name.isNullOrBlank()) {
                cycleTheme()
                return@post
            }
            val n = name.trim()
            val idx = n.toIntOrNull()?.minus(1) ?: Themes.all.indexOfFirst {
                it.name.replace(" ", "").startsWith(n.replace(" ", ""), ignoreCase = true)
            }
            if (idx < 0 || idx >= Themes.all.size) {
                out("! no theme '$n'. themes: " + Themes.all.mapIndexed { i, t -> "${i + 1}=${t.name}" }.joinToString(", "))
            } else {
                setThemeIndex(idx, if (panelAdded) themeChip else null)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, lp: WindowManager.LayoutParams, target: View, onClick: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun submit() {
        val t = input.text.toString()
        input.setText("")
        if (t.isBlank()) return
        pokeAt(input)
        history.add(t)
        histPos = history.size
        term?.exec(t)
    }

    private fun recall() {
        if (history.isEmpty()) return
        histPos = if (histPos <= 0) history.size - 1 else histPos - 1
        input.setText(history[histPos])
        input.setSelection(input.text.length)
    }

    /** Adds/removes the overlay windows so they match the current state. Main thread only. */
    private fun syncWindows() {
        if (!alive || finished) return
        if (!labelAdded && ::label.isInitialized) {
            try {
                wm.addView(label, labelLp)
                labelAdded = true
            } catch (_: Exception) {
            }
        }
        val wantBubble = uiVisible
        val wantPanel = uiVisible && panelWanted && !running
        if (wantBubble && !bubbleAdded) {
            wm.addView(bubble, bubbleLp); bubbleAdded = true
        } else if (!wantBubble && bubbleAdded) {
            wm.removeView(bubble); bubbleAdded = false
        }
        if (wantPanel && !panelAdded) {
            wm.addView(panel, panelLp); panelAdded = true
        } else if (!wantPanel && panelAdded) {
            closeMenu(animate = false)
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            wm.removeView(panel); panelAdded = false
        }
    }

    private fun removeWindows() {
        if (!::wm.isInitialized) return
        if (panelAdded) { try { wm.removeView(panel) } catch (_: Exception) {}; panelAdded = false }
        if (bubbleAdded) { try { wm.removeView(bubble) } catch (_: Exception) {}; bubbleAdded = false }
        if (labelAdded) { try { wm.removeView(label) } catch (_: Exception) {}; labelAdded = false }
    }

    private fun onRunState(r: Boolean) {
        main.post {
            running = r
            if (::bubble.isInitialized) bubble.running = r
            if (!r) panelWanted = true
            syncWindows()
        }
    }

    // ------------------------------------------------------------------ Host

    override fun out(s: String) {
        main.post {
            logLines.addLast(s)
            while (logLines.size > 300) logLines.removeFirst()
            if (::logView.isInitialized) {
                logView.text = logLines.joinToString("\n")
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    override fun clearLog() {
        main.post {
            logLines.clear()
            if (::logView.isInitialized) logView.text = ""
        }
    }

    override fun capturer(): ScreenCapturer? = cap

    override fun hidePanel() {
        main.post { panelWanted = false; syncWindows() }
    }

    override fun exit() {
        main.post { shutdown() }
    }

    override suspend fun <T> withUiHidden(block: suspend () -> T): T {
        withContext(Dispatchers.Main) { uiVisible = false; syncWindows() }
        delay(450) // let the screen repaint without our windows
        try {
            return block()
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { uiVisible = true; syncWindows() }
        }
    }

    override suspend fun selectRegion(shot: Bitmap): Rect? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Rect?> { cont ->
            lateinit var view: RegionSelectorView
            view = RegionSelectorView(this@OverlayService, shot) { rect ->
                try { wm.removeView(view) } catch (_: Exception) {}
                if (cont.isActive) cont.resume(rect)
            }
            val lp = WindowManager.LayoutParams(
                shot.width, shot.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wm.addView(view, lp)
            cont.invokeOnCancellation {
                main.post { try { wm.removeView(view) } catch (_: Exception) {} }
            }
        }
    }

    override suspend fun pickPoint(): Point? = withContext(Dispatchers.Main) {
        val c = cap
        val dm = resources.displayMetrics
        val w = c?.width ?: dm.widthPixels
        val hgt = c?.height ?: dm.heightPixels
        suspendCancellableCoroutine<Point?> { cont ->
            lateinit var view: PointPickerView
            view = PointPickerView(this@OverlayService) { pt ->
                try { wm.removeView(view) } catch (_: Exception) {}
                if (cont.isActive) cont.resume(pt)
            }
            val lp = WindowManager.LayoutParams(
                w, hgt, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wm.addView(view, lp)
            cont.invokeOnCancellation {
                main.post { try { wm.removeView(view) } catch (_: Exception) {} }
            }
        }
    }

    override fun mark(r: Rect) {
        main.post {
            if (!alive || finished) return@post
            val c = cap ?: return@post
            val v = HighlightView(this, r)
            val lp = WindowManager.LayoutParams(
                c.width, c.height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            try {
                wm.addView(v, lp)
                main.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {} }, 1200)
            } catch (_: Exception) {
            }
        }
    }
}

/** Wraps an [Icon] as a Drawable so it can sit inside buttons and menu rows. */
private class IconDrawable(private val icon: Icon, private var color: Int, private val size: Int) : Drawable() {
    override fun draw(canvas: Canvas) {
        val b = bounds
        Icons.draw(canvas, icon, b.exactCenterX(), b.exactCenterY(), min(b.width(), b.height()).toFloat(), color)
    }

    override fun setAlpha(alpha: Int) {
        color = withAlpha(color, alpha)
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = size

    override fun getIntrinsicHeight(): Int = size
}
