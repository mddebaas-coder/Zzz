package app.imageclicker

import kotlin.math.min
import kotlin.math.roundToInt

/** Name, one-line description and renderer of each menu style. Order = gallery order. */
class StyleInfo(val id: String, val name: String, val blurb: String, val make: () -> StyleCanvas)

object StyleFactory {
    const val DEFAULT = "classic"

    val all: List<StyleInfo> = listOf(
        StyleInfo("glass", "Liquid Glass", "Frosted dock; a liquid drop flows to what you touch and melts into the glass") { GlassCanvas() },
        StyleInfo("neon", "Neon Cyberpunk", "Slanted neon blades on a rail; boots with a glitch, RGB split and scanlines") { NeonCanvas() },
        StyleInfo("orbital", "Orbital", "Items orbit a glowing core; spin the ring with your finger, it snaps with a tick") { OrbitalCanvas() },
        StyleInfo("deck", "Card Deck", "A hand of cards that fans out; swipe to turn it, tap to flip a card over") { DeckCanvas() },
        StyleInfo("blob", "Morphing Blob", "One living shape that melts into the silhouette of each item") { BlobCanvas() },
        StyleInfo("particles", "Particle Burst", "A honeycomb of hexagons that assembles from streams of particles and bursts when pressed") { ParticleCanvas() },
        StyleInfo("terminal", "Retro Terminal", "A green-screen menu that types itself out; the bar steps line by line with a phosphor trail") { TerminalCanvas() },
        StyleInfo("arcade", "Pixel Arcade", "An 8-bit cabinet: pixel font, stepped 12 fps motion, buttons that sink one pixel") { ArcadeCanvas() },
        StyleInfo("origami", "Origami", "Paper panels unfold along their creases; a ribbon marks your place") { OrigamiCanvas() },
        StyleInfo("clay", "Clay", "Puffy pastel clay buttons that drop in, squash and jiggle") { ClayCanvas() },
        StyleInfo("aurora", "Aurora", "A night-sky curtain with flowing aurora light that glides between items") { AuroraCanvas() },
        StyleInfo("brutal", "Kinetic Brutalist", "Huge words in raw blocks that slam in and slide with your scroll") { BrutalCanvas() },
        StyleInfo("classic", "Classic", "The original dropdown: rows slide in, ripples, springy switches") { ClassicCanvas() }
    )

    fun index(id: String): Int = all.indexOfFirst { it.id == id }

    fun get(i: Int): StyleInfo = all[Math.floorMod(i, all.size)]

    /** The saved id if it still exists, otherwise the default (e.g. after an update removed a style). */
    fun resolve(id: String?): StyleInfo = all.firstOrNull { it.id == id } ?: all.first { it.id == DEFAULT }

    /** Finds a style by id, by name (spaces ignored, prefix ok) or by its 1-based number. */
    fun find(query: String): StyleInfo? {
        val q = query.trim().lowercase().replace(" ", "")
        if (q.isEmpty()) return null
        q.toIntOrNull()?.let { return all.getOrNull(it - 1) }
        return all.firstOrNull { it.id == q }
            ?: all.firstOrNull { it.name.lowercase().replace(" ", "").startsWith(q) }
            ?: all.firstOrNull { it.id.startsWith(q) }
    }

    fun make(id: String): StyleCanvas = (all.firstOrNull { it.id == id } ?: throw IllegalArgumentException("unknown style $id")).make()
}

/** Where the menu box sits inside the overlay window. */
enum class Anchor { TOP, BOTTOM, CENTER, START, END, TOP_END, FILL }

/** A style's menu box, in dp, inside a window of the given size. [scrim] = alpha of the dim layer behind it. */
class Placement(val anchor: Anchor, val w: Int, val h: Int, val marginX: Int, val marginY: Int, val scrim: Int) {
    /** Left/top of the box inside a [sw] x [sh] window (dp). */
    fun left(sw: Int): Int = when (anchor) {
        Anchor.START -> marginX
        Anchor.END, Anchor.TOP_END -> sw - w - marginX
        Anchor.FILL -> 0
        else -> (sw - w) / 2
    }

    fun top(sh: Int): Int = when (anchor) {
        Anchor.TOP, Anchor.TOP_END -> marginY
        Anchor.BOTTOM -> sh - h - marginY
        Anchor.FILL -> 0
        else -> (sh - h) / 2
    }
}

/**
 * Each style's own placement on screen: a dock, a rail, a drawer, a curtain, a takeover...
 * Pure arithmetic on the window size (dp), so it is unit-tested for phones, tablets and landscape.
 */
object MenuLayouts {
    fun place(id: String, sw: Int, sh: Int): Placement {
        val narrow = { max: Int, margin: Int -> min(sw - margin * 2, max).coerceAtLeast(min(sw, 160)) }
        val tall = { max: Int, margin: Int -> min(sh - margin * 2, max).coerceAtLeast(min(sh, 120)) }
        return when (id) {
            "glass" -> Placement(Anchor.BOTTOM, narrow(440, 8), tall(150, 12), 0, 20, 0x40)
            "neon" -> Placement(Anchor.START, min(124, sw / 2), tall(460, 24), 0, 0, 0x70)
            "orbital" -> min(min(sw, sh) - 24, 380).coerceAtLeast(160).let { Placement(Anchor.CENTER, it, it, 0, 0, 0x99) }
            "deck" -> Placement(Anchor.BOTTOM, narrow(440, 4), tall(200, 8), 0, 8, 0x70)
            "blob" -> Placement(Anchor.TOP, narrow(440, 8), tall(170, 24), 0, min(56, sh / 10), 0x50)
            "particles" -> Placement(Anchor.CENTER, narrow(400, 12), tall(360, 24), 0, 0, 0x99)
            "terminal" -> Placement(Anchor.TOP, narrow(560, 0), tall((sh * 0.45f).roundToInt().coerceAtLeast(260), 0), 0, 0, 0x66)
            "arcade" -> Placement(Anchor.BOTTOM, narrow(480, 0), tall(210, 0), 0, 0, 0x80)
            "origami" -> Placement(Anchor.END, min((sw * 0.8f).roundToInt(), 300), tall(500, 16), 0, 0, 0x66)
            "clay" -> Placement(Anchor.CENTER, narrow(340, 16), tall(400, 24), 0, 0, 0x80)
            "aurora" -> Placement(Anchor.TOP, sw, tall(190, 0), 0, 0, 0x50)
            "brutal" -> Placement(Anchor.FILL, sw, sh, 0, 0, 0)
            else -> Placement(Anchor.TOP_END, narrow(240, 8), tall(452, 28), 8, min(48, sh / 12), 0x30)
        }
    }
}
