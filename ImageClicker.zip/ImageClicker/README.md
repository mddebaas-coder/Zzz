# Image Clicker

Android overlay auto-clicker driven by **screenshot matching**. You save small images of buttons/icons from the
screen, build a **sequence** of steps in a floating **terminal**, and the app finds each image on screen and taps it.

No root, no OpenCV. Matching is done in Kotlin; taps are injected through an Accessibility Service.

## Build the APK

The project could not be compiled where it was written, so build it once yourself. Pick one:

**A. GitHub Actions (no setup)**
1. Create a new GitHub repo and push this folder to it.
2. Open the *Actions* tab → *Build APK* → wait for green → download artifact `ImageClicker-debug-apk`.
3. Unzip, copy `app-debug.apk` to the phone, install.

**B. Android Studio**
Open this folder → let it sync → *Build > Build Bundle(s) / APK(s) > Build APK(s)*.

**C. Command line** (JDK 17 + Android SDK with platform 34)
```
./gradlew assembleDebug
# -> app/build/outputs/apk/debug/app-debug.apk
```

Min Android 8.0 (API 26). Tested design target: Android 14.

## First-time setup (in the app)

1. **Allow draw-over-apps**
2. **Enable accessibility service** → *Image Clicker* → On
   Sideloaded app and the toggle is greyed out (Android 13+)? Settings → Apps → Image Clicker → ⋮ → *Allow restricted settings*, then retry.
3. **Start overlay terminal** → accept the screen-capture prompt.

A green `>_` bubble appears over every app. Tap it to open/close the terminal, drag it to move.

## Quick start

Open your target app, then in the terminal:

```
snap play            # screen freezes; drag a box around the Play button; Save
snap collect
snap ok
add tap play
add waitimg loading_done
add tap collect skip
add tap ok skip
add wait 1000
steps                # review
find play            # test: shows match score, outlines it in red
save daily
run 5                # run 5 loops   (run inf = forever)
```

When a run starts the panel hides and the bubble turns into a red **■**. Tap it (or the notification's *Stop run*) to stop.

## Commands

| command | what it does |
|---|---|
| `snap <name>` | freeze screen, drag a box, save it as image `<name>` |
| `snapxy <name> x y w h` | save an image from pixel coordinates |
| `tpl` / `tpl rm <name>` | list / delete images |
| `find <name> [thr=0.9]` | match right now, print score + position, outline it |
| `add <step>` | append a step (see below) |
| `ins <n> <step>` / `edit <n> <step>` | insert before / replace step n |
| `del <n>` / `mv <a> <b>` / `clear` | remove / reorder / empty |
| `steps` | list the sequence |
| `save <n>` / `load <n>` / `seqs` / `rm <n>` | named sequences |
| `run [count\|inf]` / `stop` | start / stop |
| `set thr\|poll\|loopdelay\|marks <v>` | defaults (see below) |
| `status` / `hide` / `clear log` / `exit` | misc |

## Steps

```
tap <img>      [thr=0.9] [timeout=0] [dx=0] [dy=0] [roi=x,y,w,h] [after=300] [skip]
waitimg <img>  [same options]     wait until the image is visible
goneimg <img>  [same options]     wait until the image is gone
tapxy <x> <y>                     [after=300]
swipe <x1> <y1> <x2> <y2>         [ms=300] [after=300]
wait <ms>
back | home
```

- `thr` match threshold 0–1 (default from `set thr`, initially 0.90). Lower = more forgiving.
- `timeout` ms to keep looking. **Default 0 = wait forever**, so a step never gives up on its own. If you set one, a timeout stops the run, or moves on when you add `skip`.
- `dx`/`dy` tap offset from the image centre. `roi` limits the search area (faster, fewer false hits).
- `after` pause after the step.

Settings: `thr` default threshold · `poll` ms between screenshots while waiting (350) · `loopdelay` ms between loops (500) · `marks on` flashes a red box where it taps.

## Files

Sequences are plain text (one step per line, `#` comments), images are PNGs, in
`Android/data/app.imageclicker/files/{sequences,templates}/` (reachable over USB or from a file manager that can open `Android/data`).
The current sequence is auto-saved and restored next time.

## Tips and limits

- Images are matched **pixel-wise**, so snap them on the same device/resolution/orientation you will run on. Rotating is handled, but re-snap if the app's layout changes.
- Pick boxes with some detail (text/icon edges). `snap` warns about flat areas that would match anywhere.
- Use `find` to tune `thr` before running. A good hit scores ≥ 0.95; a miss usually scores well below 0.85.
- Apps that block screenshots (`FLAG_SECURE`, many banking/streaming apps) show up black, so image matching cannot work there.
- Android 14+ shows a screen-sharing chip/notification and may ask for capture permission every time you start the overlay. That is a system rule.
- The terminal panel takes focus while open, so some games pause. It is removed automatically during runs.
- Check the target app's terms of service. Automating online games can get accounts banned.
